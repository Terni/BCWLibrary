﻿//
// General class responsible for translating hash variables
//

using System;
using System.Collections.Generic;
using System.Linq;
using System.Collections;
using System.Text;
using Expanded.VEngine.Interface;

////using System.Web;
////using System.Data;
////using System.Data.SqlClient;

//using RV.CF.Documents;
////using RV.Common;
////using DRS.Common.ERP;
//using DRS.CASE.Interface;
//using DRS.WEBClientCommon;



namespace Expanded.VEngine
{
	public class VarEngine
	{
		private IVarEngine _varEngine = new VarEngine_New();

		private IVarEngine VarEngineProp
		{
			get
			{
				return _varEngine;
			}
		}

		public string GetSpecialNullValue
		{
			get
			{
				return VarEngineProp.GetSpecialNullValue;
			}
		}

		public bool IsArticlePictureElement(string param)
		{
			return VarEngineProp.IsArticlePictureElement(param);
		}

		public bool IsContactPictureElement(string param)
		{
			return VarEngineProp.IsContactPictureElement(param);
		}

		public bool IsPictureElement(string param)
		{
			return VarEngineProp.IsPictureElement(param);
		}

		public string ProcessSimpleStringValue(string param)
		{
			return VarEngineProp.ProcessSimpleStringValue(param);
		}

		public object ProcessParam(VarParam varParam, bool ignoreErrors, out bool error)
		{
			return VarEngineProp.ProcessParam(varParam, ignoreErrors, out error);
		}
        
		public bool CommonParametersCheck(VarParam varParam, object objToCheck, out string fixedStr)
		{
			return VarEngineProp.CommonParametersCheck(varParam, objToCheck, out fixedStr);
		}

		public string ProcessString(string input)
		{
			ProcessStringReturnValue returnValue = VarEngineProp.ProcessString(input);
			return returnValue.ProcessedString;
		}

		public string ProcessString(string input, out VarParamCollection varParams, bool enableHTMLRender, bool quottedReplace)
		{
			ProcessStringReturnValue returnValue = VarEngineProp.ProcessString(input, enableHTMLRender, quottedReplace);
			varParams = returnValue.VarParams;
			return returnValue.ProcessedString;
		}

		public string ProcessString(string input, out VarParamCollection varParams, bool enableHTMLRender, string fixedGroup, bool quottedReplace)
		{
			ProcessStringReturnValue returnValue = VarEngineProp.ProcessString(input, enableHTMLRender, fixedGroup, quottedReplace);
			varParams = returnValue.VarParams;
			return returnValue.ProcessedString;
		}

		public string ProcessString(string input, out VarParamCollection varParams, bool enableHTMLRender, string fixedGroup, bool quottedReplace, out bool error)
		{
			ProcessStringReturnValue returnValue = VarEngineProp.ProcessString(input, enableHTMLRender, fixedGroup, quottedReplace);
			varParams = returnValue.VarParams;
			error = returnValue.Error;
			return returnValue.ProcessedString;
		}
	}
}