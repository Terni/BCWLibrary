﻿//
// Class for parsing and holding variables values
//

using System;
using System.Collections.Generic;
using System.Linq;
using Expanded.VEngine.Template;

////using System.Web;
////using RV.Common;

namespace Expanded.VEngine
{
	/// <summary>
	/// Summary description for CVarParam
	/// </summary>
	public class VarParam
	{
		List<KeyValuePair<string, string>> _prefixes;
		string _var, _varGroup;
		List<KeyValuePair<string, string>> _attributes;
		object _value;
	    private DisplayValueTypes _dataType;
		public const int maxAttributeLength = 200;
		public static char[] forbiddenChars = { ' ', '<', '>', '\n', '\t', ';', '\"' };

		public VarParam()
		{
			_prefixes = new List<KeyValuePair<string, string>>();
			_varGroup = "";
			_var = "";
			_attributes = new List<KeyValuePair<string, string>>();
			_value = null;
			_dataType = new DisplayValueTypes();
		}

		public List<KeyValuePair<string, string>> Prefixes
		{
			get
			{
				return _prefixes;
			}
		}

		public string VarGroup
		{
			get
			{
				return _varGroup;
			}

			set
			{
				_varGroup = value;
			}
		}
		public string Var
		{
			get
			{
				return _var;
			}

			set
			{
				_var = value;
			}
		}

		public string GroupAndVar
		{
			get
			{
				if (IsGroupDefined)
				{
					return VarGroup + ":" + Var;
				}
				return Var;
			}
		}

		public object Value
		{
			get
			{
				return _value;
			}

			set
			{
				_value = value;
			}
		}

        public string GetStringValue()
        {
            string val = _value.ToString().Replace("`", "'");
            return val;

        }

		public DisplayValueTypes DataType
		{
			get
			{
				return _dataType;
			}

			set
			{
				_dataType = value;
			}
		}

		public List<KeyValuePair<string, string>> Attributes
		{
			get
			{
				return _attributes;
			}
		}

		public bool IsGroupDefined
		{
			get
			{
				return _varGroup.Length > 0;
			}
		}

		public bool ContainsPrefix(string pref)
		{
			string prefTL = pref.ToLower();
			foreach (KeyValuePair<string, string> p in _prefixes)
			{
				if (prefTL == p.Key)
				{
					return true;
				}
			}

			return false;
		}

		public string GetPrefixValue(string pref)
		{
			string prefTL = pref.ToLower();
			foreach (KeyValuePair<string, string> p in _prefixes)
			{
				if (prefTL == p.Key)
				{
					return p.Value;
				}
			}

			return "";
		}

		public bool ContainsAttribute(string att)
		{
			string attTL = att.ToLower();
			foreach (KeyValuePair<string, string> a in _attributes)
			{
				if (attTL == a.Key)
				{
					return true;
				}
			}

			return false;
		}

		public string GetAttributeValue(string att)
		{
			string attTL = att.ToLower();
			foreach (KeyValuePair<string, string> a in _attributes)
			{
				if (attTL == a.Key)
				{
					return a.Value;
				}
			}

			return "";
		}

		public static string VarFromVarSplit(string[] str)
		{
			if (str.Length == 1)
			{
				return str[0];
			}

			if (str.Length == 2)
			{
				return str[1];
			}

			string res = "";
			for (int i = 1; i < str.Length; i++)
			{
				res += str[i];
				if (i != str.Length - 1)
				{
					res += ":";
				}
			}

			return res;
		}

		// #(prefix1,prefix2,prefixN)var(attibute1:value1,attribute2:value2,attribute3:value3)#

		public static VarParam FromHashedString(string str)
		{
			string repStr = str.Replace("#", "");
			return FromString(repStr);
		}

		public static VarParam FromString(string str)
		{
			VarParam param = new VarParam();

			// Storyboard params can have different formats, so we must process them at first
			string strTL = str.ToLower();
			if (strTL.StartsWith("drsc") || strTL.StartsWith("drsv"))
			{
				param._var = str;
				param._varGroup = "storyboard";
				return param;
			}
			if (strTL.StartsWith("storyboard:"))
			{
				param._var = str.Substring("storyboard:".Length);
				param._varGroup = "storyboard";
				return param;
			}

			// filter out forbidden characters
			if (str.Length > maxAttributeLength || (str.IndexOfAny(forbiddenChars) != -1))
			{
				return param;
			}

			bool hasPrefix = str.StartsWith("(");
			bool hasAttribute = str.EndsWith(")");

			if (hasPrefix)
			{
				string prefStr = str.Split(')')[0];
				if (prefStr.Length > 1)
				{
					string[] prefixes = prefStr.Substring(1).Split(',');
					foreach (string p in prefixes)
					{
						string[] pSpl = p.Split(':');
						pSpl[0] = pSpl[0].ToLower();
						param._prefixes.Add(new KeyValuePair<string, string>(pSpl[0], pSpl.Length > 1 ? pSpl[1] : ""));
					}
				}
			}

			if (hasAttribute)
			{
				string[] spl = str.Split('(');
				string attrStr = spl[spl.Length - 1];
				if (attrStr.Length > 1)
				{
					string[] attributes = attrStr.Substring(0, attrStr.Length - 1).Split(',');
					foreach (string a in attributes)
					{
						string[] aSpl = a.Split(':');
						aSpl[0] = aSpl[0].ToLower();
						param._attributes.Add(new KeyValuePair<string, string>(aSpl[0], aSpl.Length > 1 ? aSpl[1] : ""));

					}
				}
			}

			if (hasPrefix && hasAttribute)
			{
				string[] spl1 = str.Split(')');
				if (spl1.Length > 1)
				{
					string[] spl2 = spl1[1].Split('(');
					string[] splV = spl2[0].Split(':');
					param._varGroup = splV.Length > 1 ? splV[0].ToLower() : "";
					param._var = VarFromVarSplit(splV);
				}
			}
			else if (hasPrefix)
			{
				string[] spl = str.Split(')');
				if (spl.Length > 1)
				{
					string[] splV = spl[1].Split(':');
					param._varGroup = splV.Length > 1 ? splV[0].ToLower() : "";
					param._var = VarFromVarSplit(splV);
				}
			}
			else if (hasAttribute)
			{
				string[] splV = str.Split('(')[0].Split(':');
				param._varGroup = splV.Length > 1 ? splV[0].ToLower() : "";
				param._var = VarFromVarSplit(splV);
			}
			else
			{
				string[] splV = str.Split(':');
				param._varGroup = splV.Length > 1 ? splV[0].ToLower() : "";
				param._var = VarFromVarSplit(splV);
			}

			return param;
		}

		public override bool Equals(object obj)
		{
			// needed for unit test
			VarParam CVarParam = obj as VarParam;
			if (CVarParam == null)
			{
				return false;
			}
			bool returnValue = this.Value == null ? CVarParam.Value == null : this.Value.Equals(CVarParam.Value);
			returnValue = returnValue && string.Compare(this.GroupAndVar, CVarParam.GroupAndVar) == 0;
			//returnValue = returnValue && this.DataType.Equals(CVarParam.DataType);
			returnValue = returnValue && this.IsGroupDefined.Equals(CVarParam.IsGroupDefined);
			return returnValue;
		}
	}

	public class VarParamCollection
	{
		Dictionary<string, VarParam> _params;

		public VarParamCollection()
		{
			_params = new Dictionary<string, VarParam>();
		}

		/*public CVarParam AddParam(CTemplateUnit t, CVarParam param)
		{
			return AddParam(param, DwcTemplate.GetVarKey(t != null ? t.Template.TemplateKey : "", param.GroupAndVar));
		}*/

		public VarParam AddParam(VarParam param, string key)
		{
			VarParam found;
			if (_params.TryGetValue(key, out found))
			{
				// update
				found.Value = param.Value;
				return found;
			}

			_params[key] = param;
			return param;
		}

        /*VarParam GetParam(ETemplateUnit t, VarParam param)
        {
            VarParam found;
            if (_params.TryGetValue(ETemplate.GetVarKey(t.Template.TemplateKey, param.GroupAndVar), out found))
            {
                return found;
            }

            return null;
        }*/

        public Dictionary<string, VarParam> Params
		{
			get
			{
				return _params;
			}
            set
            {
                _params = value;
            }
		}

        public void AddParamCollection(ETemplateUnit u, VarParamCollection coll)
        {
            AddParamCollection(u, coll, false);
        }

        public void AddParamCollection(ETemplateUnit u, VarParamCollection coll, bool respectKey)
        {
            foreach (KeyValuePair<string, VarParam> p in coll.Params)
            {
                if (respectKey)
                {
                    AddParam(p.Value, p.Key);
                }
                //else
                //{
                //    AddParam(u, p.Value);
                //}
            }
        }
    }
}
