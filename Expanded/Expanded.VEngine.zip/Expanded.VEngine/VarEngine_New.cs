﻿//
// General class responsible for translating hash variables
//namespace Expanded.VEngine

using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

using Expanded.VEngine.Interface;
using Expanded.VEngine.Template;
using Expanded.VEngine.Commons;
using Expanded.VEngine;

////using System.Web;
////using System.Data;
////using System.Data.SqlClient;

//using DRS.CASE.Interface;
////using DRS.Common.ERP;
//using DRS.WEBClientCommon;
//using RV.CF.Documents;
////using RV.Common;
//using OmniView.Core.Interface;

namespace Expanded.VEngine
{
	public class ProcessStringReturnValue
    {
		public VarParamCollection VarParams
		{
			get;
			set;
		}

		public bool Error
		{
			get;
			set;
		}

		public string ProcessedString
		{
			get;
			set;
		}
	}

	public class VarEngine_New : IVarEngine
	{
	    private Common _common = new Common();


        public string GetSpecialNullValue
	    {
		    get
		    {
			    return "DWC_NULL_VALUE";
		    }
	    }

	    public bool IsArticlePictureElement(string paramStr)
	    {
		    if(string.IsNullOrWhiteSpace(paramStr))
		    {
			    return false;
		    }
		    return paramStr.ToLower().StartsWith("#article:picture");
	    }

	    public bool IsContactPictureElement(string paramStr)
	    {
		    if(string.IsNullOrWhiteSpace(paramStr))
		    {
			    return false;
		    }
		    return paramStr.ToLower().StartsWith("#contact:picture");
	    }

	    public bool IsPictureElement(string paramStr)
	    {
		    return IsArticlePictureElement(paramStr) || IsContactPictureElement(paramStr);
	    }

	    private object ProcessParam(VarParam param, bool ignoreErrors, out bool error, string fixedGroup)
	    {
		    error = true;
		    object res = null;
		    string paramGroup = (param.IsGroupDefined) ? param.VarGroup : fixedGroup;
		    if(paramGroup != null)
		    {
			    res = ProcessParamProcessParamWithGroup(param, paramGroup, ignoreErrors, ref error);
			    if(false == error)
			    {
				    return res;
			    }
		    }

		    bool trySecondProcess = ProcessParamModifyGroupOrVar(param, ref paramGroup);
		    // Try to retrieve parameter again
		    if(paramGroup != null)
		    {
			    if(trySecondProcess)
			    {
				    res = ProcessParamProcessParamWithGroup(param, paramGroup, ignoreErrors, ref error);
			    }

			    if(false == error)
			    {
				    return res;
			    }
			    else
			    {
				    return res.ToString();
			    }
		    }

		    return "MISSING PREFIX:" + param;
	    }

	    private object ProcessParamProcessParamWithGroup(VarParam param, string paramGroup, bool ignoreErrors, ref bool error)
	    {
            //TODO:62
		    //DwcDiagnostics.StartPLOMon("GetValue");
		    object res = ProcessParamWithGroup(param, paramGroup, ignoreErrors, ref error);
            //TODO:62
            //DwcDiagnostics.EndPLOMon("GetValue", "Param:" + param.GroupAndVar);
            return res;
	    }

	    private bool ProcessParamModifyGroupOrVar(VarParam param, ref string paramGroup)
	    {
		    bool returnValue = false;
		    string paramVarTL = param.Var.ToLower();
		    // Parameter was not resolved, or group was not defined. Try to resolve group
		    string[,] grouplessNames = new string[,] {
									    {"branch", "common"},
									    {"supplierid", "header"},
									    {"headerrecuid", "header"},
									    {"virtualarticlenumber", "article"},
									    {"vart", "article"},
									    {"searchquery", "common"},
									    {"loggeduser", "common"},
									    {"currentuser", "common"},
									    {"currentusername", "common"},
									    {"today", "common"},
									    {"language", "common"}
					    };
		    // Known parameters used without prefixed group
		    for(int i = 0; i < grouplessNames.GetLength(0); i++)
		    {
			    if(paramVarTL == grouplessNames[i, 0])
			    {
				    if(paramGroup != grouplessNames[i, 1])
				    {
					    paramGroup = grouplessNames[i, 1];
					    returnValue = true;
				    }
				    break;
			    }
		    }

		    // Convert aliases to corect names to retrieve data
		    string[,] aliases = new string[,] {
							    {"Article", "virtualarticlenumber", "VART"}
					    };
		    for(int i = 0; i < aliases.GetLength(0); i++)
		    {
			    if(_common.IsNull(param.VarGroup, "").ToLower() == aliases[i, 0].ToLower()
					    && param.Var.ToLower() == aliases[i, 1])
			    {
				    param.Var = aliases[i, 2];
				    returnValue = true;
				    break;
			    }
		    }

		    return returnValue;
	    }

	    private object ProcessParamWithGroup(VarParam param, string group, bool ignoreErrors, ref bool error)
	    {
		    IParamWithGroupProcessor paramWithGroupProcessor = DwcVarEngineProcessParamWithGroup.GetProcessor(group, ignoreErrors);
		    return paramWithGroupProcessor.ProcessParam(param, out error);
	    }

	    public string ProcessSimpleStringValue(string param)
	    {
		    bool error = false;
		    VarParam varParam = VarParam.FromString(param);
		    object res = ProcessParam(varParam, false, out error);
		    if(error == false && res != null)
		    {
			    return _common.GetObjectString(res);
		    }

		    return "";
	    }

	    public object ProcessParam(VarParam param, bool ignoreErrors, out bool error)
	    {
		    return ProcessParam(param, ignoreErrors, out error, null);
	    }

	    public bool CommonParametersCheck(VarParam varParam, object objToCheck, out string fixedStr)
	    {
		    // These parameters are exclusive
		    fixedStr = null;

		    // Check datasource parameter
		    /*string dataSource = varParam.GetAttributeValue("datasource");
		    if(dataSource != "")
		    {
			    return CommonParametersCheckDataSource(varParam, objToCheck, out fixedStr, dataSource);
		    }*/

		    if(CommonParametersCheckMaxLength(varParam, objToCheck, out fixedStr))
		    {
			    return true;
		    }

		    if(CommonParametersCheckNoTime(varParam, objToCheck, out fixedStr))
		    {
			    return true;
		    }

		    return CommonParametersCheckMaxWidth(varParam, objToCheck, out fixedStr);
	    }

	    /*private bool CommonParametersCheckDataSource(VarParam varParam, object objToCheck, out string fixedStr, string dataSource)
	    {
		    fixedStr = null;
		    string resStr = objToCheck.ToString();
		    rv.gc.Windows.Forms.ListItemsCollection list = new rv.gc.Windows.Forms.ListItemsCollection();
		    DwcCommon.FillEnumFromDataSource(list, DwcCommon.GetParamBranch(), dataSource);
		    foreach(rv.gc.Windows.Forms.ListItem i in list)
		    {
			    if(i.DataValue.ToString().ToLower() == resStr.ToLower())
			    {
				    fixedStr = i.DisplayValue;
				    return true;
			    }
		    }
		    return false;
	    }*/

	    private bool CommonParametersCheckMaxLength(VarParam varParam, object objToCheck, out string fixedStr)
	    {
		    fixedStr = null;
		    // Check maxlength parameter
		    string maxLength = varParam.GetAttributeValue("maxlength");
		    if(maxLength != "")
		    {
			    int maxLengthInt = int.Parse(maxLength);
			    string resStr = objToCheck.ToString();
			    if(maxLengthInt < resStr.Length)
			    {
				    resStr = resStr.Substring(0, maxLengthInt);
				    resStr += "…";
				    fixedStr = resStr;
				    return true;
			    }
		    }
		    return false;
	    }

	    private bool CommonParametersCheckNoTime(VarParam varParam, object objToCheck, out string fixedStr)
	    {
		    fixedStr = null;
		    // Check notime parameter
		    string noTime = varParam.GetAttributeValue("notime");
		    if(noTime != "")
		    {
			    // Works only for dates
			    if(objToCheck.GetType() == typeof(DateTime))
			    {
				    fixedStr = (objToCheck as DateTime?).Value.ToString();
				    return true;
			    }
		    }
		    return false;
	    }

	    private bool CommonParametersCheckMaxWidth(VarParam varParam, object objToCheck, out string fixedStr)
	    {
		    fixedStr = null;
		    // Check maxwidth parameter
		    string maxWidth = varParam.GetAttributeValue("maxwidth");
		    if(maxWidth != "")
		    {
			    string resStr = objToCheck.ToString();
			    fixedStr = @"<div style=""word-break:break-all;max-width:" + maxWidth + @""">" + resStr + "</div>";
			    return true;
		    }
		    return false;
	    }

	    public ProcessStringReturnValue ProcessString(string input)
	    {
		    return ProcessString(input, false, false);
	    }

	    public ProcessStringReturnValue ProcessString(string input, bool enableHTMLRender, bool quottedReplace)
	    {
		    return ProcessString(input, enableHTMLRender, null, quottedReplace);
	    }

	    public ProcessStringReturnValue ProcessString(string input, bool enableHTMLRender, string fixedGroup, bool quottedReplace)
	    {
		    var returnValue = new ProcessStringReturnValue()
		    {
			    VarParams = new VarParamCollection(),
			    Error = false,
			    ProcessedString = string.Empty
		    };

		    if(!string.IsNullOrEmpty(input))
		    {
			    //if(input.StartsWith("{loc:") && input.EndsWith("}"))
			    //{
			    //	returnValue.ProcessedString = DwcLocale.Localize(input);
			    //}
			    //else
			    //{
				    foreach(Match match in ProcessStringGetSymbolsToProcess(input, quottedReplace))
				    {
					    string inputSymbol = match.ToString();
					    string varSymbol = ProcessStringRemoveHashesAndQuotes(inputSymbol);
					    if(ProcessStringIsValidVarSymbol(varSymbol))
					    {
						    VarParam varParam = VarParam.FromString(varSymbol);
						    DisplayValueTypes varParamDataType = varParam.DataType;

						    bool error;
						    object processParamReturn = ProcessParam(varParam, false, out error, fixedGroup);
						    if(error)
						    {
							    returnValue.Error = true;
						    }

						    //DwcContextUnit contextUnit = DwcContext.GetContext(DwcContextType.Template);
                            ETemplateUnit templateUnit = null;
						    //WebClientTemplateColumn clientTemplateColumn = null;
						    //if(contextUnit != null)
						    //{
						    //    templateUnit = ConvertTypes.ConvertToCTemplateUnit(contextUnit.ObjectAsTemplate);
						    //	clientTemplateColumn = templateUnit.Template.Columns.GetColumn(varParam.GroupAndVar);
						    //}
						    //else
						    //{
						        enableHTMLRender = false;
                                templateUnit = new ETemplateUnit();
                            //}

                            //DisplayValueTypes ndisplayValueTypes = ProcessStringGetDisplayValueTypes(clientTemplateColumn, varParam, varParamDataType, processParamReturn);

                            string roughSymbol = ProcessStringGetRoughValue(processParamReturn, ConvertTypes.ConvertToVarParamBack(varParam), ConvertTypes.ConvertToTemplateUnitBack(templateUnit));
                            if (quottedReplace)
                            {
                                roughSymbol = ProcessStringProcessQuotes(inputSymbol, roughSymbol, 0);
                            }
                            //returnValue.VarParams.AddParam(templateUnit, varParam);
						    input = input.Replace(inputSymbol, roughSymbol);
					    }
				    }
				    returnValue.ProcessedString = input;
			    //}
		    }
		    return returnValue;
	    }



        private bool ProcessStringIsValidVarSymbol(string varSymbol)
	    {
		    if(string.IsNullOrEmpty(varSymbol))
		    {
			    return false;
		    }
		    if(varSymbol.Length > 4 && varSymbol.IndexOfAny(VarParam.forbiddenChars) >= 0)
		    {
			    //if(!(varSymbol.StartsWith("drsc", true, CultureInfo.InvariantCulture)|| varSymbol.StartsWith("drsv", true, CultureInfo.InvariantCulture)))
			    if(!(varSymbol.StartsWith("drsc")|| varSymbol.StartsWith("drsv")))
			    {
				    return false;
			    }
		    }
		    return true;
	    }

	    private MatchCollection ProcessStringGetSymbolsToProcess(string input, bool quottedReplace)
	    {
		    string forbidenChar = "#" + new string(VarParam.forbiddenChars);
		    string regexPattern;
		    if(quottedReplace)
		    {
			    regexPattern = "(N'|')?#(drsc[^#]*|drsv[^#]*|[^" + forbidenChar + "])*#'?";
		    }
		    else
		    {
			    regexPattern = "#(drsc[^#]*|drsv[^#]*|[^" + forbidenChar + "])*#";
		    }
		    return Regex.Matches(input ?? string.Empty, regexPattern, RegexOptions.IgnoreCase);
	    }

	    private string ProcessStringRemoveHashesAndQuotes(string inputSymbol)
	    {
		    var match = Regex.Match(inputSymbol ?? string.Empty, @"#(?<result>[^#]*?)#").Groups["result"];
		    if(match != null)
		    {
			    return match.Value;
		    }
		    return string.Empty;
	    }

		/*private DisplayValueTypes ProcessStringGetDisplayValueTypes(WebClientTemplateColumn clientTemplateColumn, VarParam varParam, DisplayValueTypes varParamDataType, object processParamReturn)
		{
			if(clientTemplateColumn != null)
			{
				return clientTemplateColumn.DataType;
			}
			else
			{
				// Check if data type  was not set by ProcessParam. If was, use it, if not, use value from object type
				if(varParamDataType != varParam.DataType)
				{
					return varParam.DataType;
				}
				else
				{
					return ETemplate.GetDisplayValueType(processParamReturn);
				}
			}
		}*/

		private string ProcessStringGetRoughValue(object processParamReturn, VarParam nVarParam, ETemplateUnit nTemplateUnit)
		{
			return ETemplate.GetDisplayValue(processParamReturn, ETemplate.GetDisplayValueType(processParamReturn), null, null, nVarParam);
		}

	    private string ProcessStringProcessQuotes(string originalSymbol, string inputSymbol, DisplayValueTypes displayValueTypes)
	    {
		    bool needQuotes = (false == ETemplate.IsNumberType(displayValueTypes) && displayValueTypes != DisplayValueTypes.Multiselect);
		    if(inputSymbol == GetSpecialNullValue)
		    {
			    needQuotes = false;
			    inputSymbol = "null";
		    }

		    if(needQuotes)
		    {
			    inputSymbol = "N'" + inputSymbol + "'";
		    }
		    else // older version doesn't remove quotes in this situation
		    {
			    if(originalSymbol.StartsWith("\'") && originalSymbol.EndsWith("\'"))
			    {
				    inputSymbol = "'" + inputSymbol + "'";
			    }
		    }
		    return inputSymbol;
	    }
	}
}