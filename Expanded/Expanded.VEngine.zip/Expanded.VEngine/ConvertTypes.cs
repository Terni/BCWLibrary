﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System;
using System.Collections;
using System.Collections.Generic;
//using System.Data;
//using System.Data.SqlClient;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using Expanded.VEngine.Template;

//using System.Web;

//using DRS.CASE.Interface;
////using DRS.Common.ERP;
//using DRS.WEBClientCommon;

//using RV.CF.Documents;
////using RV.Common;
//using DatecWebClient;


namespace Expanded.VEngine
{

    public static class ConvertTypes
    {

        /// -------------------------------- CONVERT OmniViev.Core.DwcVarEngine  -------------------------------- ///

        /// <summary>
        /// Method for covert type OmniViev.Core.DwcVarEngine.TemplateUnit
        /// </summary>
        /// <returns>TemplateUnit</returns>
        public static ETemplateUnit ConvertToTemplateUnit(ETemplateUnit objectAsTemplate)
        {
            if (objectAsTemplate != null)
            {
                ETemplateUnit convertedResult = new ETemplateUnit()
                {
                    ParametersFilled = objectAsTemplate.ParametersFilled,
                    //Template = objectAsTemplate.Template,
                };

                convertedResult.Parameters = ConvertToParamCollection(objectAsTemplate.Parameters);

                return convertedResult;
            }
            return null;
        }

        /// <summary>
        /// Method for covert type OmniViev.Core.DwcVarEngine.VarParamCollection
        /// </summary>
        /// <returns>VarParamCollection</returns>
        public static VarParamCollection ConvertToParamCollection(VarParamCollection objectAsParamCollection)
        {
            VarParamCollection convertedResult = new VarParamCollection();
            foreach (var item in objectAsParamCollection.Params)
            {
                convertedResult.Params.Add(item.Key, ConvertToVarParam(item.Value));
            }
            return convertedResult;
        }

        /// <summary>
        /// Method for covert type OmniViev.Core.DwcVarEngine.VarParam
        /// </summary>
        /// <returns>VarParam</returns>
        public static VarParam ConvertToVarParam(VarParam objectAsParam)
        {
            VarParam convertedResult = new VarParam()
            {
                Value = objectAsParam.Value,
                DataType = objectAsParam.DataType,
                Var = objectAsParam.Var,
                VarGroup = objectAsParam.VarGroup,
            };
            return convertedResult;
        }

        /// ---------------------------------- CONVERT BACK DatecWebClient  ------------------------------------- ///

        /// <summary>
        /// Method for covert type DatecWebClient.TemplateUnit
        /// </summary>
        /// <returns>TemplateUnit</returns>
        public static ETemplateUnit ConvertToTemplateUnitBack(ETemplateUnit objectAsTemplate)
        {
            if (objectAsTemplate != null)
            {
                ETemplateUnit convertedResult = new ETemplateUnit()
                {
                    ParametersFilled = objectAsTemplate.ParametersFilled,
                    //Template = objectAsTemplate.Template,
                };

                convertedResult.Parameters = ConvertToParamCollectionBack(objectAsTemplate.Parameters);
                return convertedResult;
            }

            return null;
        }

        /// <summary>
        /// Method for covert type DatecWebClient.VarParamCollection
        /// </summary>
        /// <returns>VarParamCollection</returns>
        public static VarParamCollection ConvertToParamCollectionBack(VarParamCollection objectAsParamCollection)
        {
            VarParamCollection convertedResult = new VarParamCollection();
            foreach (var item in objectAsParamCollection.Params)
            {
                convertedResult.Params.Add(item.Key, ConvertToVarParamBack(item.Value));
            }
            return convertedResult;
        }

        /// <summary>
        /// Method for covert type Dictionary DatecWebClient.VarParam
        /// </summary>
        /// <returns>Dictionary VarParam</returns>
        public static Dictionary<string, VarParam> ConvertToDictionaryVarParamBack( object element )
        {
            Dictionary<string, VarParam> objectAsDictionary = (Dictionary < string, VarParam > )element;

            Dictionary<string, VarParam> convertedResult = null;
            foreach (var item in objectAsDictionary)
            {
                convertedResult.Add(item.Key, ConvertToVarParamBack(item.Value));
            }

            return convertedResult;
        }

        /// <summary>
        /// Method for covert type DatecWebClient.VarParam
        /// </summary>
        /// <returns>VarParam</returns>
        public static VarParam ConvertToVarParamBack(VarParam objectAsParam)
        {
            VarParam convertedResult = new VarParam()
            {
                Value = objectAsParam.Value,
                DataType = objectAsParam.DataType,
                Var = objectAsParam.Var,
                VarGroup = objectAsParam.VarGroup,
            };
            return convertedResult;
        }




    }
}
