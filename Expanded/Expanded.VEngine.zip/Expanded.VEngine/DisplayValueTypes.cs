﻿namespace Expanded.VEngine
{
    /*public class DisplayValueTypes
    {
        private string _text;

        public DisplayValueTypes()
        {
            _text = string.Empty;
        }

        public string Text
        {
            get
            {
                return _text;
            }
            set { _text = value; }
        }
    }*/


    public enum DisplayValueTypes
    {
        Text = 0,
        Number = 1,
        PositiveNumber = 2,
        IntegerNumber = 3,
        PositiveIntegerNumber = 4,
        Currency = 5,
        PositiveCurrency = 6,
        Mask = 7,
        DateTime = 8,
        ShortDate = 9,
        ShortTime = 10,
        LongDate = 11,
        LongTime = 12,
        DateTimeCustomFormat = 13,
        Boolean = 14,
        Enum = 15,
        Hyperlink = 16,
        Icons = 17,
        EnumRewritable = 18,
        EnumRewriteNoSearch = 19,
        LongText = 20,
        Selection = 21,
        Section = 22,
        DateTimeTo = 23,
        RegularExpression = 24,
        Image = 25,
        RichText = 26,
        Button = 27,
        Template = 28,
        Whisperer = 29,
        Multiselect = 30,
        MultiselectSearchable = 31,
        ImportFile = 32,
        ErasableText = 33
    }

}