﻿//
// Translator of Article hash variables
//

using System;
using System.Collections.Generic;
using System.Linq;
//using System.Web;

//using RV.CF.Documents;
//using RV.Common;
//using DRS.Common.ERP;
//using DRS.CASE.Interface;

using System.Text;
using Expanded.VEngine.Commons;
using Org.Apache.Http.Protocol;

//using DatecWebClient;

namespace Expanded.VEngine
{
    //using DRS.WEBClientCommon;
    //using TP_OmniViewApp.Core.DomainServices.Search;
    //using TP_OmniViewApp.Core.DwcAdvanceProcessCreation;
    //using TP_OmniViewApp.Core.DwcSet;
    //using TP_OmniViewApp.Core.Common;

    public class VarEngineArticle
    {
        private VarEngine _varEngine = new VarEngine();

        public static string ArticlePictureElement(VarParam param)
        {
            return ArticlePictureElement(param, false);
        }

        public static string ArticlePictureElement(VarParam param, bool noLogin)
        {
            //string url;
            //bool error = false;
            ////_varEngine.ProcessParam(null, null, out neco);
            //object value = _varEngine.ProcessParam(VarParam.FromString("Article:" + DwcSettingsBase.ArticleCommonSettings.PictureColumnName), false,out error);
            //if (value == null)
            //{
            //    value = _varEngine.ProcessParam(VarParam.FromString("Article:VART"), false, out error);
            //}

            //if ((value == null || value == "")
            //    && DatecWebClient.DwcCache.PerUserProtectedCache[DwcCacheObjectType.PanelTempImageGuid] != null)
            //{
            //    value = DwcCache.PerUserProtectedCache[DwcCacheObjectType.PanelTempImageGuid];
            //    error = false;
            //}

            //string appendix = "";
            //string indexOfPicture = param.GetAttributeValue("index");
            //if (indexOfPicture != "")
            //{
            //    appendix = "_" + indexOfPicture;
            //}

            //string noLoginAddon = "";
            //if (noLogin)
            //{
            //    noLoginAddon = "?noLogin=1";
            //}

            //url =
            //    DwcSmartCache.CreateUrlForCachedQuery(
            //        Common.SetUrlParams(
            //            "../WEBDetail/ItemPicture.ashx" + noLoginAddon,
            //            new string[,]
            //                {
            //                    { "type", "Article" }, { "itemId", Common.GetObjectString(value) + appendix },
            //                    { "docObject", null }, { "menu", null }
            //                }),
            //        new KeyValuePair<string, string>[]
            //            {
            //                new KeyValuePair<string, string>("type", "Article"),
            //                new KeyValuePair<string, string>("itemId", Common.GetObjectString(value) + appendix)
            //            },
            //        60 * 5,
            //        // Check content each 5 minutes
            //        24 * 5); // Client will keep in cache for 5 days
            ////float:left;max-width:7em;max-height:7em
            //string style = " max-width:100%!important;max-height:100%!important;display: block;";
            //DwcContextUnit dcu = DwcContext.GetContext(DwcContextType.TableRender);
            //if (dcu != null && dcu.ObjectAsTableRender)
            //{
            //    style = "float:left;max-width:7em;max-height:7em;";
            //}
            //if (param.GetAttributeValue("maxwidth") != "")
            //{
            //    style = "width:" + param.GetAttributeValue("maxwidth");
            //}

            //return string.Format(
            //    @"<img data-key=""articlePicture"" src=""{0}"" style=""" + style + @""" alt=""{1}""/>",
            //    url,
            //    Common.GetObjectString(value) + appendix);
            throw new NotImplementedException();
        }

        public static int[] ParseStockInfoBranches(string attribute)
        {
            int[] branches = null;
            string b = attribute;

            if (b == "all")
            {
                //return DwcSettingsBase.AllBranches.ToArray();
                return null;
            }

            if (b != "")
            {
                List<int> listBranches = new List<int>();
                foreach (string branch in b.Split(new string[] { "+" }, StringSplitOptions.RemoveEmptyEntries))
                {
                    int testB = 0;
                    if (int.TryParse(branch, out testB))
                    {
                        listBranches.Add(testB);
                    }
                }

                branches = listBranches.ToArray();
            }

            return branches;
        }

        public static string GetAutomaticPriceStringValue(string variable)
        {
            decimal? priceValue = GetAutomaticPriceDecimalValue(variable);
            if (false == priceValue.HasValue)
            {
                return "";
            }

            return Common.GetPriceString(priceValue.Value);
        }

        public static decimal? GetAutomaticPriceDecimalValue(string variable)
        {
            //DwcContextUnit a = DwcContext.GetContext(DwcContextType.ArticleByVART);
            //if (a == null)
            //{
            //    return null;
            //}

            //ArticleException ae = null;
            //ArticleGTIN agtin = null;
            //int branch = Common.GetParamBranch();
            //Guid posGroup = ERPTools.GetPOSGroup(branch);
            //Guid? secondaryPosGroup = ERPTools.GetSecondaryPOSGroup(branch);

            //DwcContextUnit dcbs = DwcContext.GetContext(DwcContextType.ArticleBulkStream);
            //if (dcbs != null)
            //{
            //    ae =
            //        dcbs.ObjectAsArticleBulkStream.ArticleExceptionList.GetArticleException(
            //            a.ObjectAsArticleDescription.VART);
            //    if (agtin == null)
            //    {
            //        foreach (ArticleGTIN g in dcbs.ObjectAsArticleBulkStream.ArticleGTINList)
            //        {
            //            if (g.GTIN == a.ObjectAsArticleDescription.GTIN)
            //            {
            //                agtin = g;
            //                break;
            //            }
            //        }
            //    }
            //    if (agtin == null)
            //    {
            //        agtin = CSIClient.ArticleCache_GetGTIN(
            //            posGroup,
            //            secondaryPosGroup,
            //            a.ObjectAsArticleDescription.GTIN);
            //    }
            //}

            //if (ae == null)
            //{
            //    agtin = CSIClient.ArticleCache_GetGTIN(posGroup, secondaryPosGroup, a.ObjectAsArticleDescription.GTIN);
            //    if (agtin == null)
            //    {
            //        return null;
            //    }
            //    ae = CSIClient.ArticleCache_GetArticleException(agtin.RecUID, Common.GetParamBranch());
            //}

            //bool isAction = variable.StartsWith("Action");
            //object attributeValue = null;
            //DateTime now = DateTime.Now;
            //if (ae != null && agtin != null)
            //{
            //    attributeValue = ae.GetValue(variable);
            //    if (attributeValue == null)
            //    {
            //        attributeValue = "";
            //    }

            //    decimal attributeNumEx = 0;
            //    decimal.TryParse(attributeValue.ToString(), out attributeNumEx);
            //    bool isZeroEx = attributeNumEx == 0;
            //    if (attributeValue.ToString() != "")
            //    {
            //        if (isAction)
            //        {
            //            if ((!ae.ActionSince.HasValue || now >= ae.ActionSince.Value)
            //                && (!ae.ActionTill.HasValue || now <= ae.ActionTill.Value) && !isZeroEx)
            //            {
            //                return attributeNumEx;
            //            }
            //        }
            //        else
            //        {
            //            if (attributeValue.ToString() != "")
            //            {
            //                return attributeNumEx;
            //            }
            //        }
            //    }
            //}

            //attributeValue = agtin.GetValue(variable);
            //if (attributeValue == null)
            //{
            //    attributeValue = "";
            //}

            //decimal attributeNum = 0;
            //decimal.TryParse(attributeValue.ToString(), out attributeNum);
            //bool isZero = attributeNum == 0;
            //if (attributeValue.ToString() != "" && attributeValue.GetType() != typeof(DRS.Common.ERP.ValueNameUndefined))
            //{
            //    if (isAction)
            //    {
            //        if ((agtin.ActionSince == DateTime.MinValue || now >= agtin.ActionSince)
            //            && (agtin.ActionTill == DateTime.MinValue || now <= agtin.ActionTill) && !isZero)
            //        {
            //            return attributeNum;
            //        }
            //        else
            //        {
            //            return null;
            //        }
            //    }
            //    else
            //    {
            //        return attributeNum;
            //    }
            //}

            return null;
        }

        public static string StockInfo(string formulaID, int[] branches, string gtin)
        {
            //DwcContextUnit u = DwcContext.GetContext(DwcContextType.ArticleByVART);

            ////TPOMM.Tools.Log.Logger.Static.GetContext().Log("MultipleItemsCASE StockInfo_formula: {0} branches: {1} gtin: {2}", formulaID, branches.ToString(), gtin);
            //DwcSettingsBase.InitializeDocumentTools();
            //string units =
            //    DocumentTools.MeasurementUnits.GetUnitTextByElementID(u.ObjectAsArticleDescription.MeasurementUnits);

            //int decimalPlaces =
            //    DocumentTools.MeasurementUnits.GetUnitByID(u.ObjectAsArticleDescription.MeasurementUnits).DecimalPlaces;

            //bool fromOwnBranch = false;
            //if (branches == null)
            //{
            //    branches = new int[] { Common.GetParamBranch() };
            //    fromOwnBranch = true;
            //}

            //bool expanded = false;
            //branches = Common.ExpandBranchesAccordingToSumGroup(branches, out expanded);
            //if (expanded)
            //{
            //    // This can be later removed when we add condition to sum branches in BulkStream
            //    fromOwnBranch = false;
            //}

            //DwcContextUnit dcu = DwcContext.GetContext(DwcContextType.ArticleByVART);
            //if (dcu == null)
            //{
            //    return "?" + "&nbsp;" + units;
            //}

            //// First check article bulk stream
            //CASEArticleStockInfo[] casi = null;
            //DwcContextUnit dcbs = DwcContext.GetContext(DwcContextType.ArticleBulkStream);
            //if (dcbs != null && string.IsNullOrEmpty(formulaID) && fromOwnBranch)
            //{
            //    /*there is only basic formula and own branch in bulkstream*/
            //    casi = dcbs.ObjectAsArticleBulkStream.ArticleStockInfoList.StockInfoList.ToArray();
            //}

            //if (casi == null)
            //{
            //    casi = CSIClient.GetArticleStockInfo(
            //        dcu.ObjectAsArticleDescription.VART,
            //        branches,
            //        formulaID,
            //        0,
            //        DateTime.Now);
            //}

            //if (casi != null)
            //{
            //    double sum = 0;
            //    foreach (CASEArticleStockInfo c in casi)
            //    {
            //        bool found = false;
            //        foreach (int b in branches)
            //        {
            //            if (c.Branch == b)
            //            {
            //                found = true;
            //                break;
            //            }
            //        }

            //        if (false == found)
            //        {
            //            continue;
            //        }

            //        if (string.IsNullOrEmpty(gtin))
            //        {
            //            if (c.VART.ToLower() == u.ObjectAsArticleDescription.VART.ToLower())
            //            {
            //                sum += c.Quantity;
            //            }
            //        }
            //        else
            //        {
            //            Guid posGroup = ERPTools.GetPOSGroup(c.Branch);
            //            Guid? secPOSGroup = ERPTools.GetSecondaryPOSGroup(c.Branch);
            //            ArticleGTIN articleGtin = CSIClient.ArticleCache_GetGTIN(
            //                posGroup,
            //                secPOSGroup,
            //                c.VART,
            //                c.vi1,
            //                c.vi2);
            //            if (articleGtin != null && gtin == articleGtin.GTIN)
            //            {
            //                sum += c.Quantity;
            //            }
            //        }
            //    }
            //    if (u.ObjectAsArticleDescription.MeasurementUnits == 1)
            //    {

            //    }
            //    return string.Format(
            //        @"{0:N" + decimalPlaces + @"}",(decimal)sum) + "&nbsp;" + units;
            //}

            //return "?" + "&nbsp;" + units;
            return string.Empty;
        }

        public static object ProcessParam(VarParam param, ref bool error)
        {
            if (param.Var.EndsWith("_lng"))
            {
                VarParam p = new VarParam();

                p.DataType = param.DataType;
                p.VarGroup = param.VarGroup;
                p.Var = param.Var + "(" + Common.GetParamLanguageCode() + ")";
                p.Value = param.Value;

                object o = ProcessParam(p, ref error);
                if (!string.IsNullOrEmpty((string)o))
                {
                    return o;
                }
            }

            if (param.Var == "Picture")
            {
                error = false;
                return ArticlePictureElement(param);
            }

            if (param.Var == "Ordered")
            {
                error = false;
                //DwcContextUnit dc = DwcContext.GetContext(DwcContextType.ArticleByVART);
                //IReplanishmentOrderService service = new ReplanishmentOrderService();
                //ISetDataService sservice = new DwcSetDatasourceService();
                //if (dc != null && sservice.IsHeaderSetByVartAndGTIN(
                //    dc.ObjectAsArticleDescription.VART,
                //    dc.ObjectAsArticleDescription.GTIN))
                //{
                //    return string.Empty;
                //}
                //if (dc == null)
                //{
                //    return string.Empty;
                //}
                //ArticleVART vv = CSIClient.ArticleCache_GetVART(dc.ObjectAsArticleDescription.VART);
                //if (vv.IsService)
                //{
                //    return string.Empty;
                //}


                //return service.GetOrdered(null,null);
                return string.Empty;
            }

            if (param.Var == "Set")
            {
                /*DwcContextUnit dc = DwcContext.GetContext(DwcContextType.ArticleByVART);
                if (dc != null)
                {
                    ISetDataService service = new DwcSetDatasourceService();
                    if (service.IsArticleInSetByVart(dc.ObjectAsArticleDescription.VART, dc.ObjectAsArticleDescription.GTIN))
                    {
                        error = false;
                        return "javascript:showSetPopup(\'" + dc.ObjectAsArticleDescription.VART  + "\',\'" + dc.ObjectAsArticleDescription.Text + "\') ";
                    }
                }*/
                return string.Empty;
            }

            if (param.Var == "PictureNoLogin")
            {
                error = false;
                return ArticlePictureElement(param,true);
            }

            if (param.Var == "GTIN" && Common.GetUrlParameterAsString("newean","0") == "1") {
                error = false;
                return "";
            }

            if (param.Var == "FutureVART")
            {
                error = false;
                //return DwcArticleTools.GetNewFreeVART(null, false);
                return string.Empty;
            }

            //DwcContextUnit a = DwcContext.GetContext(DwcContextType.ArticleByVART);
            //if (a != null) {

            //    if (param.Var.StartsWith("Shelf")) {
            //        int branch = Common.GetParamBranch();

            //        DwcContextUnit dcbs = DwcContext.GetContext(DwcContextType.ArticleBulkStream);
            //        CASEArticleStockPositionInfoList sourceList = null;
            //        if ( dcbs != null ) {
            //            sourceList = dcbs.ObjectAsArticleBulkStream.ArticleStockPositionList;
            //        } else {
            //            sourceList = CSIClient.GetArticlePositionInfo(a.ObjectAsArticleDescription.VART, a.ObjectAsArticleDescription.VART, null, ERPTools.GetPOSGroup(Common.GetParamBranch()), "TextValue");
            //        }

            //        foreach(CASEArticleStockPositionInfo i in sourceList.List) {
            //            if ( i.VART.ToLower() == a.ObjectAsArticleDescription.VART.ToLower() ) {
            //                foreach( CASEArticleStockPositionBranch b in i.Positions ) {
            //                    if (  b.PositionID.ToLower() == param.Var.ToLower() && b.Branch == branch ) {
            //                        error = false;
            //                        return b.Position;
            //                    }
            //                }
            //            }
            //        }

            //        error = false;
            //        return "";
            //    }

            //    if (param.Var == "StockInfo")
            //    {
            //        error = false;
            //        ISetDataService data = new DwcSetDatasourceService();
            //        string f = param.GetAttributeValue("formulaID");
            //        string b = param.GetAttributeValue("branches");
            //        string gtin = param.GetAttributeValue("gtin");
            //        if (string.IsNullOrEmpty(gtin))
            //        {
            //            gtin = a.ObjectAsArticleDescription.GTIN;
            //        }
            //        int[] branches = ParseStockInfoBranches(b) ?? new[] { Common.GetParamBranch() };
            //        if (data.IsHeaderSetByVartAndGTIN(a.ObjectAsArticleDescription.VART,gtin))
            //        {
            //            return string.Empty;
            //        }
            //        else
            //        {
            //            try
            //            {
            //                ArticleVART aVart = CSIClient.ArticleCache_GetVART(a.ObjectAsArticleDescription.VART);
            //                if (aVart!=null && aVart.IsService)
            //                {
            //                    return string.Empty;
            //                }
            //                return StockInfo(f, branches, gtin);
            //            }
            //            catch (Exception)
            //            {
            //                return string.Empty;
            //            }

            //        }

            //    }

            //    if (param.Var == "AutomaticPrice") {
            //        error = false;
            //        string idx = param.GetAttributeValue("idx");
            //        if ( idx == "" ) {
            //            idx = "1";
            //        }
            //        object val = GetAutomaticPriceStringValue("ActionPrice" + idx);
            //        if (val.ToString() == "")
            //        {
            //            val = GetAutomaticPriceStringValue("RetailPrice" + idx);
            //        }
            //        else
            //        {
            //            val += " (A)";
            //        }
            //        return val.ToString();
            //    }

            //    if (param.Var == "PrintLink")
            //    {
            //        ArticleDescription g = a.ObjectAsArticleDescription;

            //        if (g != null)
            //        {
            //            error = false;
            //            return Common.SetUrlParams("../WEBSearch/ArticlePrintExport.ashx", new string[,] { { "gtin", g.GTIN }, { "amount", "1" } });
            //        }
            //        else
            //        {
            //            return "";
            //        }
            //    }
            //    if (a.ObjectAsArticleDescription == null) {
            //        error = true;
            //        return "CONFIGURATION ERROR: Invalid article.";
            //    }

            //    if (param.Var == "SetDetail")
            //    {
            //        DwcContextUnit dc = DwcContext.GetContext(DwcContextType.ArticleByVART);
            //        if (dc != null)
            //        {
            //            error = false;
            //            StringBuilder builder = new StringBuilder();
            //            ISetDataService service = new DwcSetDatasourceService();
            //            if (service.IsArticleInSetByVart(dc.ObjectAsArticleDescription.VART, dc.ObjectAsArticleDescription.GTIN))
            //            {
            //                IList<SetDTO> sets = service.GetSetsByVart(dc.ObjectAsArticleDescription.VART, dc.ObjectAsArticleDescription.GTIN);


            //                builder.Append("<div id='dwcMultipleItemsOrderContent1'><H3 id='mainTableHeader'> " + DwcLocale.Localize("{loc:drs.Articles.Relations}") + " </H3>");
            //                SetService.CreateTable("mainTableSets", sets, builder, false, true, "showSetDetail", false, "cursor:pointer");
            //                foreach (var set in sets)
            //                {
            //                    builder.Append("<H3 data-set-Header data-id=" + set.Id + set.CompositionType + "> Detail of: " + set.Name + "</H3>");
            //                    SetService.CreateTable(set.Id + set.CompositionType , set.ListOfArticlesInSet, builder, true, false, "showSetDetail", true, "");

            //                }
            //                builder.Append("</div>");
            //            }
            //            builder.AppendLine(@"<script type=""text/javascript"" >" + "showSetDetailHide();</script>");
            //            return builder.ToString();
            //        }
            //    }
            //    if (param.Var == "PackDetail")
            //    {
            //        DwcContextUnit dc = DwcContext.GetContext(DwcContextType.ArticleByVART);
            //        if (dc != null)
            //        {
            //            error = false;
            //            StringBuilder builder = new StringBuilder();
            //            ISetDataService service = new DwcSetDatasourceService();
            //            if (service.IsArticleInPackByVart(dc.ObjectAsArticleDescription.VART, dc.ObjectAsArticleDescription.GTIN))
            //            {
            //                IList<SetDTO> sets = service.GetSetsByVart(dc.ObjectAsArticleDescription.VART, dc.ObjectAsArticleDescription.GTIN);


            //                builder.Append("<div id='dwcMultipleItemsOrderContent1'><H3 id='mainTableHeader'> " + DwcLocale.Localize("{loc:drs.Articles.Relations}") + " </H3>");
            //                SetService.CreateTable("mainTablePack", sets, builder, false, true, "showPackDetail", false, "cursor:pointer");
            //                foreach (var set in sets)
            //                {
            //                    builder.Append("<H3 data-pack-Header data-id=" + set.Id + "> Detail of: " + set.Name + "</H3>");
            //                    SetService.CreateTable(set.Id + set.CompositionType, set.ListOfArticlesInSet, builder, true, false, "showPackDetail",true, "");
            //                }
            //                builder.Append("</div>");
            //            }
            //            builder.AppendLine(@"<script type=""text/javascript"" >" + "showSetDetailHide();</script>");
            //            return builder.ToString();
            //        }
            //    }

            //    if (param.Var == "StockInfoLink") {
            //        error = false;
            //        string vart = "";
            //        // In item context we show stock info for specified variant
            //        DwcContextUnit dcu = DwcContext.GetContext(DwcContextType.DocumentObjectItem);
            //        if ( dcu != null )
            //        {
            //            vart = dcu.ObjectAsDocumentObjectItem.VART;
            //        } else {
            //            vart = a.ObjectAsArticleDescription.VART;
            //        }

            //        string formulaID = param.GetAttributeValue("formulaID");
            //        string branches = param.GetAttributeValue("branches");
            //        return "javascript:dwcStockInfoPopup('" + vart + "','" + formulaID + "','" + branches + "');";
            //    }

            //    if (param.Var == "ArticleHistoryLink") {
            //        error = false;
            //        string vart = "";
            //        // In item context we show stock info for specified variant
            //        DwcContextUnit dcu = DwcContext.GetContext(DwcContextType.DocumentObjectItem);
            //        if ( dcu != null )
            //        {
            //            vart = dcu.ObjectAsDocumentObjectItem.VART;
            //        } else {
            //            vart = a.ObjectAsArticleDescription.VART;
            //        }

            //        return "javascript:dwcArticleHistoryPopup('" + vart + "');";
            //    }

            //    // Solution for IE image upload - in panel load temp variables back to form
            //    if (DwcPanel.CurrentPanelVariables != null && HttpContext.Current.Request.Url.AbsolutePath.ToLower().Contains("webpanel/panel.aspx"))
            //    {
            //        DatecWebClient.VarParam tempP = null;
            //        if (DwcPanel.CurrentPanelVariables.Params.TryGetValue(DwcTemplate.GetVarKey("", param.GroupAndVar), out tempP))
            //        {
            //            error = false;
            //            return Common.GetObjectString(tempP.Value);
            //        }
            //    }

            //    object res = a.ObjectAsArticleDescription.GetValue(param.Var);
            //    if(param.Var.Contains("BranchException"))
            //    {
            //        string help = param.Var.Replace("BranchException","");
            //        res = a.ObjectAsArticleDescription.GetValue(help, Common.GetParamBranch());
            //    }

            //    if (res is ValueNameUndefined || res == "")
            //    {
            //        ArticleGTIN agtin = null;
            //        DwcContextUnit dcbs = DwcContext.GetContext(DwcContextType.ArticleBulkStream);
            //        if ( dcbs != null ) {
            //            foreach( ArticleGTIN g in dcbs.ObjectAsArticleBulkStream.ArticleGTINList) {
            //                if (g != null)
            //                {
            //                    if (g.GTIN == a.ObjectAsArticleDescription.GTIN)
            //                    {
            //                        agtin = g;
            //                        break;
            //                    }
            //                }
            //            }
            //        }

            //        if ( agtin == null ) {
            //            agtin = CSIClient.ArticleCache_GetGTIN(a.ObjectAsArticleDescription.PosGroupRecUID, ERPTools.GetSecondaryPOSGroup(Common.GetParamBranch()), a.ObjectAsArticleDescription.GTIN);
            //        }
            //        if (agtin != null) {
            //            res = agtin.GetValue(param.Var);
            //            if (res is ValueNameUndefined) {
            //                error = false;
            //                return "";
            //            }

            //            error = false;
            //            return res;
            //        }

            //        error = false;
            //        return "";
            //    }
            //    else
            //    {
            //        error = false;
            //        return res;
            //    }
            //}

            //a = DwcContext.GetContext(DwcContextType.ArticleByGTIN);
            //if (a != null) {
            //    object res = a.ObjectAsArticleGTIN.GetValue(param.Var);
            //    if (!(res is ValueNameUndefined)) {
            //        error = false;
            //        return res;
            //    }
            //}

            error = true;
            return null;
        }
    }
}