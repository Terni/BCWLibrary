﻿using Expanded.VEngine.Interface;

namespace Expanded.VEngine
{
	public class ParamWithGroupProcessorArticle : ParamWithGroupProcessorBase, IParamWithGroupProcessor
	{
		public ParamWithGroupProcessorArticle(bool ignoreErrors)
			: base(ignoreErrors)
		{
		}

		public object ProcessParam(VarParam param, out bool error)
		{
			error = true;
			object res = VarEngineArticle.ProcessParam(param, ref error);
			if (false == error)
			{
				return res;
			}
			return ProcessParamBase(ref error);
		}
	}
}