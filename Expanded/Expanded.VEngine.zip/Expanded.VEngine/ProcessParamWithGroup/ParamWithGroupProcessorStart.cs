﻿//using DatecWebClient;

using System;
using Expanded.VEngine.Interface;

namespace Expanded.VEngine
{
	public class ParamWithGroupProcessorStart : ParamWithGroupProcessorBase, IParamWithGroupProcessor
	{
		public ParamWithGroupProcessorStart(bool ignoreErrors)
			: base(ignoreErrors)
		{
		}

		public object ProcessParam(VarParam param, out bool error)
		{
            //error = false;
            //int nodeId = -1;
            //int subNodeId = -1;
            //string[] spl = param.Var.Split('.');
            //nodeId = int.Parse(spl[0]);
            //if (spl.Length > 1)
            //{
            //	subNodeId = int.Parse(spl[1]);
            //}
            //return DwcMenuCore.NodeIdToUrl(nodeId, subNodeId, false);
            throw new NotImplementedException();
        }
	}
}