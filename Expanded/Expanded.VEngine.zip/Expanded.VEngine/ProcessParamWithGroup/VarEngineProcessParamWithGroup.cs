﻿//using DatecWebClient;

using Expanded.VEngine.Interface;

namespace Expanded.VEngine
{
	public static class DwcVarEngineProcessParamWithGroup
	{
		public static IParamWithGroupProcessor GetProcessor(string group, bool ignoreErrors)
		{
			//DwcContextUnit dcuNOR = DwcContext.GetContext(DwcContextType.NewObjectRender);
			//if (dcuNOR != null && dcuNOR.ObjectAsNewObjectRender)
			//{
			//	ignoreErrors = true;
			//}

			switch (group)
			{
				case "loc":
					{
						return new ParamWithGroupProcessorLoc(ignoreErrors);
					}
				case "document":
					{
						return new ParamWithGroupProcessorDocument(ignoreErrors);
					}
				case "header":
				case "footer":
					{
						return new ParamWithGroupProcessorHeaderFooter(ignoreErrors);
					}
				case "item":
					{
						return new ParamWithGroupProcessorItem(ignoreErrors);
					}
				case "common":
					{
						return new ParamWithGroupProcessorCommon(ignoreErrors);
					}
				case "device":
					{
						return new ParamWithGroupProcessorDevice(ignoreErrors);
					}
				case "article":
					{
						return new ParamWithGroupProcessorArticle(ignoreErrors);
					}
				case "contact":
					{
						return new ParamWithGroupProcessorContact(ignoreErrors);
					}
				case "start":
					{
						return new ParamWithGroupProcessorStart(ignoreErrors);
					}
				case "startasapp":
					{
						return new ParamWithGroupProcessorStartAsApp(ignoreErrors);
					}
				case "program":
					// inline user program
					{
						return new ParamWithGroupProcessorProgram(ignoreErrors);
					}
				case "programlink":
					// editable user program or with many data with filter
					{
						return new ParamWithGroupProcessorProgramLink(ignoreErrors);
					}
				case "userprograminput":
					{
						return new ParamWithGroupProcessorUserProgramInput(ignoreErrors);
					}
				case "userprogramtablerow":
					{
						return new ParamWithGroupProcessorUserProgramTableRow(ignoreErrors);
					}
				case "action":
					{
						return new ParamWithGroupProcessorAction(ignoreErrors);
					}
				//case "myspidero":
				//{
				//	return new ParamWithGroupProcessorMySpidero(ignoreErrors);
				//}
				case "reports":
					{
						return new ParamWithGroupProcessorReports(ignoreErrors);
					}
				case "global":
					{
						return new ParamWithGroupProcessorGlobal(ignoreErrors);
					}
				case "storyboard":
					{
						return new ParamWithGroupProcessorStoryboard(ignoreErrors);
					}
				case "template":
					{
						return new ParamWithGroupProcessorTemplate(ignoreErrors);
					}
				case "tmptable":
					{
						return new ParamWithGroupProcessorTmpTable(ignoreErrors);
					}
				case "startpoint":
					{
						return new ParamWithGroupProcessorStartPoint(ignoreErrors);
					}
				case "module":
					{
						return new ParamWithGroupProcessorModule(ignoreErrors);
					}
				default:
					{
						return new ParamWithGroupProcessorDefault(ignoreErrors);
					}
			}
		}
	}
}