﻿using System;
using Expanded.VEngine.Commons;
using Expanded.VEngine.Interface;

//using DRS.Common.ERP;
//using DatecWebClient;

namespace Expanded.VEngine
{
	public class ParamWithGroupProcessorCommon : ParamWithGroupProcessorBase, IParamWithGroupProcessor
	{
		public ParamWithGroupProcessorCommon(bool ignoreErrors)
			: base(ignoreErrors)
		{
		}

		public object ProcessParam(VarParam param, out bool error)
		{
			error = false;
			string paramVarTL = param.Var.ToLower();
			//User currUser = null;
			//DwcContextUnit u = DwcContext.GetContext(DwcContextType.User);
			//if (u != null)
			//{
			//	currUser = u.ObjectAsUser;
			//}

			//switch (paramVarTL)
			//{
			//	case "today":
			//		{
			//			return DateTime.Now.ToString("MM/dd/yyyy");
			//		}
			//	case "user":
			//	case "loggeduser":
			//	case "currentuser":
			//	case "currentusername":
			//		{
			//			return (currUser == null) ? "Guest" : currUser.LoginName;
			//		}
			//	case "branch":
			//		{
			//			return Common.GetParamBranch();
			//		}
			//	case "branchfordisplay":
			//		{
			//			return Common.GetParamBranchForDisplay();
			//		}
			//	case "password":
			//		{
			//			return (currUser == null) ? "" : currUser.Password;
			//		}
			//	case "language":
			//		{
			//			return Common.GetParamLanguageCode();
			//		}
			//	case "searchquery":
			//		{
			//			DwcContextUnit dcu = DwcContext.GetContext(DwcContextType.CurrentSearchQuery);
			//			if (dcu != null)
			//			{
			//				return dcu.ObjectAsCurrentSearchQuery;
			//			}
			//			return "";
			//		}
			//}
			return ProcessParamBase(ref error);
		}
	}
}