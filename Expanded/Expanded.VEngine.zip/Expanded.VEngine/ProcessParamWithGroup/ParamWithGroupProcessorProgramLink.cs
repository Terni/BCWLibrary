﻿//using DRS.Common.ERP;
//using DatecWebClient;

using System;
using Expanded.VEngine.Interface;

namespace Expanded.VEngine
{
	public class ParamWithGroupProcessorProgramLink : ParamWithGroupProcessorBase, IParamWithGroupProcessor
	{
		public ParamWithGroupProcessorProgramLink(bool ignoreErrors)
			: base(ignoreErrors)
		{
		}

		public object ProcessParam(VarParam param, out bool error)
		{
            //         error = false;
            //   string currencyAlign = string.Empty;
            //   if (param.ContainsAttribute("usenew"))
            //   {
            //             UserProgram up = DwcSettingsBase.UserProgramCollection.GetProgram(int.Parse(param.Var));
            //             if (up != null)
            //       {
            //           if (up.UserDialog.UserDialogFields.Count > 0)
            //           {
            //                     return "../UserProgram/UserProgramView?userProgram=" + param.Var + "&language=" + DwcCommon.GetParamLanguageCode() +
            //                         "&branch=" + DwcCommon.GetParamBranch() + "&deviceId=" + DwcCommon.GetParamDeviceId() + "&currencyAlign=" + currencyAlign 
            //                         + "#Dialog/" + param.Var;
            //                 }
            //       }

            //       return "../UserProgram/UserProgramView?userProgram=" + param.Var + "&language=" + DwcCommon.GetParamLanguageCode() +
            //                 "&branch=" + DwcCommon.GetParamBranch() + "&deviceId=" + DwcCommon.GetParamDeviceId() + "&currencyAlign=" + currencyAlign 
            //                + "#Table/" + param.Var;
            //         }
            //   int programId = 0;
            //string var = param.Var;
            //if (int.TryParse(var, out programId))
            //{
            //	UserProgram up = DwcSettingsBase.UserProgramCollection.GetProgram(programId);
            //	if (up != null)
            //	{
            //		error = false;
            //		DwcUserProgramContext.BindCurrentContext();
            //		DwcUserProgramContext.NeedShowInputDialogSet(up.RecID, true);
            //		DwcUserProgramContext.ResetAllConnections();
            //		DwcUserProgramContext.SetUserDataTableCache(up.RecID, null);
            //		DwcUserProgramContext.UserProgramInputParams.Params.Clear();
            //		DwcUserProgramContext.AutoFinishResultSet(DwcUserProgramAutoFinishResult.None);
            //		DwcUserProgramContext.SetSkipExecuteProgramSQL(up.RecID, false);

            //		string link = DwcCommon.SetUrlParams("../WEBSearch/UserSearch.aspx",
            //						new string[,] {
            //																									{"userProgramId", up.RecID.ToString()},
            //																									{"noSum", param.ContainsAttribute("nosum") ? "1" : "0"},
            //																									{"noFilter", param.ContainsAttribute("nofilter") ? "1" : "0"},
            //																									{"refreshMain", param.ContainsAttribute("refreshmain") ? "1" : "0"},
            //																									{"escapeUrl", param.ContainsAttribute("useescapeurl") ? DwcCommon.EscapeUrlToThisPage : null}
            //													});
            //		if (param.ContainsAttribute("popup"))
            //		{
            //			link += "&iframe=1";
            //			// NC MP // MSO
            //			link = DwcCommon.RemoveParameterFromUrl(link, "multipleItems");
            //			return "javascript:dwcUserProgramPopup(" + up.RecID.ToString() + ","
            //																							 + (param.ContainsAttribute("reloadafterclose") ? "1" : "0") + ","
            //																							 + (param.ContainsAttribute("popupwidth") ? ("&quot;" + param.GetAttributeValue("popupwidth") + "&quot;") : "-1") + ","
            //																							 + (param.ContainsAttribute("popupheight") ? ("&quot;" + param.GetAttributeValue("popupheight") + "&quot;") : "&quot;600px&quot;") + ","
            //																							 + "&quot;" + link + "&quot;)";
            //		}
            //		else
            //		{
            //			return link;
            //		}
            //	}
            //}

            //ReasonFailure = "UNKNOWN PROGRAM:" + programId;
            //return ProcessParamBase(ref error);
            throw new NotImplementedException();
        }
	}
}