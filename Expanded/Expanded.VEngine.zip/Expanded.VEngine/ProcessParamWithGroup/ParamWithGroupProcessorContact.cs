﻿using Expanded.VEngine.Interface;

namespace Expanded.VEngine
{
	public class ParamWithGroupProcessorContact : ParamWithGroupProcessorBase, IParamWithGroupProcessor
	{
		public ParamWithGroupProcessorContact(bool ignoreErrors)
			: base(ignoreErrors)
		{
		}

		public object ProcessParam(VarParam param, out bool error)
		{
			error = true;
			//object res = DwcVarEngineContact.ProcessParam(param, ref error);
			//if (false == error)
			//{
			//	return res;
			//}
			return ProcessParamBase(ref error);
		}
	}
}