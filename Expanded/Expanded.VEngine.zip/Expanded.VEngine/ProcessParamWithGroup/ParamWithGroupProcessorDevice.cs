﻿//using DRS.WEBClientCommon;
using Expanded.VEngine.Interface;

//using DatecWebClient;

namespace Expanded.VEngine
{
	public class ParamWithGroupProcessorDevice : ParamWithGroupProcessorBase, IParamWithGroupProcessor
	{
		public ParamWithGroupProcessorDevice(bool ignoreErrors)
			: base(ignoreErrors)
		{
		}

		public object ProcessParam(VarParam param, out bool error)
		{
			error = false;
			//WebClientDevice currDev = DwcSettingsBase.CurrentDeviceSettings;
			//WebClientDeviceVariable wcdv = null;
			//if (currDev.Variables.Variables.TryGetValue(param.Var, out wcdv))
			//{
			//	return wcdv.Value;
			//}
			return "";
		}
	}
}