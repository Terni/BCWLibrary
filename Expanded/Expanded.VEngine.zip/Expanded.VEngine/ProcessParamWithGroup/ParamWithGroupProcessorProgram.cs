﻿using System;
//using System.Data.SqlClient;
using System.Text;
using Expanded.VEngine.Interface;
using Expanded.VEngine.Template;

//using DRS.Common.ERP;

//using RV.Common;
//using DatecWebClient;

namespace Expanded.VEngine
{

	public class ParamWithGroupProcessorProgram : ParamWithGroupProcessorBase, IParamWithGroupProcessor
	{
        private VarEngine _varEngine = new VarEngine();

        public ParamWithGroupProcessorProgram(bool ignoreErrors)
			: base(ignoreErrors)
		{
		}

		public object ProcessParam(VarParam param, out bool error)
		{
            //error = true;
            //int programId = 0;
            //string var = param.Var;
            //if (int.TryParse(var, out programId))
            //{
            //    if (param.ContainsAttribute("usenew"))
            //    {
            //        error = false;
            //        return @"<iframe style=""width:100%"" src=""" + VarEngine.ProcessString("#ProgramLink:" + programId + @"(usenew)#") + @"""></iframe>";
            //    }
            //    else
            //    {
            //        UserProgram up = DwcSettingsBase.UserProgramCollection.GetProgram(programId);
            //        if (up != null)
            //        {
            //            error = false;
            //            string fixedGroup = ProcessParamGetFixedGroup();
            //            return ProcessUserProgram(up, fixedGroup, param, false);
            //        }
            //    }
            //}

            //ReasonFailure = "UNKNOWN PROGRAM:" + programId;
            //return ProcessParamBase(ref error);
            throw new NotImplementedException();
        }

		/*private string ProcessParamGetFixedGroup()
		{
			string fixedGroup = null;
			if (DwcContext.GetContext(DwcContextType.ArticleByVART) != null)
			{
				fixedGroup = "article";
			}
			else if (DwcContext.GetContext(DwcContextType.DocumentObject) != null)
			{
				fixedGroup = "header";
			}
			else if (DwcContext.GetContext(DwcContextType.Contact) != null)
			{
				fixedGroup = "contact";
			}
			return fixedGroup;
		}

		private string ProcessUserProgram(UserProgram up, string fixedGroup, VarParam optionalParam, bool quottedReplace)
		{
			string errorMessage = "";
			int resultCode = 0;

			string connString = DwcCommon.GetConnectionStringById(up.UserProgramSql.SqlConnectionStringID);

			SqlCommand comm = null;
			SqlDataReader rdr = null;

			string processedSQL = "";
			DwcUserProgramContext.ExecuteUserProgramSQL(ref comm, ref rdr, up.RecID, up.UserProgramSql.SqlCommand, connString, up.UserProgramSql.SqlCommandTimeout,
							fixedGroup, out errorMessage, out resultCode, quottedReplace, out processedSQL);

			// Add template derived from user program, if not already defined
			DwcTemplate.AddTemplate(up);
			bool res = resultCode == 0;

			string returnValue = ProcessUserProgramProcessReaderData(up, res, rdr, optionalParam, errorMessage, processedSQL);

			if (rdr != null)
			{
				rdr.Close();
				rdr.Dispose();
			}
			if (comm != null)
			{
				comm.Dispose();
			}

			if (DwcUserProgramContext.CurrentUserProgram != null)
			{
				if (!DwcUserProgramContext.CurrentUserProgram.UseSharedConnection)
				{
					SqlConnection conn;

					conn = DwcUserProgramContext.GetConnection(connString);

					if (conn != null)
					{
						conn.Close();
						conn.Dispose();
						conn = null;
					}
				}
			}
			return returnValue;
		}

		private string ProcessUserProgramProcessReaderData(UserProgram up, bool res, SqlDataReader rdr, VarParam optionalParam, string errorMessage, string processedSQL)
		{
			string returnValue = "";
			try
			{
				bool read = (rdr == null) ? false : rdr.Read();
				if (res && (rdr != null) && (read || (up.UserProgramSql.Editable)))
				{
					DatecWebClient.TemplateUnit tu = ETemplate.GetTemplate(ETemplate.GetUserProgramTemplateKey(up));

					// This way we process only one-column attributes
					if (optionalParam != null && optionalParam.ContainsAttribute("notable"))
					{
						returnValue = ProcessUserProgramNoTable(rdr, tu);
					}
					else
					{
						returnValue = ProcessUserProgramTable(rdr, tu, up);
					}
				}
				else if (res && (!RV.Common.CStringEx.IsEmpty(up.SuccessMessage)))
				{
					returnValue = _varEngine.ProcessString(up.SuccessMessage);
				}
				if (!res && (!RV.Common.CStringEx.IsEmpty(up.FailedMessage)))
				{
					returnValue = _varEngine.ProcessString(up.FailedMessage) + ": " + errorMessage;
				}
			}
			catch (Exception ex)
			{
                //TPOMM.Tools.Log.Logger.Static.GetContext().Log("UserProgramSQLError UserProgramId: {0} Command: {1}",up.RecID,processedSQL);
                returnValue = _varEngine.ProcessString(up.FailedMessage) + ": " + ex.Message;
			}
			return returnValue;
		}

		private string ProcessUserProgramTable(SqlDataReader rdr, DatecWebClient.TemplateUnit tu, UserProgram up)
		{
			StringBuilder bld = new StringBuilder();
			if (rdr != null)
			{
				int rowNum = 1;
				DwcContext.SetContext(DwcContextType.TableRender, true);
				DwcContext.SetContext(DwcContextType.UserProgram, up);

				bld.AppendLine(@"<div class=""outer-center"">");
				bld.AppendLine(@"<div class=""inner-center"">");
				bld.AppendLine(DwcSearchCore.UserProgramPDFPrintButton);
				//sb.Append(DwcSearchCore.UserProgramExcelPrintButton);
				bld.AppendLine("</div>");
				bld.AppendLine("</div>");
				bld.AppendLine(@"<div class=""clear""></div>");

				bld.AppendLine(DwcTable.RenderStartTableTag(null, "width:100%", DwcTable.TableRenderMode.reflow));
				bld.AppendLine(DwcTable.RenderStartHeaderTag());
				bld.AppendLine(DwcTemplate.RenderReaderTableHeader(rdr, tu, null));
				bld.AppendLine(DwcTable.RenderEndHeaderTag());
				bld.AppendLine(DwcTable.RenderStartBodyTag());

				do
				{
					bld.AppendLine(DwcTemplate.RenderReaderTableRow(rdr, tu, 0, null, rowNum, true));
					rowNum++;
				} while (rdr.Read());
				bld.AppendLine(DwcTable.RenderEndBodyTag());
				bld.AppendLine(DwcTable.RenderEndTableTag());
			}
			return bld.ToString();
		}

		private string ProcessUserProgramNoTable(SqlDataReader rdr, DatecWebClient.TemplateUnit tu)
		{
			StringBuilder bld = new StringBuilder();
			if (rdr != null)
			{
				bool isFirst = true;
				do
				{
					if (false == isFirst)
					{
						bld.Append(@", ");
					}
					else
					{
						isFirst = false;
					}

					WebClientTemplateColumn tc = tu.GetColumnByName(rdr.GetName(0));
					DisplayValueTypes dvt = ETemplate.GetDisplayValueType(rdr[0]);
					if (tc != null)
					{
						dvt = tc.DataType;
					}
					if (tc != null)
					{
						bld.Append(ETemplate.RenderOneVar(rdr[0], null, tu, tc, 0, true, false, 0));
					}
					else
					{
						bld.Append(DwcCommon.GetObjectString(rdr[0]));
					}
				} while (rdr.Read());
			}
			return bld.ToString();
		}*/
	}
}