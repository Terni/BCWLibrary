﻿//using DRS.WEBClientCommon;
using Expanded.VEngine.Interface;
using System;

//using DatecWebClient;

namespace Expanded.VEngine
{
	public class ParamWithGroupProcessorModule : ParamWithGroupProcessorBase, IParamWithGroupProcessor
	{
		private class ProcessParamParameter
		{
			public bool IsPopup
			{
				get;
				set;
			}

			public bool IsNew
			{
				get;
				set;
			}

			public bool ContextAssigned
			{
				get;
				set;
			}

			public string VarValue
			{
				get;
				set;
			}

			public string VarIdentificator
			{
				get;
				set;
			}

			//public WebClientModuleType ModuleType
			//{
			//	get;
			//	set;
			//}

			public int? ModuleId
			{
				get;
				set;
			}
		}

		public ParamWithGroupProcessorModule(bool ignoreErrors)
			: base(ignoreErrors)
		{
		}

		public object ProcessParam(VarParam param, out bool error)
		{
			//error = true;
			//ProcessParamParameter processParamParameter = GetProcessParamParameter(param);
			//if (processParamParameter.ModuleId.HasValue)
			//{
			//	if (!processParamParameter.ContextAssigned && !processParamParameter.IsNew)
			//	{
			//		return "#";
			//	}
			//	// Don't allow to create new element in booked document
			//	DwcContextUnit contextUnit = DwcContext.GetContext(DwcContextType.DocumentControlsReadOnly);
			//	if (processParamParameter.IsNew && contextUnit != null && contextUnit.ObjectAsDocumentControlsReadOnly)
			//	{
			//		return "#";
			//	}
			//	error = false;
			//	if (processParamParameter.IsNew)
			//	{
			//		object returnValue = ProcessParamIsNew(param, processParamParameter.ModuleType, processParamParameter.ModuleId.Value);
			//		if (returnValue != null)
			//		{
			//			return returnValue;
			//		}
			//	}
			//	else
			//	{
			//		if (processParamParameter.IsPopup)
			//		{
			//			return ProcessParamIsPopup(processParamParameter.ModuleId.Value, processParamParameter.VarIdentificator, processParamParameter.VarValue);
			//		}
			//		else
			//		{
			//			return ProcessParamNotPopupNotNew(param, processParamParameter);
			//		}
			//	}
			//}

			//ReasonFailure = "UNKNOWN MODULE:" + param.Var;

			//return ProcessParamBase(ref error);
            throw new NotImplementedException();
        }

		/*private object ProcessParamNotPopupNotNew(VarParam param, ProcessParamParameter processParamParameter)
		{
			if (processParamParameter.ModuleType == WebClientModuleType.ArticlePanel
			|| processParamParameter.ModuleType == WebClientModuleType.ContactPanel)
			{
				if (param.ContainsAttribute("newean"))
				{
					return DwcCommon.SetUrlParams("../WEBPanel/Panel.aspx",
											new string[,] {
																												{"moduleId",processParamParameter.ModuleId.ToString()},
																												{processParamParameter.VarIdentificator, processParamParameter.VarValue},
																												{"newean", "1"},
																												{"escapeUrl", null}});
				}

				return DwcCommon.SetUrlParams("../WEBPanel/Panel.aspx",
														new string[,] {
																												{"moduleId", processParamParameter.ModuleId.ToString()},
																												{processParamParameter.VarIdentificator, processParamParameter.VarValue},
																												{"escapeUrl", null}});

			}
			else if (processParamParameter.ModuleType == WebClientModuleType.ArticleSearch)
			{
				return DwcCommon.SetUrlParams("../WEBSearch/ArticleSearch.aspx",
												new string[,] {
																																		{"moduleId", processParamParameter.ModuleId.ToString()},
																																		{"escapeUrl", DwcCommon.EscapeUrlToThisPage}
														});
			}
			else if (processParamParameter.ModuleType == WebClientModuleType.ContactSearch)
			{
				return DwcCommon.SetUrlParams("../WEBSearch/ContactSearch.aspx",
												new string[,] {
																																		{"moduleId", processParamParameter.ModuleId.ToString()},
																																		{"escapeUrl", DwcCommon.EscapeUrlToThisPage}
														});
			}

			// Storyboard - Do not stack escape urls on panel
			string escapeURL = DwcCommon.GetUrlParameterAsString("escapeUrl", "");
			if (escapeURL == "")
			{
				escapeURL = DwcCommon.EscapeUrlToThisPage;
			}
			return DwcCommon.SetUrlParams("../WEBPanel/Panel.aspx",
													new string[,] {
																												{"moduleId", processParamParameter.ModuleId.ToString()},
																												{processParamParameter.VarIdentificator, processParamParameter.VarValue},
																												{"escapeUrl", escapeURL}});
		}

		private object ProcessParamIsPopup(int moduleId, string varIdentificator, string varValue)
		{
			DwcModuleUnit dmu = DwcModule.GetModule(moduleId);
			if (dmu != null)
			{
				WebClientSubModule wcsm = DwcModule.GetSubModule(dmu);
				if (wcsm != null)
				{
					return "javascript:dwcTemplatePopup('" + wcsm.TemplateForPage + "','" +
							varIdentificator + "','" + varValue + "');";
				}
			}
			return "#";
		}

		private ProcessParamParameter GetProcessParamParameter(VarParam param)
		{
			ProcessParamParameter returnValue = new ProcessParamParameter();

			int moduleId = 0;
			string var = param.Var;

			if (int.TryParse(var, out moduleId))
			{
				DwcModuleUnit moduleUnit = DwcModule.GetModule(moduleId);
				if (moduleUnit != null)
				{
					returnValue.IsNew = param.ContainsAttribute("new");
					returnValue.IsPopup = param.ContainsAttribute("popup");
					returnValue.ModuleType = moduleUnit.Module.ModuleType;
					returnValue.ModuleId = moduleUnit.Module.Id;

					// Article
					if (returnValue.ModuleType == WebClientModuleType.ArticlePanel)
					{
						returnValue.VarIdentificator = "VART";
						DwcContextUnit contextUnit = DwcContext.GetContext(DwcContextType.ArticleByVART);
						if (contextUnit != null)
						{
							returnValue.VarValue = contextUnit.ObjectAsArticleDescription.VART;
							returnValue.ContextAssigned = true;
						}
					}
					// Contact
					else if (returnValue.ModuleType == WebClientModuleType.ContactPanel)
					{
						returnValue.VarIdentificator = "contactNumber";
						DwcContextUnit contextUnit = DwcContext.GetContext(DwcContextType.Contact);
						if (contextUnit != null)
						{
							returnValue.VarValue = contextUnit.ObjectAsContact.ToString();
							if (returnValue.VarValue != "0")
							{
								returnValue.ContextAssigned = true;
							}
						}
					}
					// Other
					if (string.IsNullOrEmpty(returnValue.VarIdentificator))
					{
						returnValue.ContextAssigned = true;
					}
				}
			}

			return returnValue;
		}

		private object ProcessParamIsNew(VarParam param, WebClientModuleType moduleType, int moduleId)
		{
			if (moduleType == WebClientModuleType.ContactPanel)
			{
				// new Contact panel
				string contactType = DwcCommon.GetUrlParameterAsString("contactType", "1");
				if (param.ContainsAttribute("contacttype"))
				{
					contactType = param.GetAttributeValue("contacttype");
				}

				if (param.ContainsAttribute("owncompanyonly"))
				{
					return DwcCommon.SetUrlParams("../WEBPanel/Panel.aspx",
							new string[,] {
																						{"moduleId", moduleId.ToString()},
																						{"ownCompanyOnly", "1"},
																						{"contactType", contactType},
																						{"new", "1"},
																						{"escapeUrl", null}}); // Clear escape url in contact and article panels
				}
				else
				{

					return DwcCommon.SetUrlParams("../WEBPanel/Panel.aspx",
							new string[,] {
																						{"moduleId", moduleId.ToString()},
																						{"contactType", contactType},
																						{"new", "1"},
																						{"escapeUrl", null}});
				}
			}
			else if (moduleType == WebClientModuleType.ArticlePanel)
			{
				// new article panel
				return DwcCommon.SetUrlParams("../WEBPanel/Panel.aspx",
						new string[,] {
																						{"moduleId", moduleId.ToString()},
																						{"new", "1"},
																						{"escapeUrl", null}});
			}

			return null;
		}*/
	}
}