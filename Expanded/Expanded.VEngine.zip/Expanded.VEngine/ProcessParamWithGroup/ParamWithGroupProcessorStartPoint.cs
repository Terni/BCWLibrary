﻿//using DatecWebClient;

using System;
using Expanded.VEngine.Commons;
using Expanded.VEngine.Interface;

namespace Expanded.VEngine
{
	public class ParamWithGroupProcessorStartPoint : ParamWithGroupProcessorBase, IParamWithGroupProcessor
	{
		public ParamWithGroupProcessorStartPoint(bool ignoreErrors)
			: base(ignoreErrors)
		{
		}

		public object ProcessParam(VarParam param, out bool error)
		{
            //error = false;
            //return Common.GetUrlFromStartPointID(param.Var);
            throw new NotImplementedException();
        }
	}
}