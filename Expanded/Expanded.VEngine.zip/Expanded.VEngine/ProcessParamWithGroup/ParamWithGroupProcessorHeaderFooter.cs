﻿using System;
using System.Collections;
//using System.Data;

//using DRS.CASE.Interface;
using Expanded.VEngine.Interface;

//using DRS.Common.ERP;

//using RV.Common;
//using DatecWebClient;

namespace Expanded.VEngine
{
	public class ParamWithGroupProcessorHeaderFooter : ParamWithGroupProcessorBase, IParamWithGroupProcessor
	{
		private const string CONTACT_ADDRESSES_COMBO = "DWC_CONTACT_ADDRESSES_COMBO";

		public ParamWithGroupProcessorHeaderFooter(bool ignoreErrors)
			: base(ignoreErrors)
		{
		}

		public object ProcessParam(VarParam param, out bool error)
		{
            //error = true;
            //DwcContextUnit contextUnit = DwcContext.GetContext(DwcContextType.DocumentSearchDRSStyleRow);
            //if (contextUnit != null)
            //{
            //	// LSK - here we read data from document search DRS data table to display
            //	// Get column settings
            //	DocumentsBrowserColumn col = GetDocumentsBrowserColumnAndModifyVarParam(ref param);

            //	IDataReader dataReader = contextUnit.ObjectAsDocumentSearchDRSStyleRow;
            //	bool hasColumn = false;
            //	for (int i = 0; i < dataReader.FieldCount; i++)
            //	{
            //		if (dataReader.GetName(i).Equals(param.Var, StringComparison.InvariantCultureIgnoreCase))
            //		{
            //			hasColumn = true;
            //			break;
            //		}
            //	}


            //             // Load contact address
            //             if (hasColumn)
            //             {
            //                 object value = dataReader[param.Var];
            //                 if (param.Var.ToLower() == "contactaddressid" && false == Convert.IsDBNull(value))
            //                 {
            //                     if (DwcCache.PerRequestContextStorage[CONTACT_ADDRESSES_COMBO] == null)
            //                     {
            //                         CASEContactAddressComboColletion addresses = CSIClient.CRMContactCache_GetAllAddresses();
            //                         Hashtable htbl = new Hashtable();
            //                         foreach (CASEContactAddressComboElement e in addresses.Elements)
            //                         {
            //                             htbl[e.RecUID] = e;
            //                         }
            //                         DwcCache.PerRequestContextStorage[CONTACT_ADDRESSES_COMBO] = htbl;
            //                     }

            //                     Hashtable cachedHtbl = (Hashtable)DwcCache.PerRequestContextStorage[CONTACT_ADDRESSES_COMBO];
            //                     CASEContactAddressComboElement cachedEl = (CASEContactAddressComboElement)cachedHtbl[(Guid)value];
            //                     if (cachedEl != null)
            //                     {
            //                         value = cachedEl.Text;
            //                     }
            //                 }

            //                 error = false;
            //                 string displayStr = DwcTemplate.RenderOneVar(value, ConvertTypes.ConvertToVarParamBack(param), null, null, null, col.DataSource, false, true, false, null, 0, null, true, col.ValueType, null, false, 0);
            //                 return displayStr;
            //             }			
            //             else
            //             {
            //                 return "unknown value";
            //             }				
            //}
            //else
            //{
            //	contextUnit = DwcContext.GetContext(DwcContextType.DocumentObject);
            //	if (contextUnit != null)
            //	{
            //		error = false;
            //		return contextUnit.ObjectAsDocumentObject.GetValue(param.Var);
            //	}
            //}
            //return ProcessParamBase(ref error);

            throw new NotImplementedException();

        }

        /*private DocumentsBrowserColumn GetDocumentsBrowserColumnAndModifyVarParam(ref VarParam varParam)
		{
			DocumentsBrowserColumn documentBrowserColumn = null;
			string varParamTL = varParam.Var.ToLower();

            // Rename some columns, they are stored with different name - thank you, thank you thank you, you're far too kind....
            switch (varParamTL)
            {
                case "contact":
                    {
                        varParam.Var = "ContactID";
                        break;
                    }
                case "contactaddress":
                    {
                        varParam.Var = "ContactAddressID";
                        break;
                    }
                case "creator":
                    {
                        varParam.Var = "DocumentCreator";
                        break;
                    }
                case "dealer":
                    {
                        varParam.Var = "DocumentDealer";
                        break;
                    }
                case "pairedtext":
                    {
                        varParam.Var = "Paired";
                        break;
                    }
                case "documenttime":
                    {
                        varParam.Var = "RecCreated";
                        varParamTL = "reccreated";
                        break;
                    }
            }

            foreach (DocumentsBrowserColumn c in DwcSettingsBase.DocumentBrowserColumnCollection.GetSortedColumnsByOrder())
			{
				if (c.FixedColumn.ToString().ToLower() == varParamTL)
				{
					documentBrowserColumn = c;
					break;
				}
			}

			// Setup some default columns
			switch (varParam.Var.ToLower())
			{
				case "paired":
					{
						documentBrowserColumn.ValueType = DisplayValueTypes.Enum;
						documentBrowserColumn.DataSource = "DwcPairedDataSource";
						break;
					}
				case "contactid":
					{
						documentBrowserColumn.ValueType = DisplayValueTypes.Enum;
						documentBrowserColumn.DataSource = "Contacts";
						break;
					}
				case "branch":
				case "branchsecond":
					{
						documentBrowserColumn.ValueType = DisplayValueTypes.Enum;
						documentBrowserColumn.DataSource = "Branches";
						break;
					}
				case "totalpricewithvat":
				case "totalpricewithoutvat":
					{
						documentBrowserColumn.ValueType = DisplayValueTypes.Currency;
						break;
					}
			}
			return documentBrowserColumn;
		}*/
    }

}