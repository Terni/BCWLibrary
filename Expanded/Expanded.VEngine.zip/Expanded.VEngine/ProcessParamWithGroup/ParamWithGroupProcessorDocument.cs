﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Expanded.VEngine.Interface;

//using DRS.Common.ERP;
//using DatecWebClient;
//using RV.CF.Documents;
using Newtonsoft;

namespace Expanded.VEngine
{
	public class ParamWithGroupProcessorDocument : ParamWithGroupProcessorBase, IParamWithGroupProcessor
	{
		public ParamWithGroupProcessorDocument(bool ignoreErrors)
			: base(ignoreErrors)
		{
		}

		public object ProcessParam(VarParam param, out bool error)
		{
			error = true;
			string paramVarTL = param.Var.ToLower();
			switch (paramVarTL)
			{
				//case "refererurl":
				//	{
				//		error = false;
				//		return DwcDocumentCore.RefererUrl;
				//	}
				//case "copylink":
				//	{
				//		object returnValue = ProcessParamCopyLink(param, out error);
				//		if (returnValue != null)
				//		{
				//			return returnValue;
				//		}
				//		break;
				//	}
				//case "takeoverlink":
				//	{
				//		object returnValue = ProcessParamTakeoverLink(out error);
				//		if (returnValue != null)
				//		{
				//			return returnValue;
				//		}
				//		break;
				//	}
				//case "openlink":
				//	{
				//		object returnValue = ProcessParamOpenLink(out error);
				//		if (returnValue != null)
				//		{
				//			return returnValue;
				//		}
				//		break;
				//	}
				//case "printlink":
				//	{
				//		object returnValue = ProcessParamPrintLink(out error);
				//		if (returnValue != null)
				//		{
				//			return returnValue;
				//		}
				//		break;
				//	}
				case "takeoverallitems":
					{
						error = false;
						return "javascript:documentTakeoverAllItems()";
					}
                //case "documentattachments":
                //    {
                //        object returnValue = ProcessParamDocumentAttachmentsLink(out error);
                //        if (returnValue != null)
                //        {
                //            return returnValue;
                //        }
                //        break;
                //    }
                //case "countofattachments":
                //    {
                //        error = false;
                //        string returnValue = DatecWebClient.DwcDocumentCore.AttachmentsList.Count.ToString();
                //        if (returnValue != null)
                //        {
                //            return returnValue;
                //        }
                //        break;
                //    }
            }
			return ProcessParamBase(ref error);
		}

  //      private object ProcessParamDocumentAttachmentsLink(out bool error)
  //      {
  //          Document document = DwcDocumentBase.DocObject;
  //          if (document != null)
  //          {
  //              error = false;
  //              return DwcCommon.SetUrlParams("../WEBDocument/DocumentAttachments.aspx", new string[,]
  //              {
  //                  {"docEdit" , document.HeaderRecUID.ToString() },
  //                  {"docObject",null }
  //              });
  //          }
  //          error = true;
  //          return null;
  //      }

		//private object ProcessParamCopyLink(VarParam varParam, out bool error)
		//{
		//	DwcContextUnit d = DwcContext.GetContext(DwcContextType.DocumentObject);
		//	if (d != null)
		//	{
		//		Document doc = d.ObjectAsDocumentObject;

		//		if (varParam.Attributes.Count < 2)
		//		{
		//			error = !doc.IsBooked;
		//			Dictionary<string, string> docTypes = new Dictionary<string, string>();
		//			Document2DocumentRestrictionList list;
		//			StringBuilder sb = new StringBuilder();

		//			foreach (DocSettings ds in DwcSettingsBase.AllDocumentsSettings.DocSettings)
		//			{
		//				docTypes.Add((int)ds.DocType + "_" + ds.DocSubType, ds.Text);
		//			}

		//			list = Document2DocumentRestrictionList.FromSQL(ERPTools.CFConnectionString, DwcCommon.GetParamLanguageCode());

		//			foreach (Document2DocumentRestriction r in list.Doc2DocRestrictionList)
		//			{
		//				if (r.SourceDoc.DocType == doc.DocType && r.SourceDoc.DocSubType == doc.DocSubType)
		//				{
		//					docTypes.Clear();

		//					foreach (DocSettings ds in r.DestDocs)
		//					{
		//						docTypes.Add((int)ds.DocType + "_" + ds.DocSubType, ds.Text);
		//					}
		//				}
		//			}

		//			foreach (KeyValuePair<string, string> docType in docTypes)
		//			{
		//				sb.AppendLine(docType.Key + "_" + DwcLocale.Localize(docType.Value) + ";");
		//			}

		//			if (docTypes.Count < 1)
		//			{
		//				error = true;
		//			}
		//			else if (docTypes.Count == 1)
		//			{
		//				string[] s = docTypes.First().Key.Split('_');
		//				return DwcCommon.SetUrlParams("../WEBDocument/Document",
		//																			new string[,]
		//																			{
		//																							{"copyFromDoc", doc.HeaderRecUID.ToString()},
		//																							{"docType", s[0]},
		//																							{"docSubType", s[1]}
		//																			});
		//			}
		//			else
		//			{
		//				return "javascript:dwcChooseDestinationDoc('" + sb.ToString().Substring(0, sb.ToString().Length - 3) + "','" + doc.HeaderRecUID.ToString() + "')";
		//			}
		//		}
		//		else
		//		{
		//			error = !doc.IsBooked;
		//			string s1 = varParam.Attributes.Where(a => a.Key == "totype").FirstOrDefault().Value;
		//			string s2 = varParam.Attributes.Where(a => a.Key == "tosubtype").FirstOrDefault().Value;
		//			return DwcCommon.SetUrlParams("../WEBDocument/Document",
		//																		new string[,]
		//																		{
		//																						{"copyFromDoc", doc.HeaderRecUID.ToString()},
		//																						{"docType", s1},
		//																						{"docSubType", s2}
		//																		});
		//		}
		//	}
		//	error = true;
		//	return null;
		//}

		//private object ProcessParamTakeoverLink(out bool error)
		//{
		//	DwcContextUnit contextUnit = DwcContext.GetContext(DwcContextType.DocumentObject);
		//	if (contextUnit != null)
		//	{
		//		Guid guid = (Guid)contextUnit.ObjectAsDocumentObject.GetValue("HeaderRecUID");
		//		if (guid != null || guid != new Guid())
		//		{

		//			error = contextUnit.ObjectAsDocumentObject.IsBooked;

		//			if (contextUnit.ObjectAsDocumentObject.GetMemoItemDataValue("CheckAllItems").ToLower() == "true")
		//			{
		//				error = true;
		//			}

		//			if (DwcCommon.GetUrlParameterAsString("docObject", "") == "")
		//			{
		//				return "javascript:dwcTakeoverDialog('" + guid + "',false)";
		//			}
		//			else
		//			{
		//				return "javascript:dwcTakeoverDialog('" + guid + "',true)";
		//			}
		//		}
		//	}
		//	error = true;
		//	return null;
		//}

		//private object ProcessParamOpenLink(out bool error)
		//{
		//	Document document = DwcDocumentBase.DocObject;
		//	if (document != null)
		//	{
		//		error = false;
  //              string inventoryOpening = null;
  //              string inventoryInProcess = null;
  //              if (document.DocType == RV.Common.DocTypes.Inventory && document.DocStatus != DocStatus.Booked)
  //              {
  //                  inventoryOpening = "1";
  //                  List<InventoryTemplate> inl = InventoryTemplate.FromSQL(new int[] { DwcCommon.GetParamBranch() }, ERPTools.CFConnectionString, LanguagesInfo.GetLanguageRecUID(DwcCommon.GetParamLanguageCode()));
  //                  if (inl.Count > 0)
  //                  {
  //                      if (inl[0].Status == InventoryStatus.ReadOnly)
  //                      {
  //                          inventoryInProcess = "1";
  //                      }
  //                  }
  //              }
		//		return DwcCommon.SetUrlParams("../WEBDocument/Document",
		//																	new string[,] {
		//																					{"docEdit", document.HeaderRecUID.ToString()},
		//																					{"docObject", null},
  //                                                                                          {"inventoryOpening", inventoryOpening },
  //                                                                                          {"inventoryInProcess",inventoryInProcess }
		//																	});
		//	}
		//	error = true;
		//	return null;
		//}

		//private object ProcessParamPrintLink(out bool error)
		//{
		//	Document document = DwcDocumentBase.DocObject;
		//	if (document != null)
		//	{
		//		DocDeviceSettings settings = DwcDocumentBase.DeviceSettings;
		//		if (settings != null)
		//		{
		//			error = false;
  //                  string printToNewWindow = DwcDocumentBase.DeviceSettings.PrintToNewWindow ? "true" : "false";
  //                  return "javascript:printMultipleDocuments("+ printToNewWindow +");";
		//		}
		//	}
		//	error = true;
		//	return null;
		//}
	}
}