﻿using System.Linq;
using Expanded.VEngine.Commons;
using Expanded.VEngine.Interface;

//using DatecWebClient;

namespace Expanded.VEngine
{
	public class ParamWithGroupProcessorReports : ParamWithGroupProcessorBase, IParamWithGroupProcessor
	{
		public ParamWithGroupProcessorReports(bool ignoreErrors)
			: base(ignoreErrors)
		{
		}

		public object ProcessParam(VarParam param, out bool error)
		{
			error = true;
			string paramVarTL = param.Var.ToLower();

			//switch (paramVarTL)
			//{
			//	case "menu":
			//		{
			//			error = false;
			//			string currNode = "";
			//			DwcWebMenuNode dwmn = DwcMenuCore.CurrentNode;
			//			if (dwmn != null)
			//			{
			//				currNode = dwmn.Path;
			//			}
			//			return Common.SetUrlParams("../WEBReports/Reports.aspx", new string[,] { { "menu", currNode }, { "escapeUrl", DwcCommon.EscapeUrlToThisPage } });
			//		}
			//	case "folder":
			//		{
			//			DwcReportMenuNode f = DwcReportsCore.ReportFolders.FirstOrDefault(fo => fo._reportFolder.RecUID.ToString().ToLower() == param.Attributes[0].Key.ToLower());
			//			if (f != null)
			//			{
			//				error = false;
			//				return Common.SetUrlParams("../WEBReports/Reports.aspx", new string[,] { { "reportFolder", f.Id } });
			//			}
			//			return "";
			//		}
			//}
			return ProcessParamBase(ref error);
		}
	}
}