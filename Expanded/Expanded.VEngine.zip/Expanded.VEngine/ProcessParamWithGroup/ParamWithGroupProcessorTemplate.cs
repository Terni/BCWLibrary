﻿using System;
using Expanded.VEngine.Interface;
using Expanded.VEngine.Template;

namespace Expanded.VEngine
{
	public class ParamWithGroupProcessorTemplate : ParamWithGroupProcessorBase, IParamWithGroupProcessor
	{
		public ParamWithGroupProcessorTemplate(bool ignoreErrors)
			: base(ignoreErrors)
		{
		}

		public object ProcessParam(VarParam param, out bool error)
		{
            //error = true;
            //string var = param.Var;
            //int templateId = 0;
            //if (int.TryParse(var, out templateId))
            //{
            //	DatecWebClient.TemplateUnit dtu = ETemplate.GetTemplate(ETemplate.GetNormalTemplateKey(templateId));
            //	if (dtu != null)
            //	{
            //		error = false;
            //		return ETemplate.Render(dtu);
            //	}
            //}
            //return ProcessParamBase(ref error);
            throw new NotImplementedException();
        }
	}
}