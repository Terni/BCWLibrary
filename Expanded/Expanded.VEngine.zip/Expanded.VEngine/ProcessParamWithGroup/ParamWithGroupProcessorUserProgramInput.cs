﻿using System;
using System.Collections.Generic;
using Expanded.VEngine.Interface;

//using DatecWebClient;

namespace Expanded.VEngine
{
	public class ParamWithGroupProcessorUserProgramInput : ParamWithGroupProcessorBase, IParamWithGroupProcessor
	{
		public ParamWithGroupProcessorUserProgramInput(bool ignoreErrors)
			: base(ignoreErrors)
		{
		}


        private static VarParamCollection UserProgramInputParams
        {
            get
            {
                //return (VarParamCollection)DwcCache.GetPerUserProtectedCacheObject(DwcCacheObjectType.UserProgramInputParams,
                //    () => {
                //        return new VarParamCollection();
                //    });
                throw new NotImplementedException();
            }
        }

        public object ProcessParam(VarParam param, out bool error)
		{
			error = true;
			string paramVarTL = param.Var.ToLower();
			foreach (KeyValuePair<string, VarParam> p in UserProgramInputParams.Params)
			{
				if (p.Value.Var.ToLower() == paramVarTL)
				{
					error = false;
					// Setup correct data type to parameter
					param.DataType = p.Value.DataType;
					return FixUserProgramInput(p.Value);
				}
			}

			ReasonFailure = "UNKNOWN PARAMETER:" + param.GroupAndVar;
			return ProcessParamBase(ref error);
		}
	}
}