﻿using System;
using Expanded.VEngine.Interface;

namespace Expanded.VEngine
{
	public class ParamWithGroupProcessorStoryboard : ParamWithGroupProcessorBase, IParamWithGroupProcessor
	{
		public ParamWithGroupProcessorStoryboard(bool ignoreErrors)
			: base(ignoreErrors)
		{
		}

		public object ProcessParam(VarParam param, out bool error)
		{
            //error = true;
            //object res = DwcVarEngineStoryBoard.ProcessParam(param, ref error);
            //if (false == error)
            //{
            //	return res;
            //}
            //return ProcessParamBase(ref error);
            throw new NotImplementedException();
        }
	}
}