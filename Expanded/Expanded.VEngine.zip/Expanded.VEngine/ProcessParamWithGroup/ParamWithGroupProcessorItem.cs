﻿//using DRS.CASE.Interface;
//using DRS.Common.ERP;
//using RV.CF.Documents;
using System;
using Expanded.VEngine.Interface;
//using TP_OmniViewApp.Core.DwcAdvanceProcessCreation;
//using DatecWebClient;

namespace Expanded.VEngine
{
	public class ParamWithGroupProcessorItem : ParamWithGroupProcessorBase, IParamWithGroupProcessor
	{
		public ParamWithGroupProcessorItem(bool ignoreErrors)
			: base(ignoreErrors)
		{
		}

		public object ProcessParam(VarParam param, out bool error)
		{
            //error = true;

            //DwcContextUnit cui = DwcContext.GetContext(DwcContextType.DocumentObjectItem);
            //if (cui != null)
            //{
            //	var item = cui.ObjectAsDocumentObjectItem;
            //	var branch = DwcCommon.GetParamBranch();

            //	if (item != null)
            //	{
            //		error = false;
            //		if (param.Var == "StockInfo")
            //		{
            //			return GetStockInfo(item, branch);
            //		}
            //		else if (param.Var == "StockInfoRepl")
            //		{
            //			return GetStockInfoRepl(item, branch);
            //		}

            //		return item.GetValue(param.Var);
            //	}
            //}
            //return ProcessParamBase(ref error);
            throw new NotImplementedException();
        }

		/*private static object GetStockInfoRepl(Item item, int branch)
		{
			Document currentDoc = DwcDocumentBase.DocObject;
			DocumentStatusFormula statForm = null;
			string formula = "";
			if (currentDoc != null)
			{
				try
				{
					//DocSettingAffectedStatusCollection liststatuses = currentDoc.Settings.BookingStatuses;
					int deviceid = DwcCommon.GetParamDeviceId();
					statForm = ReplanishmentOrderService.GetStockFormula(DwcDocumentBase.DeviceSettings.FormulaForOrderedArticles);
					if (statForm != null)
						formula = statForm.Formula;
				}
				catch
				{

				}
			}

			CASEArticleStockInfo[] cas = CSIClient.GetArticleStockInfo(
				 item.VART,
				 new int[] { branch },
				 formula,
				 0,
				 DateTime.Now);

			Guid posGroup = ERPTools.GetPOSGroup(branch);
			Guid? secPosGroup = ERPTools.GetSecondaryPOSGroup(branch);
			ArticleGTIN abc = CSIClient.ArticleCache_GetGTIN(posGroup, secPosGroup, item.GTIN);

			CASEArticleStockInfo selected = null;
			for (int i = 0; i < cas.Length; i++)
			{
				CASEArticleStockInfo c = cas[i];
				if (c.vi1 == abc.VI1 && c.vi2 == abc.VI2 && c.vi3 == abc.VI3 && c.vi4 == abc.VI4 && c.vi5 == abc.VI5
						&& c.vi6 == abc.VI6)
				{
					selected = c;
					break;
				}
			}

			if (selected == null)
			{
				return 0d;
			}

			return selected.Quantity;
		}

		private static object GetStockInfo(RV.CF.Documents.Item item, int branch)
		{
			CASEArticleStockInfo[] cas = CSIClient.GetArticleStockInfo(item.VART, new int[] { branch }, "", 0, DateTime.Now);

			Guid posGroup = ERPTools.GetPOSGroup(branch);
			Guid? secPosGroup = ERPTools.GetSecondaryPOSGroup(branch);
			ArticleGTIN abc = CSIClient.ArticleCache_GetGTIN(posGroup, secPosGroup, item.GTIN);

			CASEArticleStockInfo selected = null;
			for (int i = 0; i < cas.Length; i++)
			{
				CASEArticleStockInfo c = cas[i];
				if (c.vi1 == abc.VI1 && c.vi2 == abc.VI2 && c.vi3 == abc.VI3 && c.vi4 == abc.VI4 && c.vi5 == abc.VI5
						&& c.vi6 == abc.VI6)
				{
					selected = c;
					break;
				}
			}

			if (selected == null)
			{
				return 0d;
			}

			return selected.Quantity;
		}*/
	}

}