﻿using System.Linq;
using Expanded.VEngine.Interface;
using Expanded.VEngine.Template;

//using DatecWebClient;

namespace Expanded.VEngine
{
	public class ParamWithGroupProcessorAction : ParamWithGroupProcessorBase, IParamWithGroupProcessor
	{
		public ParamWithGroupProcessorAction(bool ignoreErrors)
			: base(ignoreErrors)
		{
		}

		public object ProcessParam(VarParam param, out bool error)
		{
			error = true;
			string paramVarTL = param.Var.ToLower();
			if (ProcessParamCheckAttributesCount(paramVarTL, param.Attributes.Count))
			{
				switch (paramVarTL)
				{
					case "book":
						{
							error = false;
							return @"javascript:documentPageBookDocument();";
						}
					case "refreshinventory":
						{
							error = false;
							return @"javascript:documentPageRefreshInventory();";
						}
					case "reloadpage":
						{
							error = false;
							return @"javascript:location.reload()";
						}
					case "addvart":
						{
							error = false;
							return string.Format(@"javascript:documentPageAddVART('{0}');", param.Attributes[0].Key);
						}
					case "addfirstgtin":
						{
							error = false;
							return string.Format(@"javascript:documentPageAddFirstGTIN('{0}');", param.Attributes[0].Key);
						}
					case "cleararticlechoice":
						{
							error = false;
							return string.Format(@"javascript:documentPageClearArticleChoice('{0}');", param.Attributes[0].Value);
						}
					case "toggle":
						{
							error = false;
							return string.Format(@"javascript:dwcTemplateToggle('{0}');", param.Attributes[0].Value);
						}
					//case "setheaderandbook":
					//	{
					//		return ProcessParamSetHeaderAndBook(param, ref error);
					//	}
					case "tpevent":
						{
							return ProcessParamTPEvent(param, ref error);
						}
					//case "tpeventcontactinfo":
					//	{
					//		return ProcessParamTPEventContactInfo(ref error);
					//	}
					case "addsearcheditemstodocument":
						{
							return ProcessParamAddSearchedItemsToDocument(param, ref error);
						}
					case "upbuttonclick":
						{
							return ProcessParamUpButtonClick(param, ref error);
						}
				}
			}

			ReasonFailure = "UNKNOWN ACTION:" + paramVarTL;
			return ProcessParamBase(ref error);
		}

		/*private object ProcessParamSetHeaderAndBook(VarParam param, ref bool error)
		{
			error = false;
			string header = param.Attributes[0].Value;
			string value = param.Attributes[1].Value;
			DwcContextUnit dcu = DwcContext.GetContext(DwcContextType.Template);
			if (dcu != null)
			{
				string key = ETemplate.GetVarKey(dcu.ObjectAsTemplate.Template.TemplateKey, "header:" + header);
				return @"javascript:documentPageSetHeaderAndBook('" + key + "','" + value + "');";
			}
			return "";
		}*/

		private object ProcessParamTPEvent(VarParam param, ref bool error)
		{
			string dataType = param.GetAttributeValue("type");
			string data = param.GetAttributeValue("data");
			if (dataType.ToLower() == "disabled")
			{
				// Use this data type to hide button
				return "#";
			}
			error = false;
			return @"javascript:dwcTPDoEvent('" + dataType + @"','" + data + "')";
		}

		/*private object ProcessParamTPEventContactInfo(ref bool error)
		{
			DwcContextUnit dcu = DwcContext.GetContext(DwcContextType.Contact);
			if (dcu == null)
			{
				return "#";
			}
			error = false;
			return @"javascript:dwcTPDoEvent('ContactInfo'," + DwcCommon.SetUrlParams("../WEBDetail/ItemExport.ashx", new string[,] {
																																						{"contactNumber", dcu.ObjectAsContact.ToString()}}) + ")";
		}*/

		private object ProcessParamAddSearchedItemsToDocument(VarParam param, ref bool error)
		{
			string stockFormula;
			string maxItems;
			string branches;

			stockFormula = param.Attributes.FirstOrDefault(a => a.Key.ToLower() == "stockformula").Value;
			if (string.IsNullOrEmpty(stockFormula))
			{
				stockFormula = "Basic";
			}

			maxItems = param.Attributes.FirstOrDefault(a => a.Key.ToLower() == "maxitems").Value;
			if (string.IsNullOrEmpty(maxItems))
			{
				maxItems = "100";
			}

			branches = param.Attributes.FirstOrDefault(a => a.Key.ToLower() == "branches").Value;
			/*if (string.IsNullOrEmpty(branches))
			{
				branches = DwcCommon.GetParamBranch().ToString();
			}*/

			error = false;
			return string.Format("javascript:dwcAddSearchedItemsToDocument('{0}','{1}','{2}')", stockFormula, branches, maxItems);
		}

		private object ProcessParamUpButtonClick(VarParam param, ref bool error)
		{
			string functionName = param.Attributes.FirstOrDefault(a => a.Key.ToLower() == "function").Value;
			string back = param.Attributes.FirstOrDefault(a => a.Key.ToLower() == "goback").Value;

			if (string.IsNullOrEmpty(functionName))
			{
				functionName = "SAVEUSERBUTTON";
			}

			if (string.IsNullOrEmpty(back))
			{
				back = "true";
			}

			error = false;
			return string.Format(@"javascript:dwcUserProgramButtonCallback('" + functionName + @"'," + back + @")");
		}

		private bool ProcessParamCheckAttributesCount(string paramVarTL, int paramAttributesCount)
		{
			switch (paramVarTL)
			{
				case "addvart":
				case "addfirstgtin":
				case "toggle":
				case "cleararticlechoice":
					{
						return paramAttributesCount > 0;
					}
				case "setheaderandbook":
					{
						return paramAttributesCount > 1;
					}
			}
			return true;
		}
	}
}