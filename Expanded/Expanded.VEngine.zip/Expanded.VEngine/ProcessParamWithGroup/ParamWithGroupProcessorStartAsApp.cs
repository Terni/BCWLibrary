﻿//using DatecWebClient;

using Expanded.VEngine.Commons;
using Expanded.VEngine.Interface;

namespace Expanded.VEngine
{
	public class ParamWithGroupProcessorStartAsApp : ParamWithGroupProcessorBase, IParamWithGroupProcessor
	{
		public ParamWithGroupProcessorStartAsApp(bool ignoreErrors)
			: base(ignoreErrors)
		{
		}

		public object ProcessParam(VarParam param, out bool error)
		{
			error = true;
			int nodeId = -1;
			int subNodeId = -1;
			string[] spl = param.Var.Split('.');
			nodeId = int.Parse(spl[0]);
			if (spl.Length > 1)
			{
				subNodeId = int.Parse(spl[1]);
			}
			error = false;
			//string url = MenuCore.NodeIdToUrl(nodeId, subNodeId, false);
		    string url = "";
			return Common.SetParameterToUrl(url, "appNode", nodeId.ToString());
		}
	}
}