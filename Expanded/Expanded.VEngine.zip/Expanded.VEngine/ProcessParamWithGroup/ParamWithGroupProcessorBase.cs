﻿using System;
using System.Globalization;
using Expanded.VEngine.Commons;
using Expanded.VEngine.Template;

//using DatecWebClient;

namespace Expanded.VEngine
{
	public class ParamWithGroupProcessorBase
	{
        private VarEngine _varEngine = new VarEngine();

		protected bool IgnoreErrors
		{
			get;
			private set;
		}

		protected string ReasonFailure
		{
			get;
			set;
		}

		public ParamWithGroupProcessorBase(bool ignoreErrors)
		{
			IgnoreErrors = ignoreErrors;
			ReasonFailure = "MISSING CONTEXT";
		}

		protected object ProcessParamBase(ref bool error)
		{
			if (false == IgnoreErrors)
			{
				error = true;
				return ReasonFailure;
			}
			else
			{
				return "";
			}
		}

		protected string FixUserProgramInput(VarParam varParam)
		{
            //if (varParam == null || varParam.Value == null)
            //{
            //	return _varEngine.GetSpecialNullValue;
            //}

            //// Remove currency from sql input
            //if (ETemplate.IsCurrencyType(varParam.DataType))
            //{
            //	decimal decCurr = Common.GetObjectCurrencyDecimal(varParam.Value, Common.GetCurrencyISOForCurrentBranch());
            //	return decCurr.ToString();
            //}

            //// Convert date time to proper string
            //if (ETemplate.IsDateTimeType(varParam.DataType))
            //{
            //	DateTime dt;
            //	if (DateTime.TryParse(varParam.Value.ToString(), CultureInfo.GetCultureInfo(DwcCommon.GetParamLanguageCode()), DateTimeStyles.None, out dt))
            //	{
            //		return dt.ToString("s");
            //	}
            //}
            //// Convert numbers to invariant type
            //if (ETemplate.IsNumberType(varParam.DataType))
            //{
            //	decimal n = 0;
            //	if (decimal.TryParse(varParam.Value.ToString(), NumberStyles.Number, CultureInfo.GetCultureInfo(Common.GetParamLanguageCode()), out n))
            //	{
            //		return n.ToString(CultureInfo.InvariantCulture);
            //	}
            //}

            //         //if (varParam.DataType== RV.Common.DisplayValueTypes.Multiselect)
            //         //{
            //         //    return varParam.Value.ToString();
            //         //}

            //string strInput = varParam.Value.ToString();
            //strInput = strInput.Replace("'", "''");
            ////strInput = DwcSecurity.SanitizeUserInput(strInput);

            //return strInput;
            throw new NotImplementedException();
        }
	}
}