﻿//using System.Data;
//using DatecWebClient;

using System;
using Expanded.VEngine.Interface;

namespace Expanded.VEngine
{
	public class ParamWithGroupProcessorTmpTable : ParamWithGroupProcessorBase, IParamWithGroupProcessor
	{
		public ParamWithGroupProcessorTmpTable(bool ignoreErrors)
			: base(ignoreErrors)
		{
		}

		public object ProcessParam(VarParam param, out bool error)
		{
            //error = false;
            //DataTable dt = DwcUserProgramContext.GetDataTableForDocument();
            //if (dt != null && dt.Rows != null && dt.Rows.Count > 0)
            //{
            //	string var = param.Var;
            //	return DwcCommon.GetObjectString(dt.Rows[0][var]);
            //}
            //return "---";
            throw new NotImplementedException();
        }
	}
}