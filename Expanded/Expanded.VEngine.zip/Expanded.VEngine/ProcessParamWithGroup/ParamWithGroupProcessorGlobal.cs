﻿//using System.Web;

//using DRS.WEBClientCommon;
using Expanded.VEngine.Interface;

//using DatecWebClient;

namespace Expanded.VEngine
{
	public class ParamWithGroupProcessorGlobal : ParamWithGroupProcessorBase, IParamWithGroupProcessor
	{
		public ParamWithGroupProcessorGlobal(bool ignoreErrors)
			: base(ignoreErrors)
		{
		}

		public object ProcessParam(VarParam param, out bool error)
		{
			error = true;
			string paramVarTL = param.Var.ToLower();
			//if (paramVarTL == "currentrequestserver")
			//{
			//	error = false;
			//	return HttpContext.Current.Request.Url.DnsSafeHost;
			//}
   //         if (paramVarTL == "currentserverwithport")
   //         {
   //             error = false;
   //             return System.Web.HttpContext.Current.Request.Url.Authority;
   //         }

   //         foreach (WebClientGlobalVariable wcgv in DwcSettingsBase.WebClientSettings.OverallSettings.GlobalVariables.WebClientGlobalVariables)
			//{
			//	if (wcgv.Name.ToLower() == paramVarTL)
			//	{
			//		error = false;
			//		return wcgv.Value;
			//	}
			//}
			return ProcessParamBase(ref error);
		}
	}
}