﻿//
// Common library, all common stuff for this web application goes here
//

using System;
using System.Collections.Generic;
//using System.Web;
//using System.Web.UI;
using System.Text;
using System.IO;
//using DRS.Common.ERP;
using System.Globalization;
//using System.Data;
//using System.Data.SqlClient;
//using System.Web.Compilation;
//using System.Web.Routing;
//using RV.CF.Common.FormCode;
//using RV.Common;
//using RV.CF.Documents;
using System.Collections;
using Android.Provider;
using Java.Net;
using Java.Util;
using Org.Apache.Http.Protocol;

//using Microsoft.Ajax.Utilities;
//using DatecReportingPortal;
//using DRS.WEBClientCommon;
//using System.Web.SessionState;

namespace Expanded.VEngine.Commons
{
    /*public class StartPointRedirectPage : Page
    {
        public string StartPointID { get; set; }
    }

    public class StartPointRouteHandler : IRouteHandler
    {
        public StartPointRouteHandler(string virtualPath)
        {
            this.VirtualPath = virtualPath;
        }

        public string VirtualPath { get; private set; }

        public IHttpHandler GetHttpHandler(RequestContext requestContext)
        {
            var page = (StartPointRedirectPage)BuildManager.CreateInstanceFromVirtualPath
                    (VirtualPath, typeof(Page));

            page.StartPointID = requestContext.RouteData.Values["StartPoint"] as String;

            return page;
        }
    }

    public class MySessionIDManager: SessionIDManager, ISessionIDManager
    {
        void ISessionIDManager.SaveSessionID( HttpContext context, string id, out bool redirected, out bool cookieAdded )
        {
            base.SaveSessionID( context, id, out redirected, out cookieAdded );

            if (cookieAdded) {
                string name = "ASP.NET_SessionId";
                HttpCookie cookie = context.Response.Cookies[ name ];
                if ( cookie != null ) {
                    cookie.Path = Common.GetCookiePath();
                }
            }
        }
    }*/

    /// <summary>
    /// Common tools for Datec Web Client
    /// </summary>
    public class Common
    {
        public object SyncLocker = new object();
        public string ProperlyConfiguredSlotID = null;
        public string MagicString = "_____";

        public Common()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        public string IsNull(object inVar, string retVal)
        {
            if (inVar == null)
            {
                return retVal;
            }
            return inVar.ToString();
        }

        public string ObjectToJSON(string var, string val)
        {
            return "\"" + var + "\":\"" + val + "\"";
        }

        public static string ArrayToJSON(string var, string[] vals)
        {
            StringBuilder str = new StringBuilder();
            str.Append("\"" + var + "\":[");

            int i = 0;
            foreach (string v in vals)
            {
                str.Append(v);

                if (i != vals.GetLength(0) - 1)
                {
                    str.Append(",");
                }

                i++;
            }

            str.Append("]");

            return str.ToString();
        }

        /*
        protected static void LogInternal(string type, string message)
        {
            ILog logger = LogManager.GetLogger("File");
            System.Diagnostics.StackFrame frame = new System.Diagnostics.StackFrame(2);
            string classStr = frame.GetMethod().ReflectedType.FullName;
            string methodStr = frame.GetMethod().Name;
            string baseStr = "IP:" + HttpContext.Current.Request.ServerVariables["REMOTE_ADDR"] + "; " + classStr + "." + methodStr + ": " + message;
            switch (type)
            {
                case "i":
                    logger.Info(baseStr);
                    break;
                case "w":
                    logger.Warn(baseStr);
                    break;
                case "e":
                    logger.Error(baseStr);
                    break;
                case "f":
                    logger.Fatal(baseStr);
                    break;
                default:
                    logger.Info(baseStr);
                    break;
            }
        }*/
        public bool GetValueBool(string str)
        {
            string val;
            bool res;

            val = str;
            if (string.IsNullOrEmpty(val))
                return false;

            if (val == "0")
                return false;

            if (val == "1")
                return true;

            if (bool.TryParse(val, out res))
                return res;
            else
                return false;

        }

        /*
        public static void LogInfo(string message)
        {
            TPOMM.Tools.Log.Logger.Static.GetContext().Log(message);
        }

        public static void LogWarn(string message)
        {
            TPOMM.Tools.Log.Logger.Static.GetContext().Log("Warning {0}", message);
        }

        public static void LogError(string message)
        {
            TPOMM.Tools.Log.Logger.Static.GetContext().Log("Error {0}", message);
        }

        public static void LogError(string message, bool noDbLogCall)
        {
            TPOMM.Tools.Log.Logger.Static.GetContext().Log("Error {0}", message);
        }

        public static void LogFatal(string message)
        {
            TPOMM.Tools.Log.Logger.Static.GetContext().Log("ServerError {0}", message);
        }

        public static void UrlMissingParamException(string param)
        {
            string exStr = "Missing parameter in path [" + System.Web.HttpContext.Current.Request.Url.AbsolutePath + "]. Parameter: [" + param + "].";
            throw (new Exception(exStr));
        }

        public static void UrlBadParamException(string param)
        {
            string exStr = "Wrong parameter in path [" + System.Web.HttpContext.Current.Request.Url.AbsolutePath + "]. Parameter: [" + param + "].";
            throw (new Exception(exStr));
        }*/

        /*public static string GetCookiePath()
        {
            if ( Common.GetSlotID() != null ) {
                return "/";// "WEBPlayer-Slot" + DwcCommon.GetSlotID() + "/";
            }

            return "/";
        }*/

        public string GetObjectStringNoCurrency(object obj)
        {
            if (obj == null)
            {
                return "";
            }

            if (obj.GetType() == typeof(DateTime))
            {
                return GetObjectDateTimeString(obj);
            }

            return obj.ToString();
        }

        public string GetObjectString(object obj)
        {
            if (obj == null )
            {
                return "";
            }

            if (obj.GetType() == typeof(DateTime)) {
                return GetObjectDateTimeString(obj);
            }
            /*
            if (obj.GetType() == typeof(Decimal)) {
                DwcContextUnit u = DwcContext.GetContext( DwcContextType.DocumentObject );
                if (u != null)
                {
                    try
                    {
                        return GetPriceString(obj, DwcDocumentCore.DocCurrencyIsoCode(u.ObjectAsDocumentObject));
                    }
                    catch (Exception e)
                    {
                        TPOMM.Tools.Log.Logger.Static.GetContext().Log(e);
                    }
                }

                return GetPriceString(obj);
            }*/

            return obj.ToString();
        }

        public int GetObjectInt(object obj)
        {
            return (int) obj;
        }

        public double GetObjectDouble(object obj)
        {
            return (double)obj;
        }

        public decimal GetObjectDecimal(object obj)
        {
            double dbl = GetObjectDouble(obj);
            return (decimal)dbl;
        }

        public Guid? GetObjectGuid(object obj)
        {
            if (obj == null)
            {
                return null;
            }

            return (Guid)obj;
        }

        public string GetObjectDateTimeString(object obj)
        {
            return GetObjectDateTimeString(obj, true);
        }

        public string GetObjectDateTimeString(object obj, bool includeTimeString )
        {
            if (obj == null) {
                return "";
            }

            DateTime tm = (DateTime)obj;
            if (includeTimeString)
            {
                return tm.ToString();
            }
            else
            {
                return tm.ToString();
            }
        }

        public decimal GetObjectCurrencyDecimal(object obj, string currencyISO)
        {
            string price = this.GetObjectString(obj);
            //NumberFormatInfo nfi = Common.GetCurrencyNFI(currencyISO);
            return decimal.Parse(price, NumberStyles.Currency);
        }

        public string GetIntString(object obj)
        {
            if (obj == null)
            {
                return "";
            }

            int result = 0;
            if (int.TryParse(obj.ToString(), out result)) {
                return result.ToString();
            }

            return "";
        }
        /*
        public static string GetCurrencyISOForCurrentBranch()
        {
            CurrencyElem el = GlobalCurrencyInfo.GetCurrencyDefault(Common.GetParamBranch());
            if ( el != null ) {
                return el.ISOCode;
            }
            return GlobalCurrencyInfo.GetCurrencyDefaultForFirstBranch().ISOCode;
        }*/
        /*
        public static string GetCurrencyString(int branch)
        {
            return GetCurrencyString(GetCurrencyISOForCurrentBranch());
        }

        public static string GetCurrencyString(object currency)
        {
            NumberFormatInfo ni = RV.Common.CurrencyConvTable.GetCurrencyForCode(Common.GetObjectString(currency));
            return ni == null ? "" : ni.CurrencySymbol;
        }

        public static string GetCurrencyString(DocumentsContract.Document doc)
        {
            NumberFormatInfo ni = RV.Common.CurrencyConvTable.GetCurrencyForCode(DwcDocumentCore.DocCurrencyIsoCode(doc));
            return ni == null ? "" : ni.CurrencySymbol;
        }
        */

        //public static NumberFormatInfo GetCurrencyNFI(int branch)
        //{
        //    return GetCurrencyNFI(GetCurrencyISOForCurrentBranch());
        //}

        /*
        public static string GetSlotID()
        {
            if ( ProperlyConfiguredSlotID != null ) {
                return ProperlyConfiguredSlotID;
            }

            string appVPath = System.Web.Hosting.HostingEnvironment.ApplicationVirtualPath;
            if ( false == string.IsNullOrEmpty(appVPath)) {
                string slotIDString = "-slot";
                int idxOfSlotIDString = appVPath.ToLower().LastIndexOf(slotIDString);
                int lenOfSlotIDString = slotIDString.Length;
                if ( idxOfSlotIDString != -1) {
                    string slotID = appVPath.Substring(idxOfSlotIDString + lenOfSlotIDString);
                    return slotID;
                }
            }
            return null;
        }

        public static NumberFormatInfo GetCurrencyNFI(object currency)
        {
            NumberFormatInfo ni = RV.Common.CurrencyConvTable.GetCurrencyForCode(Common.GetObjectString(currency));
            return ni == null ? System.Globalization.NumberFormatInfo.CurrentInfo : ni;
        }

        public static NumberFormatInfo GetCurrencyNFI(DocumentsContract.Document doc)
        {
            NumberFormatInfo ni = RV.Common.CurrencyConvTable.GetCurrencyForCode(DwcDocumentCore.DocCurrencyIsoCode(doc));
            return ni == null ? System.Globalization.NumberFormatInfo.CurrentInfo : ni;
        }*/

        public static string GetPriceString(object number)
        {
            throw new NotImplementedException();
            //return GetPriceString(number, Common.GetParamBranch(), null, null);
        }

        public static string GetPriceString(object number, int branch)
        {
            throw new NotImplementedException();
            //return GetPriceString(number, branch, null, null);
        }

        public static string GetPriceString(object number, DocumentsContract.Document doc)
        {
            throw new NotImplementedException();
            //return GetPriceString(number, Common.GetParamBranch(), doc, null);
        }

        public static string GetPriceString(object number, string isoCode)
        {
            throw new NotImplementedException();
            //return GetPriceString(number, Common.GetParamBranch(), null, isoCode);
        }
        /*
        public static string GetPriceString(object obj, int branch, DocumentsContract.Document doc, string isoCode ) {

            decimal num = 0;
            if (obj == null || obj.GetType() == typeof(DBNull))
            {
                num = 0;
            }
            else
            {
                // Have to convert from object using invariant culture
                decimal tempNumber;
                if (obj.GetType() == typeof(string))
                {
                    if (false == decimal.TryParse(obj.ToString(), NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out tempNumber))
                    {
                        return obj.ToString();
                    }
                }
                else
                {
                    tempNumber = Convert.ToDecimal(obj);
                }

                num = tempNumber;
            }

            if (isoCode != null) {

                NumberFormatInfo ni = RV.Common.CurrencyConvTable.GetCurrencyForCode(isoCode);
                if (ni != null)
                {
                    return num.ToString("c", ni);
                }
            }

            // If this context is specified always format in document currency
            DwcContextUnit dcu = DwcContext.GetContext(DwcContextType.DocumentObjectFormatInDocumentCurrency);
            if (dcu != null) {
                DwcContextUnit dcuDoc = DwcContext.GetContext(DwcContextType.DocumentObject);
                if (dcuDoc != null) {
                    doc = dcuDoc.ObjectAsDocumentObject;
                }
            }
            dcu = DwcContext.GetContext(DwcContextType.DocumentSearchDRSStyleRow);
            if (dcu != null)
            {
                IDataReader rdr = dcu.ObjectAsDocumentSearchDRSStyleRow;
                if (false == Convert.IsDBNull(rdr["CurrencyISOCode"])) {
                    NumberFormatInfo ni = Common.GetCurrencyNFI(rdr["CurrencyISOCode"]);
                    return num.ToString("c", ni);
                }
            }

            if (doc != null) {
                NumberFormatInfo ni = Common.GetCurrencyNFI(doc);
                return num.ToString("c", ni);
            }

            return GlobalCurrencyInfo.FormatInBranchCurrency(num, branch);
        }*/

        public static bool IsParameterInUrl(string param)
        {
            throw new NotImplementedException();
            //return System.Web.HttpContext.Current.Request.Params[param] != null;
        }
        /*
        public static string UpdateRSLink(string linkStr)
        {
            string linkStrTl = (linkStr == null) ? "" : linkStr.ToLower();
            if (false == linkStrTl.Contains("/reportserver/") && false == linkStrTl.Contains("/reportserver?")) {
                return linkStr;
            }

            // Update link to report with slot parameter
            string slotID = GetSlotID();
            string slotIDString = "&SlotID=";
            if ( slotID != null && linkStr.IndexOf(slotIDString) == -1 ) {
                linkStr += slotIDString + slotID;
            }

            if (DwcSettingsBase.GetCurrentDeviceVariableValue("RSPDFHandler") == "0")
            {
                return linkStr;
            }

            if (linkStrTl.Contains("pdf") && false == linkStrTl.Contains("/rspdfhandler.ashx"))
            {
                linkStr = linkStr.Replace("#", "_DWC_HASH_DWC_");
                linkStr = linkStr.Replace(":", "_DWC_COLON_DWC_");
                string encoded = HttpUtility.UrlEncode(linkStr);
                encoded = encoded.Replace("_DWC_HASH_DWC_", "#");
                encoded = encoded.Replace("_DWC_COLON_DWC_", ":");

                // we need to return back encoded #
                linkStr = Common.SetUrlParams("../WEBCommon/RSPDFHandler.ashx", new string[,] { { "link", encoded }, {"format", "PDF"}});
            }

            return linkStr;
        }*/

        public static void ClearUserCache()
        {
            throw new NotImplementedException();
            //DwcUserProgramContext.ResetAllConnections();
            //DwcSecurity.CurrentUserAccount = null;
            //DwcCache.PerUserProtectedCache = null;
            //DwcCache.PerUserCache = null;
            //DwcDRSVariables.VariablesCache = null;
        }

        public static string GetUnsafeUrlParameterAsString(string param, string defParam)
        {
            return GetUrlParameterAsString(param, defParam, false);
        }

        public static string GetUrlParameterAsString(string param, string defParam)
        {
            return GetUrlParameterAsString(param, defParam, true);
        }

        // Return paramameter from url as string. If defParam is null and parameter is not found in url, throws exception
        public static string GetUrlParameterAsString(string param, string defParam, bool sanitizeInput)
        {
            //try
            //{
            //    string val = System.Web.HttpContext.Current.Request.Params[param];
            //    if (val == null && defParam == null)
            //    {
            //        UrlMissingParamException(param);
            //        return "";
            //    }
            //    else if (val == null)
            //    {
            //        return defParam;
            //    }
            //    else
            //    {
            //        if (sanitizeInput)
            //        {
            //            return DwcSecurity.SanitizeUserInput(val);
            //        }
            //        else
            //        {
            //            return val;
            //        }
            //    }
            //}
            //catch (Exception ex)
            //{
            //    if (defParam == null)
            //    {
            //        throw ex;
            //    }

            //    return defParam;
            //}
            throw new NotImplementedException();
        }

        //public static Dictionary<string, string> GetURLColonPrefixParameters(string prefix)
        //{
        //    Dictionary<string, string> urlColonPrefixParameters = new Dictionary<string, string>();

        //    foreach (string s in System.Web.HttpContext.Current.Request.Params)
        //    {
        //        if (!string.IsNullOrEmpty(s))
        //        {
        //            if (s.StartsWith(prefix + ":"))
        //            {
        //                urlColonPrefixParameters.Add(s.Replace(prefix + ":", "").ToLower(), System.Web.HttpContext.Current.Request.Params[s]);
        //            }
        //        }
        //    }

        //    return urlColonPrefixParameters;
        //}

        //public static int? ParseContactFromAnyDataSource(string contact)
        //{
        //    if (contact == null || contact == "") {
        //        return null;
        //    }
        //    /*if (contact == DwcLocale.Localize("{loc:dwc.contactEdit.ChooseEntry}")) {
        //        return 0;
        //    }*/
        //    string[] spl = contact.Split(' ');
        //    if (spl.Length < 1) {
        //        return null;
        //    }

        //    int testContact;
        //    if (int.TryParse(spl[0], out testContact)) {
        //        return testContact;
        //    }

        //    return null;
        //}

        //// Return paramameter from url as integer. If defParam is null and parameter is not found in url, throws exception
        //// If passed parameter cannod be interpreted as integer, throws exception
        //public static int GetUrlParameterAsInt(string param, int? defParam)
        //{
        //    string val = GetUrlParameterAsString(param, defParam.HasValue ? defParam.Value.ToString() : null);
        //    int retVal = 0;
        //    if (false == int.TryParse(val, out retVal))
        //    {
        //        // Logging of invalid branch would cause stack overflow
        //        /*if (param.ToLower() != "branch")
        //        {
        //            TPOMM.Tools.Log.Logger.Static.GetContext().Log("ServerError Failed to parse int url parameter: {0} val: {1}", param,val);
        //        }*/
        //        return defParam.HasValue ? defParam.Value : 0;
        //    }
        //    else
        //    {
        //        return retVal;
        //    }

        //    return 0;
        //}

        //public static double GetUrlParameterAsDouble(string param, double? defParam)
        //{
        //    string val = GetUrlParameterAsString(param, defParam.HasValue ? defParam.Value.ToString() : null);
        //    double retVal = 0;
        //    if (false == double.TryParse(val, out retVal))
        //    {
        //        UrlBadParamException(param);
        //    }
        //    else
        //    {
        //        return retVal;
        //    }

        //    return 0;
        //}

        //// Return paramameter from url as double. If defParam is null and parameter is not found in url, throws exception
        //// If passed parameter cannod be interpreted as currency, throws exception
        //public static double GetUrlParameterAsPrice(string param, double? defParam)
        //{
        //    string val = GetUrlParameterAsString(param, defParam.HasValue ? defParam.Value.ToString() : null);
        //    double retVal = 0;
        //    if (false == double.TryParse(val, out retVal))
        //    {
        //        UrlBadParamException(param);
        //    }
        //    else
        //    {
        //        return retVal;
        //    }

        //    return 0;
        //}

        //public static bool GetUrlParameterAsBool(string param, bool? defParam)
        //{
        //    string val = GetUrlParameterAsString(param, defParam.HasValue ? defParam.Value.ToString() : null);
        //    bool retVal = false;
        //    if (false == bool.TryParse(val, out retVal))
        //    {
        //        // Logging of invalid branch would cause stack overflow
        //        /*if (param.ToLower() != "branch")
        //        {
        //            TPOMM.Tools.Log.Logger.Static.GetContext().Log("ServerError Failed to parse bool url parameter: {0} val: {1}", param, val);
        //        }*/
        //        return defParam.HasValue ? defParam.Value : false;
        //    }

        //    return retVal;
        //}

        ///*public static string GetControlCode(UserControl ctrl)
        //{
        //    StringBuilder sb = new StringBuilder();
        //    StringWriter tw = new StringWriter(sb);
        //    HtmlTextWriter hw = new HtmlTextWriter(tw);
        //    ctrl.RenderControl(hw);
        //    return sb.ToString();
        //}*/

        public static string GetParamLanguageCode()
        {
            string lang = GetUrlParameterAsString("language", "en-GB");
            if (lang == "")
            {
                lang = "en-GB";
            }
            if (lang.Contains(","))
            {
                lang = lang.Split(',')[0];
            }
            return lang;
        }

        //public static int GetParamDeviceId()
        //{
        //    int devId = GetUrlParameterAsInt("deviceId", -1);
        //    return devId;
        //}

        //public static string GetParamProfile()
        //{
        //    return Common.GetUrlParameterAsString("profile", "");
        //}

        //public static Guid? GetBranchCompany(int branch)
        //{
        //    Guid? companyGuid = null;
        //    DwcSQLClient.CFDataReader(
        //                                "select CompanyRecUID from setShop where Number = @Number",
        //                                new SqlParameter[] {
        //                                   new SqlParameter("@Number", branch)
        //                                },
        //                                (rdr) =>
        //                                {
        //                                    if (rdr.Read())
        //                                    {
        //                                        companyGuid = Common.GetObjectGuid(rdr[0]);
        //                                    }
        //                                });
        //    return companyGuid;
        //}

        //public static bool CheckExistingBranch(int branch)
        //{
        //    bool branchExist = false;
        //    DwcSQLClient.CFDataReader(
        //                                "SELECT 1 FROM setShop WHERE Number = @Number",
        //                                new SqlParameter[] {
        //                                   new SqlParameter("@Number", branch)
        //                                },
        //                                (rdr) =>
        //                                {
        //                                    if (rdr.Read())
        //                                    {
        //                                        branchExist = true;
        //                                    }
        //                                });
        //    return branchExist;
        //}

        //public static Guid? GetBranchCompany()
        //{
        //    return GetBranchCompany(Common.GetParamBranch());
        //}

        //public static int GetParamBranch()
        //{
        //    int defBranch = 1;
        //    int? cachedBranch = (int?) DwcCache.PerUserCache[DwcCacheObjectType.CurrentUserCachedBranch];
        //    if ( false == cachedBranch.HasValue ) {
        //        // if cached branch is null get first branch of user
        //        User usr = DwcSecurity.CurrentUserAccountTest;
        //        if (usr != null) {
        //            string strBranch = usr.GetAccessRightValue(enumAccessRightsVariables.Branch, "1");
        //            int.TryParse(strBranch, out defBranch);
        //        }
        //    } else {
        //        defBranch = cachedBranch.Value;
        //    }

        //    int branch =  GetUrlParameterAsInt("branch", defBranch);
        //    if ( Common.GetUrlParameterAsInt("documentStep",-1) != -1
        //        || Common.GetUrlParameterAsInt("step",-1) != -1
        //        /* cannot use context in this level */) {
        //        // In document context return source branch of document
        //        if ( DwcDocumentBase.DocObject != null ) {
        //            // Do not cache document branch
        //            return DwcDocumentBase.DocObject.SourceBranch;
        //        }
        //    }
        //    DwcCache.PerUserCache[DwcCacheObjectType.CurrentUserCachedBranch] = branch;
        //    return branch;
        //}

        //public static string GetParamBranchForDisplay()
        //{
        //    return GetParamBranchForDisplay(GetParamBranch());
        //}

        //public static string GetParamBranchForDisplay(int branch)
        //{
        //    string branchForDisplay = branch.ToString();
        //    Dictionary<int, string> GetParamBranchForDisplay = (Dictionary<int, string>)DwcCache.PerUserCache[DwcCacheObjectType.CurrentCachedBranchForDisplay];

        //    if (GetParamBranchForDisplay == null)
        //    {
        //        GetParamBranchForDisplay = new Dictionary<int,string>();

        //        using (SqlConnection conn = new SqlConnection(ERPTools.CFConnectionString))
        //        {
        //            conn.Open();
        //            string c = @"SELECT TextValue,Branch FROM setShopAttributeType t
        //                JOIN setShopAttributeValue v ON t.RecUID=v.AttributeTypeRecUID
        //                WHERE t.AttributeName='BranchForDisplay'";

        //            using (SqlCommand cmd = new SqlCommand(c, conn))
        //            {
        //                SqlDataReader rdr = cmd.ExecuteReader();
        //                while (rdr.Read())
        //                {
        //                    int b = Common.GetObjectInt(rdr["Branch"]);
        //                    if (!GetParamBranchForDisplay.ContainsKey(b))
        //                    {
        //                        if (!string.IsNullOrEmpty(Common.GetObjectString(rdr["TextValue"])))
        //                        {
        //                            GetParamBranchForDisplay.Add(b, Common.GetObjectString(rdr["TextValue"]));
        //                        }
        //                    }
        //                }
        //            }
        //        }
        //    }

        //    DwcCache.PerUserCache[DwcCacheObjectType.CurrentCachedBranchForDisplay] = GetParamBranchForDisplay;
        //    GetParamBranchForDisplay.TryGetValue(branch,out branchForDisplay);
        //    if (string.IsNullOrEmpty(branchForDisplay))
        //    {
        //        return branch.ToString();
        //    }

        //    return branchForDisplay;
        //}


        //public static string GetParamMenu()
        //{
        //    string val = GetUrlParameterAsString("menu", "");
        //    return val == "" ? null : val;
        //}
        ///*
        //public static bool IsLoggedIn()
        //{
        //    return DwcSecurity.IsLoggedIn();
        //}*/

        //public static bool GetParamEnableBack()
        //{
        //    int val = GetUrlParameterAsInt("enableBack", 0);
        //    return val == 1;
        //}

        //public static string GetParamContactAuthToken()
        //{
        //    string val = GetUrlParameterAsString("ContactAuthToken", "");
        //    if (val != "") {
        //        Common.LogInfo("AuthTokenValue: " + val);
        //        string[] splitted = val.Split(',');
        //        if (splitted.Length > 1) {
        //            return splitted[0].Length > 0 ? splitted[0] : splitted[1];
        //        }
        //        return val;
        //    }

        //    return null;
        //}

        //public static string ResolveUrl(string originalUrl)
        //{
        //    if (originalUrl == null)
        //    {
        //        return null;
        //    }
        //    if (originalUrl.IndexOf("://") != -1)
        //    {
        //        return originalUrl;
        //    }
        //    if (originalUrl.StartsWith("~"))
        //    {
        //        string newUrl = "";
        //        if (HttpContext.Current != null)
        //        {
        //            newUrl = HttpContext.Current.Request.ApplicationPath + originalUrl.Substring(1).Replace("//", "/");
        //            return newUrl;
        //        }
        //        else
        //        {
        //            throw new ArgumentException("Invalid URL: Relative URL not allowed.");
        //        }
        //    }
        //    return originalUrl;
        //}

        //public static void HandlerMessageBox( string message ) {
        //    HandlerMessageBox(message, false);
        //}

        //public static void HandlerMessageBox(string message, bool mustConfirm)
        //{
        //    message = message.Replace("\\r\\n", "<br/>");
        //    message = message.Replace("\\n", "<br/>");
        //    HttpContext.Current.Response.Write(@"<div style=""display:none"" class=""dwcMessage"" data-confirm=""" + (mustConfirm ? "1" : "0") + @""">" + DwcVarEngine.ProcessString(message) + "</div>");
        //}

        //public static string GetIconUrl(string icon) {
        //    return ResolveUrl(ImgConverter.ConvertIcoFile(DatecReportingPortal.Reports.EntityType.FOLDER, System.Web.HttpContext.Current.Server.MapPath("~/"), icon));
        //}

        //public static int? GetContactNumberByCustomerCardInternal( string customerCardNumber, string customerCardType )
        //{
        //    string query = @"select ccm.Number from ctContactMain ccm
        //          join ctContactIdentity cci on cci.ContactRecUID = ccm.RecUID 
        //          join ctbContactIdentityList ccil on ccil.RecUID = cci.ReferenceRecUID
        //          join ctContactIdentityData ccid on ccid.ParentRecUID = cci.RecUID
        //          join ctContactVariable ccv on ccv.RecID = ccid.VariableNumber
        //          where ccil.ID = @CardType and ccv.VariableName = 'IdentityValue' and ccid.Value = @Value";

        //    int? result = null;
        //    DwcSQLClient.CFDataReader(query, new SqlParameter[] {
        //            new SqlParameter("@CardType", customerCardType),
        //            new SqlParameter("@Value", customerCardNumber)}, (rdr) => {
        //                if ( rdr.Read() ) {
        //                    result = Convert.ToInt32(rdr[0].ToString());
        //                }
        //            });

        //    return result;
        //}

        //public static int? GetContactNumberByCustomerCard(string customerCardNumber)
        //{
        //    // parse cardnumber
        //    string[] spl = customerCardNumber.Split( new char[] {'-'}, 2);
        //    if (spl.Length > 1)
        //    {
        //        int cardType = int.Parse(spl[0]);
        //        string cardNumber = HttpUtility.UrlDecode(spl[1]);

        //        switch ( spl[1] ) {
        //            case "0":
        //                return GetContactNumberByCustomerCardInternal(cardNumber, "CARD");
        //            case "1":
        //                return GetContactNumberByCustomerCardInternal(cardNumber, "MOBITO");
        //            case "2":
        //                return GetContactNumberByCustomerCardInternal(cardNumber, "CHIP");
        //            default:
        //                return GetContactNumberByCustomerCardInternal(cardNumber, "CARD");

        //        }
        //    }
        //    else{
        //        return GetContactNumberByCustomerCardInternal(customerCardNumber, "CARD");
        //    }
        //}

        //public static string GetCurrentCustomerLanguageISOCode()
        //{
        //    string languageIsoCode = Common.GetParamLanguageCode();

        //    if (DwcDocumentBase.DocObject == null)
        //    {
        //        return languageIsoCode;
        //    }

        //    try
        //    {
        //        DwcSQLClient.RFCDataReader(
        //           @"SELECT TextValue FROM permContactExtendedInfoTypes t 
        //        JOIN permContactExtendedInfoValues v ON t.RecUID = v.ExtendedInfoType 
        //        JOIN permContact c ON v.ContactUID = c.RecUID
        //        WHERE ContactNumber='@ContactNumber' AND t.Name='LanguageISOCode'",
        //           new SqlParameter[] {
        //            new SqlParameter("@ContactNumber", DwcDocumentBase.DocObject.SupplierID)
        //        },
        //           (rdr) =>
        //           {
        //               while (rdr.Read())
        //               {
        //                   languageIsoCode = Common.GetObjectString(rdr[0]);
        //               }
        //           });
        //    }
        //    catch
        //    {
        //    }

        //    return languageIsoCode;
        //}

        //public static string ReplaceCaseInsensitive(string strWhere, string strOld, string strNew)
        //{

        //    int i = strWhere.IndexOf(strOld, StringComparison.OrdinalIgnoreCase);
        //    int len = strOld.Length;
        //    if (i == -1 || len == 0) {
        //        return strWhere;
        //    }
        //    strWhere = strWhere.Replace(strWhere.Substring(i, len), strNew);
        //    return strWhere;
        //}

        //public static string StringToInsensitiveForm(string str) {
        //    return CStringEx.RemoveDiacritics(str).ToLower();
        //}

        //public static List<string> SplitSearchPhrase(string str) {

        //    List<string> origStr = CStringEx.SplitRespApostrophes2(str, new char[] { ' ', ',', ';' });
        //    // remove empty entries
        //    List<string> newStr = new List<string>();
        //    foreach( string s in origStr ) {
        //        if ( false == string.IsNullOrEmpty(s)) {
        //            newStr.Add(s);
        //        }
        //    }
        //    return newStr;
        //}

        //public static bool EvaluateBranchToCurrentUser( int branch )
        //{
        //    User usr = DwcSecurity.CurrentUserAccountTest;
        //    if (usr == null) {
        //        return true;
        //    }

        //    foreach (int s in DwcSecurity.CurrentUserBranches) {
        //        if (s == branch) {
        //            return true;
        //        }
        //    }

        //    return false;
        //}

        //public static void FillEnumFromDataSource(rv.gc.Windows.Forms.ListItemsCollection items, int branch, string dataSource)
        //{
        //    if ( DwcDataSource.Process(dataSource, ref items))
        //    {
        //        return;
        //    }

        //    CodeList[] cl = DwcSettingsBase.CodeLists;

        //    // Evaluate user code lists first

        //    // First selectable from database
        //    foreach (CodeList c in cl) {
        //        if ( c.CodeListType == CodeListType.SelectFromDatabase && c.ID == dataSource) {
        //            //  Do own select with varengine replace

        //            DwcVarParamCollection coll = new DwcVarParamCollection();
        //            string select = DwcVarEngine.ProcessString(c.Select, out coll, false, "userprogramtablerow", true);
        //            try {
        //                DwcSQLClient.DataReader(Common.GetConnectionStringById(c.ConnectionStringID), select, null,
        //                        (rdr) =>
        //                        {
        //                            while (rdr.Read()) {
        //                                if ( rdr.FieldCount < 2) {
        //                                    throw new Exception("CONFIGURATION ERROR: Enumeration select must return at least 2 fields.");
        //                                }
        //                                items.Add(new rv.gc.Windows.Forms.ListItem(Common.GetObjectString(rdr[1]), rdr[0]));
        //                            }
        //                        });
        //            }
        //            catch(Exception ex)
        //            {
        //                TPOMM.Tools.Log.Logger.Static.GetContext().Log("ServerError InvalidSQLCodeList: {0} ErrorSelect: {1} Exception: {2}", c.ID, select, ex.Message);
        //            }
        //            return;
        //        }
        //    }

        //    string langCode = Common.GetParamLanguageCode().ToLower();

        //    // Second - fixed with current language code
        //    foreach (CodeList c in cl) {
        //        if ( c.CodeListType == CodeListType.ConstValues && c.ID == dataSource && c.LanguageCode.ToLower() == langCode) {
        //            foreach( CodeListItem cli in c.CodeListItems ) {
        //                items.Add(DwcVarEngine.ProcessString(cli.DisplayValue), cli.DataValue);
        //            }
        //            return;
        //        }
        //    }

        //    // Third - fixed with default language code
        //    foreach (CodeList c in cl) {
        //        if ( c.CodeListType == CodeListType.ConstValues && c.ID == dataSource && c.LanguageCode.ToLower() == "en-gb") {
        //            foreach( CodeListItem cli in c.CodeListItems ) {
        //                items.Add(DwcVarEngine.ProcessString(cli.DisplayValue), cli.DataValue);
        //            }
        //            return;
        //        }
        //    }

        //    // Last - fixed - no matter about language code
        //    foreach (CodeList c in cl) {
        //        if ( c.CodeListType == CodeListType.ConstValues && c.ID == dataSource ) {
        //            foreach( CodeListItem cli in c.CodeListItems ) {
        //                items.Add(DwcVarEngine.ProcessString(cli.DisplayValue), cli.DataValue);
        //            }
        //            return;
        //        }
        //    }

        //    // Standard data sources
        //    rv.gc.Windows.Forms.ListItemsCollection collection = new rv.gc.Windows.Forms.ListItemsCollection();
        //    DataSourceHelper.FillEnumFromDataSource(collection, branch, dataSource, ERPTools.GetPOSGroup(branch),

        //        delegate(object addObject) {

        //            User usr = DwcSecurity.CurrentUserAccountTest;
        //            switch (dataSource) {
        //                case "Branches":
        //                case "SourceBranches":
        //                case "SourceBranchesAndCompany":
        //                case "SourceBranchesAndGroups":
        //                {
        //                    if ( usr == null ) {
        //                        return true;
        //                    }
        //                    Shop shop = (Shop)addObject;
        //                    return EvaluateBranchToCurrentUser(shop.Number);
        //                }
        //            }
        //            return true;
        //        });

        //    foreach(rv.gc.Windows.Forms.ListItem it in collection)
        //    {
        //        if (it.DataValue != null && !string.IsNullOrEmpty(it.DataValue.ToString()))
        //        {
        //            items.Add(it);
        //        }
        //    }
        //}


        //public static KeyValuePair<string,string> GetItemIdBase()
        //{
        //    if (DwcDRSVariables.DrsOverrideItemId != null
        //        && DwcDRSVariables.DrsOverrideItemIdValue != null) {
        //            return new KeyValuePair<string, string>(DwcDRSVariables.DrsOverrideItemId, DwcDRSVariables.DrsOverrideItemIdValue);
        //    }

        //    string[,] itemIds = new string[,] {
        //        {"VART", Common.GetUrlParameterAsString("VART", "")},
        //        {"GTIN", Common.GetUrlParameterAsString("GTIN", "")},
        //        {"contactNumber", Common.GetUrlParameterAsString("contactNumber", "")},
        //        {"addressRecUID", Common.GetUrlParameterAsString("addressRecUID", "")},
        //        {"docObject", Common.GetUrlParameterAsString("docObject", "")},
        //        {"customerCardNumber", Common.GetUrlParameterAsString("customerCardNumber", "")}
        //    };

        //    for (int i = 0; i < itemIds.GetLength(0); i++)
        //    {
        //        if (itemIds[i,1] != "")
        //        {
        //            return new KeyValuePair<string, string>(itemIds[i,0], itemIds[i,1]);
        //        }
        //    }

        //    return new KeyValuePair<string, string>("", "");
        //}*/

        //public static string GetItemIdIdentificator()
        //{
        //    return GetItemIdBase().Key;
        //}

        //public static string GetItemId()
        //{
        //    return GetItemIdBase().Value;
        //}

        //public static string GetItemSystemId()
        //{
        //    string itemIdValue = Common.GetUrlParameterAsString("itemIdValue", "");
        //    string itemIdIdentificator = Common.GetUrlParameterAsString("itemIdIdentificator", "");
        //    if (itemIdIdentificator.ToLower() == "customercardnumber")
        //    {
        //        // Convert to number
        //        int? number = GetContactNumberByCustomerCard(itemIdValue);
        //        if (false == number.HasValue)
        //        {
        //            number = -1;
        //        }
        //        return number.Value.ToString();
        //    }

        //    return "";
        //}

        /// <summary>
        /// Method counting Mark in Url
        /// </summary>
        /// <param name="url">start string</param>
        /// <param name="mark">specific char</param>
        /// <returns>count</returns>
        private static int CountMarkIndex(string url, char mark) {

            int countMark = 0;
            for (int i = 0; i < url.Length; i++)
            {
                if (url[i] == mark)
                {
                    countMark = countMark + 1;
                }

            }
            return countMark;
        }

        /// <summary>
        /// Method for Set Parameter To Url
        /// </summary>
        /// <param name="url">in url</param>
        /// <param name="param">param for insert</param>
        /// <param name="value">value for current paran</param>
        /// <returns>set new URL</returns>
        public static string SetParameterToUrl(string url, string param, string value)
        {
            string urltl = url.ToLower();
            string paramtl = param.ToLower();

            bool containsParam = urltl.Contains("&" + paramtl + "=") || urltl.Contains("?" + paramtl + "=");
            bool containsQuery = urltl.Contains("?");

            if (false == containsQuery)
            {
                if (value != null)
                {
                    return url + "?" + param + "=" + value;
                }
                else
                {
                    return url;
                }
            }

            if (false == containsParam)
            {
                if (value != null)
                {
                    var indexOfHash = url.IndexOf("#"); // check # in url
                    if (indexOfHash == -1) // check # in url but check lastPosition
                    {
                        return url + "&" + param + "=" + value;
                    }
                    else
                    {
                        if (CountMarkIndex(url, '#') == 1) // check count hash
                        {

                            url = url.Insert(indexOfHash, "&" + param + "=" + value);
                            return url;
                        }
                        else
                        {
                            return url + "&" + param + "=" + value;
                        }
                    }
                }
                else
                {
                    return url;
                }
            }

            int start = urltl.IndexOf("&" + paramtl + "=");
            if (start == -1) {
                start = urltl.IndexOf("?" + paramtl + "=");
            }

            start += 1;
            int end = urltl.IndexOf("&", start);
            if (end == -1)
            {
                end = url.Length;
            }

            string removed = url.Remove(start, end - start);
            if (value != null)
            {
                return removed.Insert(start, param + "=" + value);
            }
            else
            {
                return removed;
            }
        }

        //      public static string RemoveParameterFromUrl(string url, string param)
        //      {

        //          var prs = HttpUtility.ParseQueryString(url);
        //          prs.Remove(param);
        //          return HttpUtility.UrlDecode(prs.ToString());
        //      }
        //      public static string EscapeUrlToThisPage
        //      {
        //          get {

        //              string caller = Common.GetUrlParameterAsString("caller", "");
        //              string thisPage = "";
        //              if ( caller == "" ) {
        //                  thisPage = HttpContext.Current.Request.Url.ToString();
        //                  thisPage = ToRelativeUrl(thisPage);
        //              } else {
        //                  thisPage = caller;
        //              }

        //              return HttpUtility.UrlEncode(thisPage.Replace("amp;",""));
        //          }
        //      }

        //      public static string ToRelativeUrl(string absoluteUrl)
        //      {
        //          string[] myFolders = {"WEBCommon", "WEBDetail", "WEBDocument", "WEBDiagnostics",
        //                         "WEBLogin", "WEBMenu", "WEBPanel", "WEBPayment",
        //                         "WEBReports", "WEBSearch", "WEBTemplate"};

        //          int minIndex = -1;
        //          foreach (string folder in myFolders) {
        //              int idxOfFolder = absoluteUrl.IndexOf(folder, StringComparison.CurrentCultureIgnoreCase);
        //              if (idxOfFolder != -1 && (minIndex == -1 || idxOfFolder < minIndex)) {
        //                  minIndex = idxOfFolder;
        //              }
        //          }

        //          if ( minIndex != -1 ) {
        //              string rel = absoluteUrl.Substring(minIndex);
        //              return "../" + rel;
        //          }

        //          // TODO Compress url
        //          return absoluteUrl;
        //      }

        //      public static string ToAbsoluteUrl( string relativeUrl )
        //      {
        //          string absUrl = HttpContext.Current.Request.Url.AbsoluteUri;
        //          string currFileName = new FileInfo(HttpContext.Current.Request.Url.LocalPath).Name;

        //          int indexOfName = absUrl.IndexOf(currFileName,StringComparison.InvariantCultureIgnoreCase);
        //          string newAbsUrl = absUrl.Remove(indexOfName-1);

        //          int indexOfLastPathDelim = newAbsUrl.LastIndexOf("/");
        //          newAbsUrl = newAbsUrl.Remove(indexOfLastPathDelim);

        //          if ( relativeUrl.StartsWith("../")) {
        //              string newRelUrl = relativeUrl.Replace("../", "/");
        //              return newAbsUrl + newRelUrl;
        //          }

        //          return relativeUrl;
        //      }

        //      public static string EscapeUrl( bool forDocument )
        //      {
        //          // if escape url is specified in parameter, take it first
        //          string escapeUrlFromUrl = HttpUtility.UrlDecode(Common.GetUrlParameterAsString("escapeUrl", "",false));
        //          if (escapeUrlFromUrl != "") {
        //              // if there is escapeUrl parameter in escaped url, it needs to be escaped again
        //              string escapeUrlTL = escapeUrlFromUrl.ToLower();
        //              string findSymbol = "&escapeurl=";
        //              int start = escapeUrlTL.IndexOf(findSymbol);
        //              string toEncode = "";
        //              if (start != -1) {
        //                  toEncode = escapeUrlFromUrl.Substring(start + findSymbol.Length);
        //                  string encoded = HttpUtility.UrlEncode(toEncode);
        //                  escapeUrlFromUrl = escapeUrlFromUrl.Replace(toEncode, encoded);
        //              }

        //              return escapeUrlFromUrl;
        //          }

        //          if ( forDocument ) {

        //              string[,] overrideParams = new string[,] {
        //                              {"docObject", null},
        //                              {"documentMode", null}, // Reset document modifiers
        //                              {"setContact", null},
        //                              {"setHeader", null},
        //                              {"addVART", null},
        //                              {"addGTIN", null}};

        //              var escapeUrl = DwcDocumentBase.DeviceSettings.EscapeUrl;
        //              if (escapeUrl == " ") // In TPOMM is currently impossible to store empty value, so this is ojebavka
        //              {
        //                  escapeUrl = "";
        //              }

        //              if (escapeUrl == "") {

        //                  if ( DwcDocumentCore.IsForPublicUse ) {
        //                      return DwcDocumentCore.RefererUrl;
        //                  }

        //                  DwcWebMenuNode cn = DwcMenuCore.CurrentNode;
        //                  if (cn._menuNode != null && !(cn._menuNode.EscapeUrl == "" || cn._menuNode.EscapeUrl == " "))
        //                  {
        //                      return Common.SetUrlParams(DwcVarEngine.ProcessString(cn._menuNode.EscapeUrl), overrideParams);
        //                  }
        //                  else
        //                  {
        //                      // Escape to menu
        //                      return Common.SetUrlParams("../WEBMenu/Menu.aspx", overrideParams);
        //                  }

        //              } else {
        //                  // Escape to escape url from device settings of document
        //                  return Common.SetUrlParams(DwcVarEngine.ProcessString(DwcDocumentBase.DeviceSettings.EscapeUrl), overrideParams);
        //              }
        //          }

        //          DwcWebMenuNode node = DwcMenuCore.CurrentNode;
        //          if (node != null)
        //          {
        //              var escapeUrl = node._menuNode.EscapeUrl;
        //              if (escapeUrl == " ") // In TPOMM is currently impossible to store empty value, so this is ojebavka
        //              {
        //                  escapeUrl = "";
        //              }

        //              if (node._menuNode != null && escapeUrl != "")
        //              {
        //                  // Escape to escape url from menu
        //                  return Common.SetUrlParams(DwcVarEngine.ProcessString(escapeUrl), null);
        //              }
        //              else
        //              {
        //                  return DwcMenuCore.UpOneLevelUrl;
        //              }
        //          }

        //          return "#";
        //      }

        //      public static string UniClick(string content)
        //      {
        //          return UniClick(content, null);
        //      }

        //      public static int ContextHelpTimeout
        //      {
        //          get {
        //              return 500;
        //          }
        //      }

        //      public static string UniClick(string content, string contextContent) {
        //          if ( contextContent == null ) {
        //              return @" ontouchstart=""this.tPh=1;"" ontouchmove=""this.tPh=0;"" ontouchend=""if(this.tPh==1){" + content + @"}"" onclick=""if(dwcITD()==false){" + content + @"}"" ";
        //          } else {
        //              return @" ontouchstart=""this.tPh=1;this.tTm=setTimeout(function(){" + contextContent + @"}, " + ContextHelpTimeout + @");"" ontouchmove=""this.tPh=0;if(this.tTm){clearTimeout(this.tTm);};"" ontouchend=""if(this.tTm){clearTimeout(this.tTm);};if(this.tPh==1){" + content + @"}"" onclick=""if(dwcITD()==false){" + content + @"}"" oncontextmenu=""if(!dwcITD()){" + contextContent + @"};return false;"" ";
        //          }
        //      }

        //      public static string ContextHelpClick(string contextContent) {
        //          return @" ontouchstart=""this.tPh=1;this.tTm=setTimeout(function(){" + contextContent + @"}, " + ContextHelpTimeout + @");"" ontouchmove=""this.tPh=0;if(this.tTm){clearTimeout(this.tTm);};"" ontouchend=""if(this.tTm){clearTimeout(this.tTm);};"" oncontextmenu=""if(dwcITD()==false){" + contextContent + @"};return false;"" ";
        //      }

        //      public static string SettingsButtonCode
        //      {
        //          get {
        //              string command = @"dwcChangeSettings();";
        //              return @"<a data-role=""button"" data-inline=""true"" data-icon=""gear"" href=""#"" " + Common.UniClick(command) + " >" + DwcLocale.Localize("{loc:cf.Settings}") + "</a>";
        //           }
        //      }


        //      public static string SettingsText
        //      {
        //          get {
        //              return Common.IsControlMouse ? DwcLocale.Localize("{loc:dwc.control.mouse}") : DwcLocale.Localize("{loc:dwc.control.touch}");
        //          }
        //      }

        //      /// <summary>
        //      /// FOOTER
        //      /// </summary>
        //      public static string VersionText
        //      {
        //          get {
        //              string displayCss = "";
        //              if ( Common.GetUrlParameterAsString("autoLogin", "") != "" || Common.InPOSFlowContext) {
        //                  displayCss = @" style=""display:none"" ";
        //              }

        //              return string.Format(@"{1}<br/>{0}{5}<br/><a " + displayCss + @" data-role=""button"" data-inline=""true"" data-icon=""back"" href=""#"" {2}>{3}</a>{4}",
        //                  VersionTextBase,
        //                  LogonText,
        //                  UniClick(@"dwcLogOut();"),
        //                  DwcLocale.Localize("{loc:drp.LogoutText}"),
        //                  SettingsButtonCode,
        //                  SettingsText);
        //          }

        //      }

        //      public static string VersionTextBase
        //      {
        //          get {
        //              return string.Format(@"<center><span>{4}</span><span>&nbsp;&nbsp;{0}&nbsp;{1}{2}{3}</span></center>",
        //                  DwcSettingsBase.DwcWebClientName,
        //                  DwcLocale.Localize("v"),
        //                  DwcSettingsBase.DwcVersion,
        //                  // Here we directly use ProperlyConfiguredSlotID to be sure we are in properly configured slot version
        //                  Common.ProperlyConfiguredSlotID == null ? "" : ("&nbsp;Slot:" + Common.ProperlyConfiguredSlotID),
        //                  @"<img class=""dwcDiagnosticsSignalImage"" src=""../WEBDiagnostics/ImagesA/signal4.png"" style=""visibility:hidden;width:1em;height:0.8em;"" />");
        //          }
        //      }

        //      public static string SettingsContent
        //      {
        //          get
        //          {
        //              StringBuilder sb = new StringBuilder();

        //              sb.Append(@"<br/>");
        //              sb.Append(@"<h4>" + DwcLocale.Localize("{loc:dwc.language.choose}") + ":<h4>");
        //              sb.Append(LanguagePicker);
        //              sb.Append("<br/>");
        //              sb.Append(@"<h4>" + DwcLocale.Localize("{loc:dwc.control.choose}") + "<h4>");
        //              if (Common.CurrentControl == ControlType.mouse)
        //              {
        //                  sb.Append(@"<select  id=""settingsControl""> <option value=""Touch"">" + DwcLocale.Localize("{loc:dwc.control.touch}") + @"</option> <option value=""Mouse"" selected=""selected"">" + DwcLocale.Localize("{loc:dwc.control.mouse}") + @"</option></select>");
        //              }
        //              else
        //              {
        //                  sb.Append(@"<select  id=""settingsControl""> <option value=""Touch"" selected=""selected"">" + DwcLocale.Localize("{loc:dwc.control.touch}") + @"</option> <option value=""Mouse"">" + DwcLocale.Localize("{loc:dwc.control.mouse}") + @"</option></select>");
        //              }

        //              return sb.ToString();
        //          }
        //      }

        //      public static string LanguagePicker
        //      {
        //          get
        //          {
        //              StringBuilder sb = new StringBuilder();

        //              sb.Append(@"<select id=""languagePicker"">");
        //              foreach (WebClientLanguage l in DwcSettingsBase.WebClientSettings.OverallSettings.Languages.WebClientLanguages)
        //              {
        //                  if (l.ISOCode.ToLower() == Common.GetParamLanguageCode().ToLower())
        //                  {
        //                      sb.Append(@"<option value=""" + l.ISOCode + @""" selected=""selected"">" + l.Caption + "</option>");
        //                  }
        //                  else
        //                  {
        //                      sb.Append(@"<option value=""" + l.ISOCode + @""">" + l.Caption + "</option>");
        //                  }
        //              }
        //              sb.Append(@"</select>");

        //              return sb.ToString();
        //          }
        //      }

        //      public static string PrintLanguagePicker
        //      {
        //          get
        //          {
        //              StringBuilder sb = new StringBuilder();
        //              DocSettingsPrintForm dpf = null;
        //              int pfCount = 0;
        //              string device = Common.GetUrlParameterAsString("deviceId", "");

        //              sb.Append(@"<select id=""printLanguagePicker"">");

        //              foreach (DocDeviceSettings d in DwcDocumentBase.DocObject.Settings.DevicesSettings.DocSettingsDevices)
        //              {
        //                  if (d.DeviceId.ToString() == device)
        //                  {
        //                      foreach (DocSettingsPrintForm pf in d.SettingsPrintForms.DocSettingsPrintForms)
        //                      {
        //                          if (pf.LanguageCode.ToLower() == Common.GetParamLanguageCode().ToLower())
        //                          {
        //                              sb.Append(@"<option value=""" + pf.LanguageCode + @""" selected=""selected"">" + pf.Caption + "</option>");
        //                          }
        //                          else
        //                          {
        //                              sb.Append(@"<option value=""" + pf.LanguageCode + @""">" + pf.Caption + "</option>");
        //                          }

        //                          dpf = pf;
        //                          pfCount++;
        //                      }

        //                      break;
        //                  }
        //              }

        //              sb.Append(@"</select>");


        //              if (pfCount == 1)
        //              {
        //                  return dpf.LanguageCode;
        //              }

        //              return sb.ToString();
        //          }
        //      }

        //      public static string VersionTextNoLogout
        //      {
        //          get
        //          {
        //              return string.Format(@"{1}<br/>{0}",
        //                  VersionTextBase,
        //                  LogonText);
        //          }

        //      }

        //      public static string VersionTextNoLogonInfo
        //      {
        //          get
        //          {
        //              return VersionTextBase;
        //          }

        //      }

        //      public static bool InPOSFlowContext
        //      {
        //          get {
        //              return Common.GetUrlParameterAsString("posFlow", "0") == "1";
        //          }
        //      }

        //      public static bool InTPNetContext
        //      {
        //          get {
        //              return Common.GetUrlParameterAsString("tpNet", "0") == "1";
        //          }
        //      }

        //      public static string LogonText
        //      {
        //          get {
        //              string baseText = DwcLocale.Localize("{loc:drs.WebClient.LogonText}");
        //              string userName = DwcSecurity.CurrentUserName;
        //              string branch = Common.GetParamBranchForDisplay();
        //              string str = string.Format(baseText, userName, branch);

        //              return str;
        //          }
        //      }
        //      public static string ExpirationText(string user)
        //      {


        //              double days = (DwcSecurity.CurrentUserAccount.PasswordExpiration - DateTime.Now.Date).TotalDays;
        //              if (days < 7)
        //                  return string.Format("Password will expire in {0} days.", days);

        //              return "";
        //      }

        //      public static string HeaderControls(string left, string top, string caption, bool enableExitButton)
        //      {
        //          string exitButtonCode = "";
        //          DwcWebMenuNode dwmn = DwcMenuCore.CurrentAppNode;
        //          if ( enableExitButton && dwmn != null ) {
        //              string url = Common.SetUrlParams(dwmn.Url, new string[,] {
        //                  {"menu", dwmn._menuNode.Id.ToString()},
        //                  {"escapeUrl", null},
        //                  {"docObject", null}
        //              });

        //              exitButtonCode = @"<a data-role=""button"" style=""float:left;"" data-icon=""home"" data-iconpos=""notext"" href=""#"" " + Common.UniClick("dwcHome('" + url + "');") +  @"></a>";
        //          }
        //          return @"<div style=""position:absolute;left:"  + left +  @"em;top:" + top + @"em;"">" + exitButtonCode + @"<div style=""float:right;margin-left:0.5em;margin-top:14px"">&nbsp;" + caption + @"</div></div> ";
        //      }

        //      public static string HeaderControlsV1( string caption )
        //      {
        //          return HeaderControls( "5.5", "0.2", caption, true);
        //      }

        //      public static string HeaderControlsV2( string caption )
        //      {
        //          return HeaderControls("3", "0.4", caption, false);
        //      }

        //      public static string FormatContactString(ContactDataElement ci)
        //      {
        //          if ( ci == null ) {
        //              return "";
        //          }
        //          return ci.GetValue(ContactValues.FirstName) + " " + ci.GetValue(ContactValues.LastName);
        //      }

        public static string CurrentTimestamp
        {
            get
            {
                return DateTime.Now.Ticks.ToString("x").Substring(0, 8);
            }
        }

        //      public static bool IsDebug
        //      {
        //          get
        //          {
        //              return Common.GetUrlParameterAsString("debug", "0") == "1";
        //          }

        //      }
        //      /*
        //      public static string BarcodeInputManualButtonDoScanSearch
        //      {
        //          get
        //          {
        //              return BarcodeInputManualButtonDoScan(DwcSearchCore.InputId);
        //          }
        //      }

        //      public static string BarcodeInputManualButtonSearch
        //      {
        //          get {
        //              return BarcodeInputManualButton(DwcSearchCore.InputId);
        //          }
        //      }

        //      public static string BarcodeInputManualButton(string inputId)
        //      {
        //              return @"<a href=""#"" data-role=""button"" data-mini=""true"" " + Common.UniClick(@"dwcShowBarcodePopup(" + inputId + "ScannerProcess);") + @">
        //                      <img src=""../Framework/jQueryMobileExtend/images/barcode.png"" style=""max-height:1.8em;cursor:pointer;"" alt="""" />
        //                  </a>";
        //      }

        //      public static string BarcodeInputManualButtonDoScan(string inputId)
        //      {
        //          string code = @"<td style=""width:4em;""><a href=""#"" data-role=""button"" data-mini=""true"" " + Common.UniClick(@"dwcScannerButtonClick(" + inputId + "ScannerProcess,this);") + @">
        //                      <img src=""../Framework/jQueryMobileExtend/images/barcodesc22.png"" style=""max-height:1.8em;cursor:pointer;"" alt="""" />
        //                  </a></td>";

        //          return DwcSettingsBase.CurrentScannerType == WebClientBarcodeScannerType.Manual ? code : "";
        //      }*/

        //      public static int CurrentThemeId
        //      {
        //          get
        //          {
        //              return Common.GetUrlParameterAsInt("theme", -1);
        //          }

        //      }

        //      public static ControlType CurrentControl
        //      {
        //          get
        //          {
        //              if (HttpContext.Current.Request.Cookies["dwcControlType"] != null)
        //              {
        //                  string value = HttpContext.Current.Request.Cookies["dwcControlType"].Value;

        //                  if (value == "")
        //                  {
        //                      return DwcSettingsBase.WebClientSettings.OverallSettings.DefaultControlType;
        //                  }


        //                  if ( value.ToLower() == "mouse" )
        //                  {
        //                      return ControlType.mouse;
        //                  }
        //                  else
        //                  {
        //                      return ControlType.touch;
        //                  }
        //              }

        //              return DwcSettingsBase.WebClientSettings.OverallSettings.DefaultControlType;
        //              //return "touch";
        //          }
        //      }

        //      public static bool IsControlMouse
        //      {
        //          get {
        //              return CurrentControl == ControlType.mouse;
        //          }
        //      }

        //      public static bool IsControlTouch
        //      {
        //          get {
        //              return CurrentControl == ControlType.touch;
        //          }
        //      }

        public static string[] MovableParams
        {
            get
            {
                string[] movableParams = {
                          "language",
                          "branch",
                          "deviceId",
                          "posFlow",
                          "tpNet",
                          "publicApp",
                          "autoLogin",
                          "menu",
                          "docObject",
                          "scanner",
                          "noPrint",
                          "setContact",
                          "debug",
                          "theme",
                          "setHeader",
                          "documentMode",
                          "rsPrintFormat",
                          "layout",
                          "appNode",
                    "customerLanguage",
                          "hideRSFilters",
                          //"multipleItems",
                          "miguid",
                          "posCacheFilter"
                      };

                return movableParams;
            }
        }

        public static string SetUrlParams(string url)
        {
            return SetUrlParams(url, null);
        }

        /// <summary>
        /// Method Set Url for field overrideParams
        /// </summary>
        /// <param name="url">current url</param>
        /// <param name="overrideParams"></param>
        /// <returns>set new url</returns>
        public static string SetUrlParams(string url, string[,] overrideParams)
        {
            if (url.ToLower().StartsWith("javascript"))
            {
                return url;
            }

            string[] spl = url.Split('?');
            string query = spl.Length >= 2 ? spl[1] : "";
            bool qMark = (query == "");

            // Append non existing
            foreach (string p in MovableParams)
            {
                string currVal = Common.GetUrlParameterAsString(p, "");
                if (currVal == "")
                {
                    continue;
                }

                // Special parameters which needs encode
                //if (p == "escapeUrl")
                //{
                //    currVal = HttpUtility.UrlEncode(currVal);
                //}

                string[] splitted = currVal.Split(',');
                if (splitted.Length > 1)
                {
                    currVal = splitted[0].Length > 0 ? splitted[0] : splitted[1];
                }
                if (!query.ToLower().Contains(p.ToLower()))
                {
                    if (qMark)
                    {
                        url += "?" + p + "=" + currVal;
                        qMark = false;
                    }
                    else
                    {
                        var indexOfHash = url.IndexOf("#");
                        if (indexOfHash == -1)
                        {
                            url += "&" + p + "=" + currVal;
                        }
                        else
                        {
                            url = url.Insert(indexOfHash, "&" + p + "=" + currVal);
                        }
                    }
                }
            }

            if (overrideParams != null)
            {
                for (int i = 0; i < overrideParams.GetLength(0); i++)
                {
                    if (string.IsNullOrEmpty(overrideParams[i, 0]))
                    {
                        continue;
                    }
                    url = SetParameterToUrl(url, overrideParams[i, 0], overrideParams[i, 1]); // Set params for URL
                }
            }
            return SetParameterToUrl(url, "cts", CurrentTimestamp); // Set last position timestamp
        }

        //      public static void UrlScannerProcessBeforeLogin()
        //      {
        //          // TODO MOVE TO URLSCANNERPROCESS AFTER DEMO END (NEED MOVE URLSCANNER PROCESS BEFORE LOGIN PROCESS
        //          string source = Common.GetUrlParameterAsString("source", "");
        //          string q = Common.GetUrlParameterAsString("q", "");
        //          if (source.ToLower() == "pic2shop" && q.Length > 0)
        //          {

        //              HttpCookie cok = HttpContext.Current.Request.Cookies.Get("Pic2ShopCallback");
        //              if (cok != null)
        //              {
        //                  string url = HttpUtility.UrlDecode(cok.Value) + "&ean=" + q;
        //                  HttpContext.Current.Response.Redirect(url);
        //                  HttpContext.Current.Response.End();
        //                  return;
        //              }

        //          }
        //      }

        //      public static void UrlScannerProcess( DwcBarcodeContext context )
        //      {
        //          // Check for software scanner callbacks url
        //          if (DwcSearchCore.UrlScannerEnabled)
        //          {
        //              string ean = Common.GetUrlParameterAsString("ean", "");
        //              string qr = Common.GetUrlParameterAsString("qr", "");
        //              if (ean != "")
        //              {
        //                  DwcBarcode.Process(ean, DwcBarcodeCallerSide.Server, context, "ean");
        //              }
        //              if (qr != "")
        //              {
        //                  DwcBarcode.Process(qr, DwcBarcodeCallerSide.Server, context, "qr");
        //              }
        //          }
        //      }

        //      public static string GetConnectionStringById( string connStringId )
        //      {
        //          DwcSettingsBase.InitializeConnectionStrings();
        //          string connString = ERPTools.CFConnectionString;
        //          if ( connStringId == "RFCConnectionString" ) {
        //              connString = ERPTools.RFCConnectionString;
        //          }
        //          else if (connStringId == "MARSConnectionString" ) {
        //              connStringId = ERPTools.MARSConnectionString;
        //          }
        //          else if (connStringId == "LocConnectionString")
        //          {
        //              connStringId = ERPTools.LocConnectionString;
        //          }

        //          return connString;
        //      }

        //      public static void CopyStream(Stream input, Stream output)
        //      {
        //          byte[] buffer = new byte[32768];
        //          int read;
        //          while ((read = input.Read(buffer, 0, buffer.Length)) > 0)
        //          {
        //              output.Write(buffer, 0, read);
        //          }
        //      }

        //      public static void DisableCacheToResponse()
        //      {
        //          HttpContext.Current.Response.Cache.SetAllowResponseInBrowserHistory(false);
        //          HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.NoCache);
        //          HttpContext.Current.Response.Cache.SetNoStore();
        //          HttpContext.Current.Response.Cache.SetExpires(DateTime.Now);
        //          HttpContext.Current.Response.Cache.SetValidUntilExpires(true);
        //      }

        //      public static bool SetCacheToResponse(int clientCacheDurationInHours, string resourceETag, DateTime ifModifiedSince )
        //      {
        //          // Check and optionally send 304 to response
        //          if (HttpContext.Current.Request.Headers["If-None-Match"] == resourceETag) {
        //              HttpContext.Current.Response.Clear();
        //              HttpContext.Current.Response.StatusCode = (int) System.Net.HttpStatusCode.NotModified;
        //              HttpContext.Current.Response.SuppressContent = true;
        //              HttpContext.Current.Response.End();
        //              return true;
        //          }

        //          HttpContext.Current.Response.Cache.SetCacheability(HttpCacheability.Public);
        //          HttpContext.Current.Response.Cache.SetMaxAge(new TimeSpan(clientCacheDurationInHours, 0, 0));
        //          HttpContext.Current.Response.Cache.SetExpires(DateTime.Now.AddHours(clientCacheDurationInHours));
        //          HttpContext.Current.Response.Cache.SetETag(resourceETag);
        //          HttpContext.Current.Response.Cache.SetLastModified(ifModifiedSince);

        //          return false;
        //      }

        //      public static bool HandleCacheToResponse()
        //      {
        //          if (DwcSmartCache.IsThisRequestCachedRequest)
        //          {

        //              return SetCacheToResponse(DwcSmartCache.GetClientCacheDurationInHours, DwcSmartCache.ResourceETag, DwcSmartCache.ResourceModifiedDate );
        //          }
        //          else
        //          {
        //              DisableCacheToResponse();
        //          }
        //          return false;
        //      }

        //      public static bool StdHandlerPreInit()
        //      {
        //          return StdHandlerPreInit(true);
        //      }

        //      public static bool StdHandlerPreInit(bool checkStdLogin)
        //      {
        //          DwcLocale.SetLanguageLocale();
        //          DwcContext.SetupContext();
        //          if (Common.HandleCacheToResponse()) {
        //              // 304
        //              return false;
        //          }

        //          if ( checkStdLogin ) {
        //              if ( DwcSecurity.CurrentUserAccountTest == null ) {
        //                  return false;
        //              }
        //          }

        //          return true;
        //      }

        //      public static string StartPointsContent
        //      {
        //          get {
        //              StringBuilder bld = new StringBuilder();

        //              bld.AppendLine(@"<center><h3>" + DwcLocale.Localize("{loc:dwc.invalidStartpoint}") + "</h3></center>");
        //              bld.AppendLine(@"<hr/>");
        //              bld.AppendLine(@"<ul data-role=""listview"">");

        //              foreach( WebClientLink wcl in DwcSettingsBase.WebClientSettings.LinksCollection.WebClientLinks ) {

        //                  string printDevice = "Device:";
        //                  foreach(WebClientDevice d in DwcSettingsBase.WebClientSettings.Devices.WebClientDevices) {
        //                      if ( d.Id.ToString() == wcl.Device ) {
        //                          printDevice += wcl.Device + "(" + d.Name + ")";
        //                      }
        //                  }
        //                  string printLayout = "Layout:" + wcl.Layout;
        //                  string printBranch = "Branch:" + wcl.Branch;
        //                  string printLanguage = "Language:" + wcl.Language;
        //                  string printServer = "Server:" + wcl.Ip + "(" + DwcVarEngine.ProcessString("#Global:" + wcl.Ip + "#") + ")";

        //                  bld.AppendLine(@"<li><a id=""menuNode" + wcl.Id + @""" href=""#"" data-transition=""none"" " +Common.UniClick("dwcRedirectWithHistory('" + Common.GetUrlFromStartPointID(wcl.Id) + @"');"));
        //                  bld.Append(@" data-ajax=""false"" ");
        //                  bld.AppendLine(">");
        //                  bld.AppendLine(@"<h3>" + wcl.Id + " [" + printServer + "," + printLanguage + "," + printDevice + "(" + printLayout + ")," + printBranch + "]" +  @"</h3>");
        //                  bld.AppendLine(@"</a></li>");
        //              }

        //              bld.Append(@"</ul>");
        //              return bld.ToString();
        //          }
        //      }

        //      /// <summary>
        //      /// Method for StartPoint
        //      /// </summary>
        //      /// <returns>set URL</returns>
        //      public static string GetUrlFromStartPointID(string startPointID)
        //      {
        //          if ( startPointID == null ) {
        //              return null;
        //          }

        //          string startPointIDTL = startPointID.ToLower();
        //          foreach( WebClientLink wcl in DwcSettingsBase.WebClientSettings.LinksCollection.WebClientLinks ) {
        //              if ( wcl.Id.ToLower() == startPointIDTL) {

        //                  StringBuilder bld = new StringBuilder();
        //                  bld.Append( wcl.Protocol );
        //                  bld.Append("://");
        //                  bld.Append( "#Global:" + wcl.Ip + "#" );
        //                  if ( wcl.Port != 80 ) {
        //                      bld.Append( ":" + wcl.Port.ToString() );
        //                  }
        //                  bld.Append( "/" );
        //                  bld.Append(DwcSettingsBase.WebClientSettings.OverallSettings.ApplicationNameRespectSlot);
        //                  bld.Append( "/" );

        //                  string path = DwcMenuCore.NodeIdToUrl(wcl.MenuId, -1, true);
        //                  bld.Append(path);
        //                  string url = DwcVarEngine.ProcessString(bld.ToString());

        //                  // Requried attributes
        //                  url = SetParameterToUrl(url, "deviceId", wcl.Device);
        //                  url = SetParameterToUrl(url, "language", wcl.Language);
        //                  url = SetParameterToUrl(url, "branch", wcl.Branch.ToString());

        //                  url = SetParameterToUrl(url, "scanner", wcl.ScannerType.ToString());

        //                  // Not required attributes
        //                  if ( wcl.Layout != DocDeviceSettingsLayout.Default ) {
        //                      url = SetParameterToUrl(url, "layout", wcl.Layout.ToString());
        //                  }
        //                  if ( wcl.Theme != 0 ) {
        //                      url = SetParameterToUrl(url, "theme", wcl.Theme.ToString());
        //                  }
        //                  if (false == string.IsNullOrEmpty(wcl.AutoLogin) ) {
        //                      url = SetParameterToUrl(url, "autoLogin", wcl.AutoLogin);
        //                  }
        //                  if (false == string.IsNullOrEmpty(wcl.DocumentMode) ) {
        //                      url = SetParameterToUrl(url, "documentMode", wcl.DocumentMode);
        //                      HttpContext.Current.Session["documentMode"] = wcl.DocumentMode;
        //                  }
        //                  if (false == string.IsNullOrEmpty(wcl.EscapeUrl) ) {
        //                      url = SetParameterToUrl(url, "escapeUrl", HttpUtility.UrlEncode(DwcVarEngine.ProcessString(wcl.EscapeUrl)));
        //                  }
        //                  if (wcl.NoPrint) {
        //                      url = SetParameterToUrl(url, "noPrint", "1");
        //                  }
        //                  if (wcl.Debug) {
        //                      url = SetParameterToUrl(url, "debug", "1");
        //                  }
        //                  if (wcl.PosFlow) {
        //                      url = SetParameterToUrl(url, "posFlow", "1");
        //                  }
        //                  if (wcl.TPNet) {
        //                      url = SetParameterToUrl(url, "tpNet", "1");
        //                  }
        //                  if (wcl.PublicApp) {
        //                      url = SetParameterToUrl(url, "publicApp", "1");
        //                  }
        //                  if (wcl.PrintFormat != PrintFormat.PDF ) {
        //                      url = SetParameterToUrl(url, "rsPrintFormat", wcl.PrintFormat.ToString());
        //                  }
        //                  if (wcl.HideRSFilters == true)
        //                  {
        //                      url = SetParameterToUrl(url, "hideRSFilters", wcl.HideRSFilters.ToString());
        //                  }
        //                  if (wcl.PosCacheFilter == true)
        //                  {
        //                      url = SetParameterToUrl(url, "PosCacheFilter", wcl.PosCacheFilter.ToString());
        //                  }

        //                  return url;
        //              }
        //          }

        //          return null;
        //      }

        //      public static void RedirectFromStartPointUrl(string startPointID, string[,] optionalParams)
        //      {
        //          string url = GetUrlFromStartPointID(startPointID);
        //          if ( url != null ) {
        //              if ( optionalParams != null ) {
        //                  url = SetUrlParams(url, optionalParams);
        //              }
        //              HttpContext.Current.Response.Redirect(url);
        //          } else {
        //              HttpContext.Current.Response.Redirect("../StartPoint/Redirect.aspx");
        //          }
        //      }

        //public static bool RunningInIframe
        //      {
        //          get {
        //              return Common.GetUrlParameterAsString("iframe","0") == "1";
        //          }
        //}

        //      public static int[] ExpandBranchesAccordingToSumGroup( int[] branches, out bool expanded )
        //      {
        //          if ( branches == null ) {
        //              expanded = false;
        //              return null;
        //          }

        //          expanded = false;
        //          Hashtable htbl = new Hashtable();
        //          foreach(int b in branches) {
        //              List<int> sumShops = DwcSettingsBase.ShopGroupsCollection.GetShopsFromSumShopGroupOfShops(b);
        //              if ( sumShops != null ) {
        //                  foreach( int sumS in sumShops) {
        //                      htbl[sumS] = sumS;
        //                  }
        //              }
        //              htbl[b] = b;
        //          }

        //          List<int> res = new List<int>();
        //          foreach(int b in htbl.Keys ) {
        //              res.Add(b);
        //          }

        //          expanded = (res.Count != branches.Length);

        //          return res.ToArray();
        //      }

        //      public static List<int> ExpandBranchesAccordingToSumGroup( List<int> branches, out bool expanded )
        //      {
        //          int[] res = ExpandBranchesAccordingToSumGroup( branches.ToArray(), out expanded );
        //          return new List<int>(res);
        //      }

        //      public static string GetPaymentMethodVariableValue(PaymentMethod pm, string variable, string defaultValue)
        //      {
        //          if ( pm.Variables != null && pm.Variables.Variables != null && pm.Variables.Variables.ContainsKey(variable)) {
        //              return pm.Variables.Variables[variable].Value;
        //          }
        //          return defaultValue;
        //      }
        /*
        public static string MinifyJavascript(string source)
        {
            Minifier minifier = new Minifier();
            return minifier.MinifyJavaScript(source);
        }

        public static string MinifyCss(string source)
        {
            Minifier minifier = new Minifier();
            CssSettings set = new CssSettings();
            set.CommentMode = CssComment.None;
            return minifier.MinifyStyleSheet(source, set);
        }

        public static void StdPagePreInit(bool callLogin, bool deviceRedirection, bool documentSetup)
        {
            StdPagePreInit(callLogin, deviceRedirection, documentSetup, true, true);
        }

        public static void ProcessDocumentRedirectionAfterBook()
        {
            if (DwcDocumentCore.IsDocumentAccessRedirectToMenu) {
                DwcDocumentCore.ResetDocumentAccessRedirectToMenu();
                if ( DwcDocumentBase.DeviceSettings.RestartAfterBook ) {
                    DocSettings s = DwcDocumentBase.DocumentSettings;
                    HttpContext.Current.Response.Clear();
                    HttpContext.Current.Response.Redirect(Common.SetUrlParams("../WEBDocument/Document?docType=" + (int)s.DocType + "&docSubType=" + s.DocSubType,
                                                                                            new string[,] {{ "docObject", null},{"needRefresh", "1"},{"editMode",null}}));
                    HttpContext.Current.Response.End();
                } else {
                    HttpContext.Current.Response.Clear();
                    HttpContext.Current.Response.Redirect(Common.SetUrlParams(Common.EscapeUrl(true),
                                                                                            new string[,] {{ "docObject", null},{"needRefresh", "1"}}));
                    HttpContext.Current.Response.End();
                }
            }
        }

        public static void StdPagePreInit( bool callLogin, bool deviceRedirection, bool documentSetup, bool checkMSLogin, bool doMSDeviceRedirection )
        {
            if (HandleCacheToResponse())
            {
                // 304
                return;
            }

            // check if branch exists
            int branch = Common.GetUrlParameterAsInt("branch", 0);
            bool invalidBranchExist = Common.GetUrlParameterAsString("invalidBranch", "0") == "1";
            List<int> validBranches = DwcSettingsBase.AllBranches;

            ArticleCache.POSGroupRecUID = ERPTools.GetPOSGroup(branch);
            ArticleCache.SecondaryPOSGroupRecUID = ERPTools.GetSecondaryPOSGroup(branch);

            if (branch != 0 && !validBranches.Contains(branch) && !invalidBranchExist)
            {
                if (!Common.CheckExistingBranch(branch))
                {
                    HttpContext.Current.Response.Redirect(HttpContext.Current.Request.RawUrl + "&invalidBranch=1");
                    return;
                }
            // if set invalidBranch param - check from cache and DB
            }else if(invalidBranchExist)
            {
                if (validBranches.Contains(branch))
                {
                      HttpContext.Current.Response.Redirect(Common.RemoveParameterFromUrl(HttpContext.Current.Request.RawUrl, "invalidBranch"));
                      return;
                }
                else if(Common.CheckExistingBranch(branch))
                {
                      HttpContext.Current.Response.Redirect(Common.RemoveParameterFromUrl(HttpContext.Current.Request.RawUrl, "invalidBranch"));
                      return;
                }
            }

            DwcCache.SetConnectionDisposer();

            if (HttpContext.Current.Request != null
                && HttpContext.Current.Request.UserAgent != null
                && HttpContext.Current.Request.UserAgent.ToLower().Contains("opera mini")) {
                    HttpContext.Current.Response.Redirect("../WEBCommon/Error.aspx?operaMini=1");
            }

            if (deviceRedirection && DwcSettingsBase.DeviceRedirectionProcess())
            {
                // PJO HttpContext.Current.Response.Flush();
                return;
            }

            DwcLocale.SetLanguageLocale();
            DwcContext.SetupContext();

            if (callLogin) {
                DwcSecurity.CheckAndRedirect(false);
            }

            if (documentSetup) {
                if (DwcDocumentBase.DocumentRedirectionProcess()) {
                    return;
                }

                // At this point we have document object
                if (DwcDocumentBase.DocObject.DocStatus == DocStatus.Booked) {
                    ProcessDocumentRedirectionAfterBook();
                }

                if (HttpContext.Current.Request.UrlReferrer != null
                    &&
                    (HttpContext.Current.Request.UrlReferrer.AbsoluteUri.IndexOf(@"/webdocument/", StringComparison.InvariantCultureIgnoreCase) == -1
                     || HttpContext.Current.Request.UrlReferrer.AbsoluteUri.IndexOf(@"/webdocument/documentinventory", StringComparison.InvariantCultureIgnoreCase) != -1
                     || HttpContext.Current.Request.UrlReferrer.AbsoluteUri.IndexOf(@"/webdocument/documentreplenishment", StringComparison.InvariantCultureIgnoreCase) != -1)
                    &&
                    // We can remember referer if it is contact search which was NOT called from document
                    ((
                    HttpContext.Current.Request.UrlReferrer.AbsoluteUri.IndexOf(@"/websearch/contactsearch", StringComparison.InvariantCultureIgnoreCase) == -1
                    && HttpContext.Current.Request.UrlReferrer.AbsoluteUri.IndexOf(@"/websearch/contactexternsearch", StringComparison.InvariantCultureIgnoreCase) == -1
                    )
                    || HttpContext.Current.Request.UrlReferrer.AbsoluteUri.IndexOf(@"fromdocumentitem=", StringComparison.InvariantCultureIgnoreCase) == -1
                    )

                    && HttpContext.Current.Request.UrlReferrer.AbsoluteUri.IndexOf(@"/webpayment/", StringComparison.InvariantCultureIgnoreCase) == -1
                    && HttpContext.Current.Request.UrlReferrer.AbsoluteUri.IndexOf(@"/weblogin/", StringComparison.InvariantCultureIgnoreCase) == -1)
                {

                    DwcDocumentCore.RefererUrl = HttpContext.Current.Request.UrlReferrer == null ? null : HttpContext.Current.Request.UrlReferrer.AbsoluteUri;
                }

                string newContactId = DwcPanel.ContactPanelNewItemId;
                if (newContactId != "") {
                    TPOMM.Tools.Log.Logger.Static.GetContext().Log("HeaderChange Column: {0} SupplierID: {1} Original: {2}", DwcDocumentBase.DocObject.GetValue("SupplierID"), "New", newContactId);
                    DwcDocumentCore.SetContact(newContactId);
                    DwcPanel.ContactPanelNewItemId = "";
                }
            }
        }

        public static string StdPageIncludeCss
        {
            get
            {
                return @"<link href=""" + DwcSmartCache.CreateUrlForCachedQuery(Common.SetUrlParams("../WEBCommon/CommonStyleSheetHandler.ashx",
                                          new string[,] {{"docObject", null}, {"menu", null}}), // Remove  doc object parametr, it is not needed and it is changing url each document, and its breaking cache
                                          new KeyValuePair<string, string>[] {
                                              new KeyValuePair<string,string>("currentThemeId", Common.CurrentThemeId.ToString())
                                          }, 60 * 60, 24 * 5) + @""" rel=""stylesheet"" type=""text/css"" />
<!--[if IE 7]>
    <link href=""../Framework/jQueryMobileGrid/gridIE7.css?v2"" rel=""stylesheet"" type=""text/css"" />
<![endif]-->
";
            }
        }

        public static string StdPageIncludeJavascript
        {
            get {
                return @"
<script type=""text/javascript"" src=""" + DwcSmartCache.CreateUrlForCachedQuery(Common.SetUrlParams("../WEBCommon/CommonScriptHandler.ashx",
                                         new string[,] { { "currentSession", DwcDiagnostics.CurrentSession.ToString()}, {"docObject", null}, {"menu", null} }),
                                          new KeyValuePair<string, string>[] {
                                              new KeyValuePair<string,string>("currentSession", DwcDiagnostics.CurrentSession.ToString()),
                                              new KeyValuePair<string,string>("USER_PROGRAM_APPLY_TO_DOCUMENT",  (DwcUserProgramContext.CurrentUserProgram != null && DwcUserProgramContext.IsForDocumentItems ? "1" : "0")),
                                              new KeyValuePair<string,string>("IS_TOUCH_DEVICE", Common.IsControlMouse ? "0" : "1"),
                                              new KeyValuePair<string,string>("language", Common.GetParamLanguageCode()),
                                              new KeyValuePair<string,string>("currentScannerType", DwcSettingsBase.CurrentScannerType.ToString())
                                          }, 60 * 60, 24 * 5) + @"""></script>
<!--[if lt IE 9]>

<![endif]-->";
            }
        }

        public static string StdPageIncludeMeta
        {
            get {


//<meta http-equiv=""Cache-Control"" content=""no-cache, no-store, must-revalidate, max-age=0, post-check=0, pre-check=0"" />
//<meta http-equiv=""Pragma"" content=""no-cache"" />
//<meta http-equiv=""Expires"" content=""-1"" />
                return
@"

<meta name=""viewport"" content=""width=device-width, initial-scale=1, user-scalable=no""/>
<meta http-equiv=""Content-Type"" content=""text/html; charset=utf-8"" />
<meta name=""apple-touch-fullscreen"" content=""YES""/>
<meta name=""apple-mobile-web-app-capable"" content=""yes""/>
<meta name=""format-detection"" content=""telephone=no"">
<NOSCRIPT><meta http-equiv=REFRESH content=0;URL=../WEBCommon/Error.aspx?noJavascript=1></NOSCRIPT>";
            }
        }*/

        /* public static string StdPageInclude
         {
             get {
                 StringBuilder bld = new StringBuilder();
                 bld.AppendLine(StdPageIncludeMeta);
                 bld.AppendLine(StdPageIncludeCss);
                 bld.AppendLine(StdPageIncludeJavascript);
                 return bld.ToString();
             }
         }*/
        /*
        public static string StdPageScriptSetup(string pageId) {
            return StdPageScriptSetup(pageId, "");
        }

        public static string StdPageScriptSetup( string pageId, string customScript )
        {
                return
@"<script type=""text/javascript"">

// Page initialization
$(""#" + pageId + @""").on(""pageinit"", function() {
    $.mobile.page.prototype.options.backBtnText = """ + DwcLocale.Localize("{loc:drp.back}") + @""";
    $.mobile.loadingMessage = """ + DwcLocale.Localize("{loc:dwc.article.loading}") + @""";
    $.mobile.loadingMessageTextVisible = true;
    $.mobile.defaultDialogTransition = 'none';
    $.mobile.defaultPageTransition = 'none';
    //$.mobile.gradeA = false;
    $.event.special.swipe.horizontalDistanceThreshold = 75;
    $.event.special.swipe.verticalDistanceThreshold = 50;
    //$.mobile.ajaxEnabled = false;
    $.mobile.popup.prototype.options.history = false;

    if ( $(""#dwcLoaderBackground"").length == 0 ) {
        $('body').append(""<div id='dwcLoaderBackground' class='ui-loader-background'> </div>"");
    }

    $.cookie(""dwcTestCK"", ""1"");
    if ( $.cookie(""dwcTestCK"") == null) {
        dwcRedirect(""../WEBCommon/Error.aspx?noCookies=1"");
    }

    $chosen = $('select[data-fulltextselect=""1""]').chosen({placeholder_text_single: """ + DwcLocale.Localize("{loc:dwc.contactEdit.ChooseEntry}") + @""", allow_single_deselect: ""true"", no_results_text: """ + DwcLocale.Localize("{loc:dwc.search.notFound}") + @""", width: ""100%"", search_contains:true});
    " + customScript + @"

    $('a[data-role=""button""]').each(function(){
        var self = $(this), obj = self[0], js;
        if (typeof(obj.onclick) !== 'function'){
            js = self.attr('onclick');
            eval(js);
        }
    });

    $('input[type=""button""]').each(function () {
                var self = $(this),
                    obj = self[0],
                    js;
            js = self.attr('onclick');
                $(self).attr(""onclick"", js);
        });

});
</script>";
        }*/
    }
}
