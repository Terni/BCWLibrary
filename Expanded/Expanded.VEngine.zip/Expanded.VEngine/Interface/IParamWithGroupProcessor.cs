﻿namespace Expanded.VEngine.Interface
{
	public interface IParamWithGroupProcessor
	{
		object ProcessParam(VarParam param, out bool error);
	}
}