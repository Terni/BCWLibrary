﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Expanded.VEngine.Interface
{
    public interface ICommon
    {

        //object SyncLocker;
        //string ProperlyConfiguredSlotID;
        //string MagicString;


        string IsNull(object inVar, string retVal);

        string ObjectToJSON(string var, string val);

        string ArrayToJSON(string var, string[] vals);


        bool GetValueBool(string str);

        string GetObjectStringNoCurrency(object obj);

        string GetObjectString(object obj);

        int GetObjectInt(object obj);

        double GetObjectDouble(object obj);

        decimal GetObjectDecimal(object obj);

        Guid? GetObjectGuid(object obj);

        string GetObjectDateTimeString(object obj);

        string GetObjectDateTimeString(object obj, bool includeTimeString);


        decimal GetObjectCurrencyDecimal(object obj, string currencyISO);


        string GetIntString(object obj);

    }
}
