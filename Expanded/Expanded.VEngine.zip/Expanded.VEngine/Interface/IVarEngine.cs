﻿namespace Expanded.VEngine.Interface
{
	public interface IVarEngine
	{
		string GetSpecialNullValue
		{
			get;
		}

        bool IsArticlePictureElement(string paramStr);
		bool IsContactPictureElement(string paramStr);
		bool IsPictureElement(string paramStr);

		string ProcessSimpleStringValue(string param);

		object ProcessParam(VarParam param, bool ignoreErrors, out bool error);

		bool CommonParametersCheck(VarParam p, object objToCheck, out string fixedStr);

		ProcessStringReturnValue ProcessString(string input);
		ProcessStringReturnValue ProcessString(string input, bool enableHTMLRender, bool quottedReplace);
		ProcessStringReturnValue ProcessString(string input, bool enableHTMLRender, string fixedGroup, bool quottedReplace);
	}
}