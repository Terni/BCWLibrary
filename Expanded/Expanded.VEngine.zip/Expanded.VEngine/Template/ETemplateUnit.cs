﻿////using DRS.Common.ERP;
//using DRS.WEBClientCommon;
////using RV.Common;

namespace Expanded.VEngine.Template
{
	public class ETemplateUnit
	{
		//protected WebClientTemplate _webClientTemplate;
		protected VarParamCollection _detectedParameters;
		protected bool _parametersFilled;

		//public CCTemplateUnit(WebClientTemplate webClientTemplate)
        public ETemplateUnit()
        {
			_detectedParameters = new VarParamCollection();
			//_webClientTemplate = webClientTemplate;
			_parametersFilled = false;
		}

		/*public WebClientTemplate Template
		{
			get
			{
				return _webClientTemplate;
			}

			set
			{
				_webClientTemplate = value;
			}
		}*/

		public VarParamCollection Parameters
		{
			get
			{
				return _detectedParameters;
			}

			set
			{
				_detectedParameters = value;
			}
		}

		public bool ParametersFilled
		{
			get
			{
				return _parametersFilled;
			}

			set
			{
				_parametersFilled = value;
			}
		}

		/*public WebClientTemplateColumn GetColumnByName(string colName)
		{
			string searchName = colName.ToLower();
			foreach (WebClientTemplateColumn c in Template.Columns.WebClientTemplateColumns)
			{
				if (c.ColumnName.ToLower() == searchName)
				{
					return c;
				}
			}

			return null;
		}

		public WebClientTemplateColumn SearchTemplateDetailColumn
		{
			get
			{
				foreach (WebClientTemplateColumn c in Template.Columns.WebClientTemplateColumns)
				{
					if (c.DataType == DisplayValueTypes.Template)
					{
						if (DwcTemplate.GetTemplateIdFromDesignerValue(c.DefaultValue) == "A"
								|| DwcTemplate.GetTemplateIdFromDesignerValue(c.DefaultValue) == "A1")
						{
							return c;
						}
					}
				}
				return null;
			}
		}*/
	}
}