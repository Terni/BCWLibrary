//
// Class which renders templates, variables, and handlers basic communication between client and server side
//

using System;
using System.Collections.Generic;
using Expanded.VEngine.Commons;
using Expanded.VEngine;
using Expanded.VEngine.Interface;

//using System.Data;

//using DRS.Common.ERP;
//using DatecWebClient;
//using RV.Common;


namespace Expanded.VEngine.Template
{

	public static class ETemplate
	{
	    private static VarEngine _varEngine = new VarEngine();


	    //private IVarEngine IVarEngine _varEngine = new IVarEngine();
        //private static readonly IDwcTemplateConverter _dwcTemplateConverter = new DwcTemplateConverter();
        //private static readonly IDwcTemplateCore _dwcTemplateCore = new DwcTemplateCore();
        //private static readonly IDwcTemplateRenderer _dwcTemplateRenderer = new DwcTemplateRenderer();
        //private static readonly IDwcTemplateRenderOneVar _dwcTemplateRenderOneVar = new DwcTemplateRenderOneVar();

        /*public static string GetNormalTemplateKey(int templateId)
		{
			return DwcTemplateGetter.GetNormalTemplateKey(templateId);
		}*/

        /*public static string GetDocumentDeviceTemplateKey(DocSettings docSettings, DocDeviceSettings docDeviceSettings, int step)
		{
			return DwcTemplateGetter.GetDocumentDeviceTemplateKey(docSettings, docDeviceSettings, step);
		}

		public static string GetDocumentDeviceItemsTemplateKey(DocSettings docSettings, DocDeviceSettings docDeviceSettings)
		{
			return DwcTemplateGetter.GetDocumentDeviceItemsTemplateKey(docSettings, docDeviceSettings);
		}*/

        /*public static string GetUserProgramTemplateKey(UserProgram userProgram)
		{
			return DwcTemplateGetter.GetUserProgramTemplateKey(userProgram);
		}

		public static DatecWebClient.TemplateUnit GetTemplate(string key)
		{
			return DwcTemplateGetter.GetTemplate(key);
		}*/

        /*public static WebClientTemplateColumn ConvertReportParameterToTemplateColumn(ReportParameter reportParameter)
		{
			return _dwcTemplateConverter.ConvertReportParameterToTemplateColumn(reportParameter);
		}

		public static WebClientTemplateColumn ConvertUserProgramDialogColumnToTemplateColumn(UserDialogField userDialogField)
		{
			return _dwcTemplateConverter.ConvertUserProgramDialogColumnToTemplateColumn(userDialogField);
		}

		public static void AddTemplate(DocSettings docSettings, DocDeviceSettings docDeviceSettings, int step)
		{
			DwcTemplateGetter.AddTemplate(docSettings, docDeviceSettings, step);
		}

		public static void AddTemplate(DocSettings docSettings, DocDeviceSettings docDeviceSettings)
		{
			DwcTemplateGetter.AddTemplate(docSettings, docDeviceSettings);
		}*/
        /*
		public static void AddTemplate(UserProgram userProgram)
		{
			DwcTemplateGetter.AddTemplate(userProgram);
		}

		public static string GetVarKey(string key, string var)
		{
			return DwcTemplateGetter.GetVarKey(key, var);
		}

		public static string GetTemplateKeyFromVarKey(string varKey)
		{
			return DwcTemplateGetter.GetTemplateKeyFromVarKey(varKey);
		}

		public static string GetVarFromVarKey(string varKey)
		{
			return DwcTemplateGetter.GetVarFromVarKey(varKey);
		}

		public static bool IsCurrencyType(DisplayValueTypes displayValueTypes)
		{
			return _dwcTemplateCore.IsCurrencyType(displayValueTypes);
		}*/


        public static bool IsNumberType(DisplayValueTypes displayValueTypes)
        {
            return ((displayValueTypes == DisplayValueTypes.IntegerNumber
                            || displayValueTypes == DisplayValueTypes.PositiveIntegerNumber
                            || displayValueTypes == DisplayValueTypes.Number
                            || displayValueTypes == DisplayValueTypes.PositiveNumber));
        }
        /*
		public static bool IsEnumType(DisplayValueTypes displayValueTypes)
		{
			return _dwcTemplateCore.IsEnumType(displayValueTypes);
		}

		public static bool IsDateTimeType(DisplayValueTypes displayValueTypes)
		{
			return _dwcTemplateCore.IsDateTimeType(displayValueTypes);
		}

		public static void ProcessImageUpload(bool calledFromHandler, string profileId)
		{
			_dwcTemplateCore.ProcessImageUpload(calledFromHandler, profileId);
		}*/

        public static DisplayValueTypes GetDisplayValueType(object value)
        {
            if (value == null)
            {
                return DisplayValueTypes.Text;
            }
            string regexTime = @"[T| ][0-9][0-9]:[0-9][0-9]:[0-9][0-9]";
            if (System.Text.RegularExpressions.Regex.IsMatch(value.ToString(), regexTime))
            {
                string valuePart = System.Text.RegularExpressions.Regex.Replace(value.ToString(), regexTime, "");
                DateTime d;
                if (DateTime.TryParse(valuePart, out d))
                {
                    return DisplayValueTypes.DateTime;
                }
                if (System.Text.RegularExpressions.Regex.IsMatch(valuePart, @"(\d{1,2}[/.-]\d{1,2}[/.-]\d{4})|(\d{4}[/.-]\d{1,2}[/.-]\d{1,2})"))
                {
                    return DisplayValueTypes.DateTime;
                }
            }
            if (value is int)
            {
                return DisplayValueTypes.IntegerNumber;
            }
            if (value is long)
            {
                return DisplayValueTypes.IntegerNumber;
            }
            if (value is float)
            {
                return DisplayValueTypes.Number;
            }
            if (value is decimal)
            {
                return DisplayValueTypes.Currency;
            }
            if (value is DateTime)
            {
                return DisplayValueTypes.DateTime;
            }
            if (value is string)
            {
                return DisplayValueTypes.Text;
            }
            return DisplayValueTypes.Text;
        }

        public static DisplayValueTypes GetDisplayValueType(Type type)
        {
            if (type == typeof(int))
            {
                return DisplayValueTypes.IntegerNumber;
            }
            if (type == typeof(long))
            {
                return DisplayValueTypes.IntegerNumber;
            }
            if (type == typeof(float))
            {
                return DisplayValueTypes.Number;
            }
            if (type == typeof(decimal))
            {
                return DisplayValueTypes.Currency;
            }
            if (type == typeof(DateTime))
            {
                return DisplayValueTypes.DateTime;
            }
            if (type == typeof(string))
            {
                return DisplayValueTypes.Text;
            }
            return DisplayValueTypes.Text;
        }

        /*

        public static bool IsContactSearchRedirectControl(string dataSource)
        {
            return _dwcTemplateCore.IsContactSearchRedirectControl(dataSource);
        }

        public static bool IsContactExternalSearchRedirectControl(string dataSource)
        {
            return _dwcTemplateCore.IsContactExternalSearchRedirectControl(dataSource);
        }

        public static string GetAssigmentID()
        {
            return DwcTemplateGetter.GetAssigmentID();
        }

        public static List<VarParam> GetSameLevelParameters(Dictionary<string, VarParam> VarParams, List<TemplateUnit> templates, int requiredLayer)
        {
            return DwcTemplateGetter.GetSameLevelParameters(VarParams, templates, requiredLayer);
        }

        public static string GetValueFromRequest(object value, VarParam VarParam, string caption, bool required, DisplayValueTypes displayValueTypes, string dataSource, out bool error)
        {
            return DwcTemplateGetter.GetValueFromRequest(value, VarParam, caption, required, displayValueTypes, dataSource, out error);
        }

        public static string GetValueFromRequest(object value, VarParam VarParam, string caption, bool required, DisplayValueTypes displayValueTypes, string dataSource, out bool error, List<VarParam> sameLevelParameters)
        {
            return DwcTemplateGetter.GetValueFromRequest(value, VarParam, caption, required, displayValueTypes, dataSource, out error, sameLevelParameters);
        }*/
        public static string GetDisplayValue(object value, DisplayValueTypes displayValueTypes, string dataSource)
        {
            return GetDisplayValue(value, displayValueTypes, dataSource, null, null);
        }

        public static string GetDisplayValue(object value, DisplayValueTypes displayValueTypes, string dataSource, string currencyISOCode)
        {
            return GetDisplayValue(value, displayValueTypes, dataSource, currencyISOCode, null);
        }

        public static string GetDisplayValue(object value, DisplayValueTypes displayValueTypes, string dataSource, string currencyISOCode, VarParam nVarParam)
        {
            if (value == null)
            {
                return "";
            }
            switch (displayValueTypes)
            {
                case DisplayValueTypes.Enum:
                case DisplayValueTypes.Multiselect:
                case DisplayValueTypes.MultiselectSearchable:
                    {
                        return GetDisplayValueChoice(value, dataSource, nVarParam);
                    }
                case DisplayValueTypes.PositiveCurrency:
                case DisplayValueTypes.Currency:
                    {
                        return FinalizeDisplayValue(nVarParam, Common.GetPriceString(value, currencyISOCode));
                    }
                case DisplayValueTypes.ShortDate:
                case DisplayValueTypes.DateTime:
                    {
                        return GetDisplayValueDateTime(value, displayValueTypes, nVarParam);
                    }
            }
            return FinalizeDisplayValue(nVarParam, value.ToString());
        }

        private static string GetDisplayValueChoice(object value, string dataSource, VarParam nVarParam)
        {
            throw new NotImplementedException();
        }

        private static string GetDisplayValueDateTime(object value, DisplayValueTypes displayValueTypes, VarParam nVarParam)
        {
            throw new NotImplementedException();
        }

        private static string FinalizeDisplayValue(VarParam nVarParam, string value)
        {
            if (nVarParam == null)
            {
                return value;
            }

            string fixedValue = "";
            if (_varEngine.CommonParametersCheck(nVarParam, value, out fixedValue))
            {
                return fixedValue;
            }

            return value;
        }

        /*
        public static string RenderOneVar(object value, DatecWebClient.VarParam VarParam, DatecWebClient.TemplateUnit TemplateUnit, WebClientTemplateColumn webClientTemplateColumn, int tabIndex, bool inline, bool saveDataOnChange, int recursiveLevel)
        {
            return _dwcTemplateRenderOneVar.RenderOneVar(value, VarParam, TemplateUnit, webClientTemplateColumn, tabIndex, inline, saveDataOnChange, recursiveLevel);
        }

        public static string RenderOneVar(object value, DatecWebClient.VarParam VarParam, DatecWebClient.TemplateUnit TemplateUnit, string caption, string blobValue, string dataSource, bool? editable, bool? visible, bool? required, int? requiredLayer, int tabIndex, string hint, bool inline, DisplayValueTypes displayValueTypes, WebClientTemplateColumnSpecialValues webClientTemplateColumnSpecialValues, bool saveDataOnChange, int recursiveLevel)
        {
            return _dwcTemplateRenderOneVar.RenderOneVar(value, VarParam, TemplateUnit, caption, blobValue, dataSource, editable, visible, required, requiredLayer, tabIndex, hint, inline, displayValueTypes, webClientTemplateColumnSpecialValues, saveDataOnChange, recursiveLevel);
        }

        public static string RenderOneVar(object value, DatecWebClient.VarParam VarParam, DatecWebClient.TemplateUnit TemplateUnit, string caption, string blobValue, string dataSource, bool? editable, bool? visible, bool? required, int? requiredLayer, int tabIndex, string hint, bool inline, DisplayValueTypes displayValueTypes, WebClientTemplateColumnSpecialValues webClientTemplateColumnSpecialValues, bool saveDataOnChange, int recursiveLevel, int? dataTableKey)
        {
            return _dwcTemplateRenderOneVar.RenderOneVar(value, VarParam, TemplateUnit, caption, blobValue, dataSource, editable, visible, required, requiredLayer, tabIndex, hint, inline, displayValueTypes, webClientTemplateColumnSpecialValues, saveDataOnChange, recursiveLevel, dataTableKey);
        }

        public static string RenderOneVar(object value, VarParam VarParam, TemplateUnit TemplateUnit, string caption, string blobValue, string dataSource, bool? editable, bool? visible, bool? required, int? requiredLayer, int tabIndex, string hint, bool inline, DisplayValueTypes displayValueTypes, WebClientTemplateColumnSpecialValues webClientTemplateColumnSpecialValues, bool saveDataOnChange, int recursiveLevel, int? dataTableKey, bool addEmptyEntryToDataSource)
        {
            return _dwcTemplateRenderOneVar.RenderOneVar(value, VarParam, TemplateUnit, caption, blobValue, dataSource, editable, visible, required, requiredLayer, tabIndex, hint, inline, displayValueTypes, webClientTemplateColumnSpecialValues, saveDataOnChange, recursiveLevel, dataTableKey, addEmptyEntryToDataSource);
        }

        public static string GetTemplateIdFromDesignerValue(object value)
        {
            return DwcTemplateGetter.GetTemplateIdFromDesignerValue(value);
        }

        public static string RenderReaderTableHeader(IDataReader dataReader, DatecWebClient.TemplateUnit TemplateUnit, Dictionary<string, double> totals)
        {
            return _dwcTemplateRenderer.RenderReaderTableHeader(dataReader, TemplateUnit, totals);
        }

        public static string RenderReaderTableRow(IDataReader dataReader, DatecWebClient.TemplateUnit TemplateUnit, int keyValue, string style, int row, bool isInlineProgram)
        {
            return _dwcTemplateRenderer.RenderReaderTableRow(dataReader, TemplateUnit, keyValue, style, row, isInlineProgram, true);
        }

        public static string RenderReaderTableRow(IDataReader dataReader, TemplateUnit TemplateUnit, int keyValue, string style, int row, bool isInlineProgram, bool isEditable)
        {
            return _dwcTemplateRenderer.RenderReaderTableRow(dataReader, TemplateUnit, keyValue, style, row, isInlineProgram, isEditable);
        }

        public static string CreateStyleFromTemplateColumn(WebClientTemplateColumn webClientTemplateColumn)
        {
            return _dwcTemplateCore.CreateStyleFromTemplateColumn(webClientTemplateColumn);
        }

        public static string Render(DatecWebClient.TemplateUnit TemplateUnit)
        {
            return _dwcTemplateRenderer.Render(TemplateUnit);
        }

        public static string SaveParametersToResponse(TemplateUnit TemplateUnit)
        {
            return _dwcTemplateRenderer.SaveParametersToResponse(TemplateUnit);
        }

        public static void LoadParametersFromRequest(out List<TemplateUnit> templatesCollection, out VarParamCollection paramCollection)
        {
            _dwcTemplateCore.LoadParametersFromRequest(out templatesCollection, out paramCollection);
        }

        public static string SafeRender(int templateId)
        {
            return _dwcTemplateRenderer.SafeRender(templateId);
        }*/
    }
}